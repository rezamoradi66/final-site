# گزارش اعتبارسنجی MoradiApp.ir — نسخه 3.1.0

## آزمون‌های اجراشده روی سورس 3.1.0

- تمام فایل‌های PHP با `php -l` بدون خطای نحوی بررسی شدند.
- `admin/assets/admin.js` و `assets/js/main.js` با `node --check` بدون خطا بررسی شدند.
- اسکریپت `tests/validate_release.py` همه کنترل‌های ایستا را pass کرد.
- ۳۷ فایل PHP، ۷ تگ script و کنترل‌های CSP/nonce، XSS sink، مسیر fallback، installer، بکاپ، MFA و placeholder بررسی شدند.
- آزمون TOTP RFC 6238 با SHA1، timestamp=59 و کد شش‌رقمی موفق بود.
- آزمون بصری Chromium نشان داد BYekan و BKoodak صحیح رندر می‌شوند؛ B Tir با glyphهای جدا/ناقص رندر شد و عمداً در CSS فعال نشده است.
- فایل `data/products.json` خالی است و هیچ config واقعی/secret نصب داخل بسته نیست.

## محدودیت‌های محیط

این محیط فاقد افزونه‌های PHP `mbstring`، `GD` و `PDO MySQL` است. بنابراین در نسخه 3.1.0 تست HTTP/CRUD، آپلود واقعی، import با MySQL، ورود MFA متصل به DB و بکاپ/restore روی دیتابیس واقعی انجام نشده است. دسترسی به cPanel، TLS و دامنه زنده نیز وجود نداشته است.

در نسخه پایه 3.0.0 قبلاً smoke test مسیرهای عمومی با polyfill خارج از بسته انجام شده بود؛ آن نتیجه را نباید به‌عنوان آزمون end-to-end نسخه 3.1.0 تلقی کرد.

## اصلاحات ممیزی

- رفع Stored XSS در media picker و product workflow.
- رعایت query موفق با صفر محصول؛ پاک‌سازی cache هنگام save/delete.
- نمایش و import idempotent صندوق fallback.
- setup-key برای installer، CSRF در selfdestruct و پیام خطای عمومی.
- rate limit ترکیبی IP/username و محدودیت رمز سازگار با bcrypt.
- CSP nonce، هدرهای امنیتی و HSTS مشروط به HTTPS.
- decode/re-encode تصویر و pixel cap؛ GD به‌عنوان پیش‌نیاز.
- allowlist URL، محدودکردن مسیر تصویر و حذف `allow-same-origin` از iframe sandbox.
- placeholder محلی، صفحه سلامت، بکاپ CLI-only و MFA اختیاری TOTP.

## قبل از انتشار روی دامنه اصلی

1. روی staging با PHP 8.3/8.4، mbstring، GD و PDO MySQL نصب کنید.
2. عملیات ایجاد/ویرایش/حذف محصول، مخصوصاً حذف آخرین محصول، را تست کنید.
3. payloadهای XSS را در نام فایل، عنوان/شرح/ماژول محصول و فرم‌ها تست کنید.
4. upload انواع تصویر مجاز و تصویر با ابعاد بیش از سقف را تست کنید.
5. MFA را فعال و login/logout و recovery procedure را بررسی کنید.
6. در cPanel هدرهای HTTPS، HSTS، CSP، دسترسی مستقیم به `config/` و `data/` را از بیرون تست کنید.
7. Cron بکاپ را اجرا و restore واقعی در دیتابیس staging انجام دهید.

جزئیات یافته‌ها و وضعیت هر مورد در `docs/AUDIT-REMEDIATION-REPORT-FA.md` است.
