# MoradiApp.ir v3.1.0 — نسخه طرح تأییدشده + مدیریت cPanel

## تغییرات
- صفحه اصلی با همان فایل طرح تأییدشده و لایه موشن Liquid Light + Silk Brook
- استفاده از لوگوی رسمی و تصاویر طرح مرجع از فایل تأییدشده
- انتقال فونت‌های BYekan و BKoodak از داده‌های درون فایل مرجع به فایل‌های محلی؛ تطبیق بایت با فونت‌های پیوست بررسی شد. فایل B Tir به دلیل نمایش ناقص حروف فارسی در مرورگر استفاده نمی‌شود.
- اتصال محتوای Hero، کارت‌های خدمات، معرفی و آمار به تنظیمات MySQL و پنل مدیریت
- ویترین محصولات به محصولات واقعی پایگاه داده متصل شد؛ بدون محصول نمونه
- آمار صفحه اصلی خالی می‌ماند تا مدیر آمار واقعی وارد کند
- صفحه مدیریت محتوا بازنویسی شد تا بخش‌های طرح فعلی را مدیریت کند
- تنظیمات ورود مشتریان و ثبت‌نام/درخواست دسترسی اضافه شد
- نسخه مدیر محتوا از مدیریت تنظیمات کلی، کاربران و گزارش فعالیت محدود شد
- اجبار HTTPS در .htaccess و bootstrap فعال شد
- حذف تصاویر mock محصول و seed محصولات نمونه از نصب تازه
- راهنمای نصب، ارتقا و چک‌لیست انتشار اضافه شد

## مواردی که باید در پنل تکمیل شوند
- اطلاعات تماس و شبکه‌های اجتماعی واقعی
- لینک ثبت‌نام/درخواست دسترسی و تأیید لینک ورود
- محصولات/سامانه‌های واقعی و تصاویر آن‌ها
- آمار واقعی (اختیاری)

## 3.1.0 — Audit remediation
- Fixed stored XSS sinks in product workflow and media picker; added nonce-based script CSP.
- Corrected empty-products DB semantics and added durable, visible fallback request import.
- Added setup-key gated installer, CSRF protection for installer self-removal, generic DB error messages.
- Added IP+username login throttling, bcrypt-compatible password byte limit, upload image re-encoding and pixel limits.
- Added HTTP(S) URL validation, iframe sandbox tightening, local image path validation, placeholder art, health page, and CLI-only compressed backups.


## v3.2.0 — 2026-11-27

- Explicit clean routes for About/Contact; MultiViews disabled; canonical path excludes query parameters and PHP aliases redirect to clean URLs.
- Contact requests now use persistent per-IP server-side throttling in addition to session timing.
- Fallback inbox uses a stable month lock file and atomic queue replacement to avoid lost updates under concurrent requests.
- Admin sessions revalidate active status, current role and password hash on every request; role changes apply immediately and password changes revoke sessions.
- Logout changed to POST + CSRF.
- Installer sets private filesystem permissions on generated DB config.
- Backup output is AES-256-GCM encrypted and requires an external `MORADIAPP_BACKUP_KEY`.
- Fixed external media video URL handling; canonical internal links normalized.
- Optimized the official logo to WebP (transparent, visual identity preserved; approx. 1.25 MB → 237 KB).
- Added privacy retention CLI maintenance and updated deployment documentation.

- HTTPS redirect now uses configured `app.canonical_host`; raw `HTTP_HOST` is not used as the redirect destination.
- Existing config permissions are hardened at runtime during upgrade; added CLI permission-hardening utility.
