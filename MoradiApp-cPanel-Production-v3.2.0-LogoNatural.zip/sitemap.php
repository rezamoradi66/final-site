<?php
/**
 * sitemap.php — نقشه سایت داینامیک (از طریق .htaccess به sitemap.xml نگاشت می‌شود)
 */
require_once __DIR__ . '/includes/bootstrap.php';
header('Content-Type: application/xml; charset=utf-8');

$urls = [
    ['loc' => full_url(),                'priority' => '1.0', 'changefreq' => 'weekly'],
    ['loc' => full_url('products'),      'priority' => '0.9', 'changefreq' => 'weekly'],
    ['loc' => full_url('about'),         'priority' => '0.6', 'changefreq' => 'monthly'],
    ['loc' => full_url('contact'),       'priority' => '0.6', 'changefreq' => 'monthly'],
];
$urls[] = ['loc' => full_url('privacy'), 'priority' => '0.4', 'changefreq' => 'yearly'];

foreach (Store::products() as $p) {
    $urls[] = ['loc' => full_url('products/' . $p['slug']), 'priority' => '0.8', 'changefreq' => 'weekly'];
    $urls[] = ['loc' => full_url('demos/' . $p['slug']),    'priority' => '0.5', 'changefreq' => 'monthly'];
}

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
foreach ($urls as $u) {
    echo "  <url>\n";
    echo '    <loc>' . e($u['loc']) . "</loc>\n";
    echo '    <changefreq>' . $u['changefreq'] . "</changefreq>\n";
    echo '    <priority>' . $u['priority'] . "</priority>\n";
    echo "  </url>\n";
}
echo '</urlset>';
