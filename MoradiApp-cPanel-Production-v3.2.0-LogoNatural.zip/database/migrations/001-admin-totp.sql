-- Apply to existing installations only if these columns are absent.
ALTER TABLE admin_users ADD COLUMN totp_secret VARCHAR(255) NULL;
ALTER TABLE admin_users ADD COLUMN totp_enabled TINYINT(1) NOT NULL DEFAULT 0;
