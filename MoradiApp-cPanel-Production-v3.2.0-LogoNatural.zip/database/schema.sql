-- =====================================================================
-- مرادی‌اپ | Software Showcase — ساختار دیتابیس
-- سازگار با MySQL 5.7+ / 8.0 و MariaDB 10.3+ (utf8mb4 / InnoDB)
--
-- نکته: برای اطمینان از نسخه واقعی دیتابیس هاست خود، در phpMyAdmin
-- کوئری «SELECT VERSION();» را اجرا کنید.
-- این فایل توسط install.php به‌صورت خودکار اجرا می‌شود؛
-- اجرای دستی آن از طریق phpMyAdmin نیز بدون خطا امکان‌پذیر است.
-- =====================================================================

SET NAMES utf8mb4;

-- ---------------------------------------------------------------------
-- محصولات / سامانه‌ها
-- فیلدهای آرایه‌ای (gallery, features, modules, technologies) به‌صورت
-- JSON داخل LONGTEXT ذخیره می‌شوند تا با همه نسخه‌های MySQL/MariaDB
-- سازگار باشد.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `products` (
    `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `slug`          VARCHAR(120)  NOT NULL,
    `title`         VARCHAR(180)  NOT NULL,
    `subtitle`      VARCHAR(220)  NOT NULL DEFAULT '',
    `description`   MEDIUMTEXT    NULL,
    `category`      VARCHAR(80)   NOT NULL DEFAULT '',
    `image`         VARCHAR(255)  NOT NULL DEFAULT '',
    `gallery`       LONGTEXT      NULL,
    `features`      LONGTEXT      NULL,
    `modules`       LONGTEXT      NULL,
    `technologies`  LONGTEXT      NULL,
    `demo_url`      VARCHAR(500)  NOT NULL DEFAULT '',
    `demo_type`     VARCHAR(20)   NOT NULL DEFAULT 'placeholder',
    `status`        VARCHAR(20)   NOT NULL DEFAULT 'active',
    `featured`      TINYINT(1)    NOT NULL DEFAULT 0,
    `display_order` INT           NOT NULL DEFAULT 0,
    `created_at`    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`    DATETIME      NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_products_slug` (`slug`),
    KEY `idx_products_status` (`status`),
    KEY `idx_products_order` (`display_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- کتابخانه رسانه‌ها (تصاویر آپلودشده)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `media` (
    `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `filename`      VARCHAR(255) NOT NULL,
    `original_name` VARCHAR(255) NOT NULL DEFAULT '',
    `alt_text`      VARCHAR(255) NOT NULL DEFAULT '',
    `mime_type`     VARCHAR(80)  NOT NULL DEFAULT '',
    `file_size`     INT UNSIGNED NOT NULL DEFAULT 0,
    `width`         INT UNSIGNED NOT NULL DEFAULT 0,
    `height`        INT UNSIGNED NOT NULL DEFAULT 0,
    `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_media_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- درخواست‌های دمو ثبت‌شده از فرم سایت
-- (product_id مرجع سخت‌گیرانه ندارد تا با حذف محصول، تاریخچه درخواست‌ها
--  از دست نرود؛ product_title برای همین به‌صورت snapshot نگهداری می‌شود)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `demo_requests` (
    `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `full_name`     VARCHAR(120) NOT NULL,
    `organization`  VARCHAR(150) NOT NULL DEFAULT '',
    `phone`         VARCHAR(30)  NOT NULL,
    `email`         VARCHAR(150) NOT NULL DEFAULT '',
    `product_id`    INT UNSIGNED NULL,
    `product_title` VARCHAR(180) NOT NULL DEFAULT '',
    `message`       TEXT         NULL,
    `status`        VARCHAR(20)  NOT NULL DEFAULT 'new',
    `internal_note` TEXT         NULL,
    `archived`      TINYINT(1)   NOT NULL DEFAULT 0,
    `ip_address`    VARCHAR(45)  NOT NULL DEFAULT '',
    `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`    DATETIME     NULL,
    PRIMARY KEY (`id`),
    KEY `idx_req_status` (`status`),
    KEY `idx_req_created` (`created_at`),
    KEY `idx_req_archived` (`archived`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- کاربران مدیریتی پنل
-- رمز عبور با password_hash (bcrypt) هش می‌شود — هرگز متن ساده ذخیره نشود.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `admin_users` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `username`        VARCHAR(60)  NOT NULL,
    `email`           VARCHAR(150) NOT NULL DEFAULT '',
    `full_name`       VARCHAR(120) NOT NULL DEFAULT '',
    `password_hash`   VARCHAR(255) NOT NULL,
    `role`            VARCHAR(20)  NOT NULL DEFAULT 'admin',
    `is_active`       TINYINT(1)   NOT NULL DEFAULT 1,
    `failed_attempts` INT          NOT NULL DEFAULT 0,
    `locked_until`    DATETIME     NULL,
    `last_login`      DATETIME     NULL,
    `totp_secret`     VARCHAR(255) NULL,
    `totp_enabled`    TINYINT(1)   NOT NULL DEFAULT 0,
    `created_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_admin_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- تنظیمات سایت (مقادیر کلیدی؛ مقادیر آرایه‌ای به‌صورت JSON)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `site_settings` (
    `setting_key`   VARCHAR(80)  NOT NULL,
    `setting_value` MEDIUMTEXT   NULL,
    `updated_at`    DATETIME     NULL,
    PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- گزارش فعالیت‌های مدیریتی
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `activity_log` (
    `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `admin_user_id` INT UNSIGNED NULL,
    `username`      VARCHAR(60)  NOT NULL DEFAULT '',
    `action`        VARCHAR(60)  NOT NULL,
    `details`       VARCHAR(500) NOT NULL DEFAULT '',
    `ip_address`    VARCHAR(45)  NOT NULL DEFAULT '',
    `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_log_created` (`created_at`),
    KEY `idx_log_action` (`action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- شناسه‌های import صندوق fallback برای جلوگیری از ثبت تکراری پس از crash/retry
CREATE TABLE IF NOT EXISTS `request_fallback_imports` (
    `fallback_ref` CHAR(64) NOT NULL,
    `request_id` INT UNSIGNED NOT NULL,
    `imported_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`fallback_ref`),
    KEY `idx_fallback_request` (`request_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
