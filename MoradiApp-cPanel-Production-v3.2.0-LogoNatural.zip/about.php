<?php
/**
 * about.php — صفحه درباره ما (نسخه ۲.۰)
 * محتوا کاملاً از پنل مدیریت قابل تغییر است؛ هیچ عدد ساختگی نمایش داده نمی‌شود.
 */
require_once __DIR__ . '/includes/bootstrap.php';
secure_session_start();

$S = Store::settings();
$home = (array)($S['home'] ?? []);
$stats = (array)($home['stats'] ?? []);

$pageTitle = 'درباره ما | ' . ($S['brand_name'] ?: 'مرادی‌اپ');
$pageDesc  = excerpt($S['brand_desc'] ?? '', 160);

require __DIR__ . '/includes/partials/header.php';
?>
<section class="page-hero">
    <div class="container">
        <div class="crumb"><a href="<?= base_url() ?>">خانه</a> / درباره ما</div>
        <span class="eyebrow"><span class="idx">MoradiApp</span>هویت مجموعه</span>
        <h1><?= e($S['brand_name'] ?: 'مرادی‌اپ') ?></h1>
        <p class="lead"><?= e($S['brand_desc'] ?: '') ?></p>
    </div>
</section>

<section class="section" style="padding-top:20px">
    <div class="container">
        <div class="sec-head reveal">
            <span class="eyebrow"><span class="idx">۰۱</span>رویکرد ما</span>
            <h2 class="sec-title">سامانه‌هایی که با فرآیندهای واقعی سازمان ساخته می‌شوند</h2>
        </div>
        <div class="pd-prose reveal">
            <p>توسعه هر سامانه از گفت‌وگو با کاربران واقعی سازمان آغاز می‌شود؛ فرآیندهای موجود، نقاط درد کاربران و الزامات گزارش‌گیری، مبنای طراحی قرار می‌گیرد. به همین دلیل رابط‌های سامانه‌ها با منطق کاری سازمان هم‌خوان است و آموزش کاربران به‌سرعت انجام می‌شود.</p>
            <p>معماری ماژولار به سازمان‌ها اجازه می‌دهد تنها بخش‌های موردنیاز را مستقر کنند و در ادامه، بدون بازنویسی، ماژول‌های جدید را اضافه کنند. اشتراک داده بین ماژول‌ها، ورود اطلاعات تکراری را حذف می‌کند و گزارش‌های یکپارچه ممکن می‌سازد.</p>
        </div>
    </div>
</section>

<section class="section" style="padding-top:0">
    <div class="container">
        <div class="sec-head reveal">
            <span class="eyebrow"><span class="idx">۰۲</span>تخصص ما</span>
            <h2 class="sec-title">در چه حوزه‌هایی فعال هستیم؟</h2>
        </div>
        <div class="bento">
            <?php foreach ((array)($S['tech'] ?? []) as $ti => $t): ?>
            <div class="bento-card reveal<?= ($ti === 0) ? ' wide' : '' ?>" style="--d:<?= ($ti % 4) * 0.05 ?>s">
                <span class="b-num"><?= e(fa_num(sprintf('%02d', $ti + 1))) ?></span>
                <span class="b-ico"><?= icon(['layers','workflow','server','database','roles','extend','monitor'][$ti % 7]) ?></span>
                <h3><?= e($t['title']) ?></h3>
                <p><?= e($t['desc']) ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php if (!empty($stats)): ?>
<section class="section" style="padding-top:0">
    <div class="container">
        <div class="stats-grid">
            <?php foreach ($stats as $st): ?>
            <div class="stat-card reveal">
                <div class="num" data-count="<?= (int)($st['value'] ?? 0) ?>" data-suffix="<?= e($st['suffix'] ?? '') ?>">
                    <?= e(fa_num((string)($st['value'] ?? '0'))) . e($st['suffix'] ?? '') ?>
                </div>
                <div class="lbl"><?= e($st['label'] ?? '') ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<section class="section" style="padding-top:0">
    <div class="container">
        <div class="cta-band reveal">
            <div>
                <h2>بگوئید سازمان شما به چه نیازی دارد</h2>
                <p>نسخه آزمایشی سامانه مرتبط را فعال می‌کنیم و در جلسه‌ای کوتاه امکانات را ارائه می‌دهیم.</p>
            </div>
            <div class="btns">
                <a class="btn btn-primary" href="<?= base_url('contact#request-form') ?>">درخواست دمو</a>
                <a class="btn btn-ghost" href="<?= base_url('products') ?>">مشاهده سامانه‌ها</a>
            </div>
        </div>
    </div>
</section>

<?php require __DIR__ . '/includes/partials/footer.php'; ?>
