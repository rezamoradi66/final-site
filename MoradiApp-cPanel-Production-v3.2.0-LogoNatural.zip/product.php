<?php
/**
 * product.php — صفحه اختصاصی هر سامانه (نسخه ۲.۰)
 * آدرس تمیز: /products/{slug} (از طریق .htaccess)
 * قالب مشترک، محتوای کاملاً مستقل از دیتابیس/فایل داده.
 */
require_once __DIR__ . '/includes/bootstrap.php';
secure_session_start();

$slug = (string)($_GET['slug'] ?? '');
$p = Store::product($slug);
if (!$p || $p['status'] !== 'active') {
    http_response_code(404);
    require __DIR__ . '/404.php';
    exit;
}

$S = Store::settings();
$all = Store::products();
$pos = 0;
foreach ($all as $i => $x) { if (($x['slug'] ?? '') === $slug) { $pos = $i; break; } }
$hues = ['', 'h-teal', 'h-amber', 'h-rose', 'h-sky', 'h-ink'];
$hueClass = $hues[$pos % count($hues)];

$related = array_values(array_filter($all, fn($x) => ($x['slug'] ?? '') !== $slug));
$related = array_slice($related, 0, 3);

$pageTitle = $p['title'] . ' | ' . ($S['brand_name'] ?: 'مرادی‌اپ');
$pageDesc  = excerpt($p['subtitle'] ?: $p['description'], 160);
$img = !empty($p['image']) ? base_url($p['image']) : '';
$hasDemo = !empty($p['demo_url']) && $p['demo_type'] !== 'placeholder';

require __DIR__ . '/includes/partials/header.php';
?>
<section class="page-hero <?= $hueClass ?>">
    <div class="container">
        <div class="crumb"><a href="<?= base_url() ?>">خانه</a> / <a href="<?= base_url('products') ?>">سامانه‌ها</a> / <?= e($p['title']) ?></div>
        <div class="pd-hero">
            <div class="reveal">
                <span class="show-cat"><?= e($p['category'] ?: 'سامانه سازمانی') ?><?= !empty($p['featured']) ? ' · سامانه منتخب' : '' ?></span>
                <h1><?= e($p['title']) ?></h1>
                <p class="lead"><?= e($p['subtitle']) ?></p>
                <?php if (!empty($p['technologies'])): ?>
                <div class="pd-tags">
                    <?php foreach ($p['technologies'] as $t): ?><span><?= e($t) ?></span><?php endforeach; ?>
                </div>
                <?php endif; ?>
                <div class="pd-actions">
                    <a class="btn btn-primary" href="<?= e(base_url('demos/' . $p['slug'])) ?>"><?= icon('play') ?><?= $hasDemo ? 'ورود به نسخه آزمایشی' : 'درخواست نسخه آزمایشی' ?></a>
                    <a class="btn btn-ghost" href="#pd-request">درخواست دمو</a>
                </div>
            </div>
            <div class="pd-shot reveal clip-host">
                <div class="aura" aria-hidden="true"></div>
                <div class="frame">
                    <div class="f-head"><i></i><i></i><i></i><b><?= e($p['title']) ?></b></div>
                    <div class="f-body">
                        <?php if ($img): ?><img src="<?= e($img) ?>" alt="محیط اصلی <?= e($p['title']) ?>" width="880" height="550" loading="eager" decoding="async"><?php else: ?><img class="product-image-placeholder" src="<?= e(base_url('assets/images/products/placeholder.svg')) ?>" alt="تصویر سامانه هنوز ثبت نشده" width="600" height="338"><?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php if ($p['description']): ?>
<section class="pd-section">
    <div class="container">
        <div class="sec-head reveal">
            <span class="eyebrow"><span class="idx">۰۱</span>معرفی سامانه</span>
            <h2 class="sec-title">این سامانه چه مسئله‌ای را حل می‌کند؟</h2>
        </div>
        <div class="pd-prose reveal">
            <?= nl2br(e($p['description'])) ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php if (!empty($p['features'])): ?>
<section class="pd-section tinted">
    <div class="container">
        <div class="sec-head reveal">
            <span class="eyebrow"><span class="idx">۰۲</span>قابلیت‌های کلیدی</span>
            <h2 class="sec-title">امکانات اصلی <?= e($p['title']) ?></h2>
        </div>
        <div class="pd-feat-grid">
            <?php foreach ($p['features'] as $fi => $f): ?>
            <div class="pd-feat reveal" style="--d:<?= ($fi % 3) * 0.05 ?>s"><?= icon('check') ?><span><?= e($f) ?></span></div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php if (!empty($p['modules'])): ?>
<section class="pd-section">
    <div class="container">
        <div class="sec-head reveal">
            <span class="eyebrow"><span class="idx">۰۳</span>ماژول‌ها</span>
            <h2 class="sec-title">ساختار ماژولار سامانه</h2>
            <p class="sec-lead">سامانه از <?= e(fa_num((string)count($p['modules']))) ?> ماژول اصلی تشکیل شده است؛ هر ماژول مستقل اما داده‌اش با بقیه یکپارچه است.</p>
        </div>
        <div class="pd-modules">
            <?php foreach ($p['modules'] as $mi => $m): ?>
            <div class="pd-module reveal" style="--d:<?= ($mi % 2) * 0.06 ?>s">
                <span class="m-num" aria-hidden="true"><?= e(fa_num(sprintf('%02d', $mi + 1))) ?></span>
                <h3><?= e($m['title']) ?></h3>
                <p><?= e($m['description'] ?? '') ?></p>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<section class="pd-section tinted">
    <div class="container">
        <div class="sec-head reveal">
            <span class="eyebrow"><span class="idx">۰۴</span>گردش کار</span>
            <h2 class="sec-title">چرخه عملیاتی در یک نگاه</h2>
        </div>
        <div class="journey reveal">
            <div class="j-steps" style="--pd-cols: <?= min(4, count($p['modules'])) ?>">
                <?php foreach (array_slice($p['modules'], 0, 4) as $mi => $m): ?>
                <div class="j-step<?= $mi === 0 ? ' active' : '' ?>">
                    <span class="j-num"><?= e(fa_num((string)($mi + 1))) ?></span>
                    <span class="j-name"><?= e($m['title']) ?></span>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="j-detail" id="jDetail"></div>
            <script nonce="<?= e($GLOBALS['CSP_NONCE'] ?? '') ?>" id="flowData" type="application/json"><?= json_encode(
                array_map(fn($m) => ['title' => $m['title'], 'desc' => $m['description'] ?? '', 'points' => []], array_slice($p['modules'], 0, 4)),
                JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_THROW_ON_ERROR
            ) ?></script>
        </div>
    </div>
</section>
<?php endif; ?>

<?php if (!empty($p['gallery'])): ?>
<section class="pd-section">
    <div class="container">
        <div class="sec-head reveal">
            <span class="eyebrow"><span class="idx">۰۵</span>محیط نرم‌افزار</span>
            <h2 class="sec-title">تصاویر محیط کار سامانه</h2>
            <p class="sec-lead">برای مشاهده بزرگ‌تر روی تصاویر کلیک کنید.</p>
        </div>
        <div class="pd-gallery">
            <?php foreach ($p['gallery'] as $gi => $g): ?>
            <figure class="reveal clip-host" style="--d:<?= ($gi % 2) * 0.08 ?>s">
                <img src="<?= e(base_url($g)) ?>" alt="تصویر محیط <?= e($p['title']) ?>" width="800" height="500" loading="lazy" decoding="async">
            </figure>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<?php if ($related): ?>
<section class="pd-section tinted">
    <div class="container">
        <div class="sec-head reveal">
            <span class="eyebrow"><span class="idx">۰۶</span>سامانه‌های مرتبط</span>
            <h2 class="sec-title">در کنار این سامانه، این‌ها هم دیده می‌شوند</h2>
        </div>
        <div class="rel-grid">
            <?php foreach ($related as $ri => $r):
                $rImg = !empty($r['image']) ? base_url($r['image']) : '';
            ?>
            <a class="rel-card reveal" style="--d:<?= $ri * 0.06 ?>s" href="<?= e(base_url('products/' . $r['slug'])) ?>">
                <span class="rc-cat"><?= e($r['category'] ?: 'سامانه سازمانی') ?></span>
                <h3><?= e($r['title']) ?></h3>
                <p><?= e(excerpt($r['subtitle'] ?: $r['description'], 90)) ?></p>
                <span class="rc-link">مشاهده روایت کامل<?= icon('arrow') ?></span>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<section class="pd-section">
    <div class="container">
        <div class="cta-band reveal">
            <div>
                <h2>موضوع برای شما روشن است؟</h2>
                <p>نسخه آزمایشی <?= e($p['title']) ?> را تجربه کنید یا درخواست ارائه اختصاصی ثبت نمایید.</p>
            </div>
            <div class="btns">
                <a class="btn btn-primary" href="<?= e(base_url('demos/' . $p['slug'])) ?>"><?= icon('play') ?>تجربه نسخه آزمایشی</a>
                <a class="btn btn-ghost" href="#pd-request">درخواست دمو</a>
            </div>
        </div>
    </div>
</section>

<section class="pd-section" id="pd-request" style="padding-top:0">
    <div class="container">
        <?php $prefillProduct = $p['slug']; require __DIR__ . '/includes/partials/request-form.php'; ?>
    </div>
</section>

<div class="lightbox" id="lightbox" role="dialog" aria-label="نمایش تصویر بزرگ">
    <button class="lb-close" type="button" aria-label="بستن">✕</button>
    <img src="" alt="">
</div>

<?php require __DIR__ . '/includes/partials/footer.php'; ?>
