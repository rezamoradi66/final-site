# آزمون‌های نسخه ۳.۱.۰

از ریشه بسته اجرا کنید:

```bash
python3 tests/validate_release.py
```

این اسکریپت syntax PHP/JavaScript و چند کنترل ایستای امنیتی/یکپارچگی را بررسی می‌کند. آزمون زندهٔ MySQL، cPanel، TLS و restore بکاپ باید روی staging انجام شود.
