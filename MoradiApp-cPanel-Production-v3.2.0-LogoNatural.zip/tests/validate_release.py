#!/usr/bin/env python3
"""Static release checks for MoradiApp v3.2.0. Run: python3 tests/validate_release.py"""
from pathlib import Path
import subprocess, sys, re
ROOT=Path(__file__).resolve().parents[1]
fail=[]
def check(name, ok):
    print(('PASS' if ok else 'FAIL')+' '+name)
    if not ok: fail.append(name)
php_files=list(ROOT.rglob('*.php'))
for f in php_files:
    p=subprocess.run(['php','-l',str(f)],capture_output=True,text=True)
    if p.returncode: fail.append('PHP syntax: '+str(f)); print('FAIL PHP syntax:',f,p.stdout,p.stderr)
check('all PHP files pass php -l',not any(x.startswith('PHP syntax:') for x in fail))
for js in [ROOT/'admin/assets/admin.js',ROOT/'assets/js/main.js']:
    p=subprocess.run(['node','--check',str(js)],capture_output=True,text=True)
    check('JS syntax '+str(js.relative_to(ROOT)),p.returncode==0)
admin_js=(ROOT/'admin/assets/admin.js').read_text()
main_js=(ROOT/'assets/js/main.js').read_text()
store=(ROOT/'includes/store.php').read_text()
boot=(ROOT/'includes/bootstrap.php').read_text()
product=(ROOT/'product.php').read_text()
check('no innerHTML sinks in application JS', 'innerHTML' not in admin_js+main_js)
check('product flow JSON uses HEX escaping', all(x in product for x in ['JSON_HEX_TAG','JSON_HEX_AMP','JSON_HEX_APOS','JSON_HEX_QUOT']))
check('DB empty product set is respected', 'dbReadSucceeded' in store and 'if (!self::$dbMode || !$dbReadSucceeded)' in store)
check('fallback queue uses stable lock file + atomic replacement', 'fallbackRequests' in store and 'importFallbackRequest' in store and 'writeFallbackQueueLocked' in store and '.requests-' in store)
check('CSP uses per-response nonce and blocks inline event attributes', "'nonce-" in boot and "script-src-attr 'none'" in boot and "script-src 'self' 'unsafe-inline'" not in boot)
check('HTTPS redirect uses configured host, not raw HTTP_HOST', 'app.canonical_host' in boot and "header('Location: https://' . $canonicalHost . $uri" in boot and 'https://%{HTTP_HOST}' not in (ROOT/'.htaccess').read_text())
check('HSTS is conditional on HTTPS', "if (is_https()) { header('Strict-Transport-Security" in boot)
check('installer is setup-key gated and self-destruct CSRF protected', 'setup.key' in (ROOT/'install.php').read_text() and 'hash_equals' in (ROOT/'install.php').read_text() and "if (isset($_POST['selfdestruct'])) {\n    csrf_check();" in (ROOT/'install.php').read_text())
check('image uploads re-encoded and pixel capped', 'imagecreatefromstring' in (ROOT/'admin/media.php').read_text() and '12000000' in (ROOT/'admin/media.php').read_text())
check('TOTP MFA enrollment/login and encrypted secret storage present', 'totp_verify' in (ROOT/'admin/includes/auth.php').read_text() and 'mfa_encrypt_secret' in (ROOT/'admin/security.php').read_text() and 'aes-256-gcm' in (ROOT/'admin/includes/auth.php').read_text().lower() and (ROOT/'admin/security.php').exists())
check('CLI backup restore verification utility present', "PHP_SAPI !== 'cli'" in (ROOT/'scripts/restore-backup.php').read_text() and 'openssl_decrypt' in (ROOT/'scripts/restore-backup.php').read_text())
check('CLI privacy retention task present', "PHP_SAPI !== 'cli'" in (ROOT/'scripts/retention.php').read_text() and 'archived=1' in (ROOT/'scripts/retention.php').read_text())
check('backup script CLI-only, authenticated encryption, and protected', "PHP_SAPI !== 'cli'" in (ROOT/'scripts/backup.php').read_text() and 'aes-256-gcm' in (ROOT/'scripts/backup.php').read_text().lower() and 'MORADIAPP_BACKUP_KEY' in (ROOT/'scripts/backup.php').read_text() and (ROOT/'scripts/.htaccess').exists())
check('clean contact/about/privacy routes and MultiViews disabled', 'RewriteRule ^contact/?$ contact.php' in (ROOT/'.htaccess').read_text() and 'RewriteRule ^privacy/?$ privacy.php' in (ROOT/'.htaccess').read_text() and 'Options -Indexes -MultiViews' in (ROOT/'.htaccess').read_text())
check('admin session revalidates account active/role/password', 'SELECT username, full_name, role, is_active, password_hash FROM admin_users' in (ROOT/'admin/includes/auth.php').read_text())
check('logout requires POST and CSRF', "$_SERVER['REQUEST_METHOD'] !== 'POST'" in (ROOT/'admin/logout.php').read_text() and 'csrf_check();' in (ROOT/'admin/logout.php').read_text())
check('contact form has persistent server-side rate limit', 'contact_rate_limit_allow' in (ROOT/'contact.php').read_text() and 'contact-rate.json' in (ROOT/'includes/helpers.php').read_text())
check('upgrade hardens existing config permissions and CLI hardening utility exists', 'chmod($configFileForPerms, 0600)' in boot and "PHP_SAPI !== 'cli'" in (ROOT/'scripts/harden-permissions.php').read_text())
check('installer config permission is private', "chmod(CONFIG_DIR . '/config.php', 0600)" in (ROOT/'install.php').read_text())
check('fallback import table in schema', 'request_fallback_imports' in (ROOT/'database/schema.sql').read_text())
check('no broken mock image reference', 'mock-budget.webp' not in ''.join(f.read_text(errors='ignore') for f in ROOT.rglob('*.php')))
check('no sample products', (ROOT/'data/products.json').read_text().strip()=='[]')
check('no live config or setup secret included', not (ROOT/'config/config.php').exists() and not (ROOT/'config/setup.key').exists())
# all inline script tags must carry nonce; inline event handlers are disallowed by CSP
php_text=''.join(f.read_text(errors='ignore') for f in ROOT.rglob('*.php'))
script_tags=re.findall(r'<script\b[^>]*>',php_text,re.I)
check('every PHP script tag has nonce', all('nonce=' in tag.lower() for tag in script_tags))
check('no inline event handlers', not re.search(r'\bon(?:click|change|submit|load|error|focus)\s*=',php_text,re.I))
if fail: sys.exit(1)
print(f'Validated {len(php_files)} PHP files and {len(script_tags)} script tags.')
