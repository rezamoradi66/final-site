<?php
require_once dirname(__DIR__).'/includes/bootstrap.php';
$idx=(int)($argv[1]??0);
$ok=Store::saveRequest(['full_name'=>'Concurrent '.$idx,'organization'=>'Test Org','phone'=>'09123456789','email'=>'','product_id'=>null,'product_title'=>'Test','message'=>'Concurrency test '.$idx,'ip_address'=>'127.0.0.1']);
if(!$ok){fwrite(STDERR,"failed {$idx}\n");exit(1);}
