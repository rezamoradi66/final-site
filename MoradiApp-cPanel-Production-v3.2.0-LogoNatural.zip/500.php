<?php
/**
 * 500.php — صفحه خطای داخلی (بدون افشای جزئیات فنی)
 * سبک: تم روشن، فونت‌های B (بدون فونت غیرمجاز)
 */
http_response_code(500);
if (!headers_sent()) {
    header('Content-Type: text/html; charset=utf-8');
}
echo '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><title>خطای داخلی</title></head>'
   . '<body style="margin:0;background:#F7F4EE;color:#101E32;font-family:\'B Nazanin\',\'BNazanin\',sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh">'
   . '<div style="text-align:center;padding:32px"><div style="font-size:88px;font-weight:bold;line-height:1.2;color:transparent;-webkit-text-stroke:2px rgba(28,78,216,.4);font-family:\'B Mitra\',\'BMitra\',sans-serif">۵۰۰</div>'
   . '<h1 style="font-size:26px;font-family:\'B Mitra\',\'BMitra\',sans-serif">خطای داخلی سرور</h1>'
   . '<p style="color:#48586E">مشکلی رخ داده است. لطفاً بعداً دوباره تلاش کنید.</p>'
   . '<a href="/" style="color:#1C4ED8">بازگشت به صفحه اصلی</a></div></body></html>';
