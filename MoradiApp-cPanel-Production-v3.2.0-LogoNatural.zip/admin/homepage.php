<?php
$adminTitle = 'مدیریت محتوای صفحه اصلی';
$adminActive = 'homepage';
require_once __DIR__ . '/includes/admin-boot.php';

$defaults = [
 'hero_title'=>'راهکارهای نرم‌افزاری هوشمند',
 'hero_subtitle'=>'برای توسعه و رشد کسب‌وکار شما',
 'about_title'=>'معرفی MoradiApp.ir',
 'about_text'=>'ما در MoradiApp.ir با تکیه بر تجربه، تخصص و فناوری‌های نوین، راهکارهای نرم‌افزاری متناسب با نیاز سازمان‌ها و کسب‌وکارها ارائه می‌دهیم. هدف ما، تحول دیجیتال، افزایش بهره‌وری و ایجاد ارزش پایدار برای مشتریان است.',
 'features'=>[
  ['title'=>'نرم‌افزارهای اختصاصی','subtitle'=>'از ایده تا اجرا'],
  ['title'=>'راهکارهای منعطف','subtitle'=>'متناسب با نیاز شما'],
  ['title'=>'پشتیبانی مطمئن','subtitle'=>'همراه شما در تمام مراحل']
 ],
 'stats'=>[]
];
$V = array_replace_recursive($defaults, (array)Store::settings('visual_content', []));
if ($_SERVER['REQUEST_METHOD']==='POST') {
 csrf_check();
 $new = [
  'hero_title'=>mb_substr(trim((string)($_POST['hero_title']??'')),0,160),
  'hero_subtitle'=>mb_substr(trim((string)($_POST['hero_subtitle']??'')),0,220),
  'about_title'=>mb_substr(trim((string)($_POST['about_title']??'')),0,120),
  'about_text'=>mb_substr(trim((string)($_POST['about_text']??'')),0,1200),
  'features'=>[],
  'stats'=>[]
 ];
 $ft=(array)($_POST['feature_title']??[]); $fs=(array)($_POST['feature_subtitle']??[]);
 for($i=0;$i<3;$i++){
  $new['features'][]=[
   'title'=>mb_substr(trim((string)($ft[$i]??'')),0,100),
   'subtitle'=>mb_substr(trim((string)($fs[$i]??'')),0,120)
  ];
 }
 $sv=(array)($_POST['stat_value']??[]); $sl=(array)($_POST['stat_label']??[]);
 for($i=0;$i<4;$i++){
  $value=mb_substr(trim((string)($sv[$i]??'')),0,40);
  $label=mb_substr(trim((string)($sl[$i]??'')),0,80);
  if($value!=='' && $label!=='') $new['stats'][]=['value'=>$value,'label'=>$label];
 }
 if($new['hero_title']==='' || $new['hero_subtitle']==='' || $new['about_text']===''){
  flash_set('err','تیتر اصلی، زیرتیتر و متن معرفی نباید خالی باشند.');
 } elseif(Store::saveSettings(['visual_content'=>$new])){
  Store::syncStaticData();
  log_activity('homepage_visual_update','ویرایش محتوای طرح تأییدشده صفحه اصلی');
  flash_set('ok','محتوای صفحه اصلی ذخیره شد و در سایت اعمال شد.');
 } else { flash_set('err','ذخیره محتوا ناموفق بود؛ اتصال دیتابیس را بررسی کنید.'); }
 redirect('homepage.php');
}
require __DIR__ . '/includes/admin-header.php';
?>
<form method="post" data-validate>
 <?= csrf_field() ?>
 <div class="panel">
  <h2>متن بخش اصلی (Hero)</h2>
  <p class="p-desc">چیدمان، لوگو، رنگ‌ها و موشن طرح تأییدشده ثابت می‌مانند؛ فقط متن‌های زیر از این بخش مدیریت می‌شوند.</p>
  <div class="f-grid">
   <div class="f-field full"><label>تیتر اصلی</label><input name="hero_title" maxlength="160" required value="<?= e($V['hero_title']) ?>"></div>
   <div class="f-field full"><label>زیرتیتر</label><input name="hero_subtitle" maxlength="220" required value="<?= e($V['hero_subtitle']) ?>"></div>
  </div>
 </div>
 <div class="panel">
  <h2>کارت‌های خدمات</h2>
  <div class="f-grid">
  <?php foreach((array)$V['features'] as $i=>$f): ?>
   <div class="f-field"><label>عنوان کارت <?= e(fa_num((string)($i+1))) ?></label><input name="feature_title[]" maxlength="100" value="<?= e($f['title']??'') ?>"></div>
   <div class="f-field"><label>توضیح کارت <?= e(fa_num((string)($i+1))) ?></label><input name="feature_subtitle[]" maxlength="120" value="<?= e($f['subtitle']??'') ?>"></div>
  <?php endforeach; ?>
  </div>
 </div>
 <div class="panel">
  <h2>بخش معرفی</h2>
  <div class="f-grid">
   <div class="f-field full"><label>عنوان معرفی</label><input name="about_title" maxlength="120" value="<?= e($V['about_title']) ?>"></div>
   <div class="f-field full"><label>متن معرفی</label><textarea name="about_text" rows="5" maxlength="1200" required><?= e($V['about_text']) ?></textarea></div>
  </div>
 </div>
 <div class="panel">
  <h2>آمار و دستاوردها (اختیاری)</h2>
  <p class="p-desc">هیچ عددی به‌صورت پیش‌فرض نمایش داده نمی‌شود. فقط آمار واقعی و تأییدشده را وارد کنید. اگر هر دو فیلد یک ردیف پر شوند، همان ردیف نمایش داده می‌شود.</p>
  <div class="f-grid">
  <?php for($i=0;$i<4;$i++): $st=$V['stats'][$i]??['value'=>'','label'=>'']; ?>
   <div class="f-field"><label>مقدار <?= e(fa_num((string)($i+1))) ?></label><input name="stat_value[]" maxlength="40" value="<?= e((string)($st['value']??'')) ?>" placeholder="مثلاً ۱۰+"></div>
   <div class="f-field"><label>عنوان <?= e(fa_num((string)($i+1))) ?></label><input name="stat_label[]" maxlength="80" value="<?= e((string)($st['label']??'')) ?>" placeholder="مثلاً سال تجربه"></div>
  <?php endfor; ?>
  </div>
 </div>
 <div class="f-actions"><button class="btn" type="submit">ذخیره محتوای صفحه اصلی</button><a class="btn btn-ghost" href="<?= e(base_url()) ?>" target="_blank" rel="noopener">مشاهده صفحه اصلی</a></div>
</form>
<?php require __DIR__ . '/includes/admin-footer.php'; ?>
