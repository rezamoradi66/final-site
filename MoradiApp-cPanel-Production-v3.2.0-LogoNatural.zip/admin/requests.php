<?php
/**
 * admin/requests.php — مدیریت درخواست‌های دمو
 * مشاهده، جستجو، فیلتر، جزئیات، تغییر وضعیت، یادداشت داخلی، آرشیو و حذف
 */
$adminTitle = 'درخواست‌های دمو';
$adminActive = 'requests';
require_once __DIR__ . '/includes/admin-boot.php';

$pdo = Store::db();
$statusLabels = [
    'new' => 'جدید', 'reviewing' => 'در حال بررسی', 'contacted' => 'تماس گرفته شد',
    'meeting' => 'جلسه تعیین شد', 'completed' => 'تکمیل‌شده', 'cancelled' => 'لغوشده',
];

/* صندوق فایل هنگام اختلال دیتابیس: نمایش و import امن */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'import_fallback') {
    csrf_check();
    $file = basename((string)($_POST['fallback_file'] ?? ''));
    $idx = (int)($_POST['fallback_index'] ?? -1);
    $expectedRef = (string)($_POST['fallback_ref'] ?? '');
    $result = Store::importFallbackRequest($file, $idx, $expectedRef);
    if ($result === 'ok') { log_activity('fallback_request_import', 'بازیابی درخواست fallback: ' . $file . '#' . $idx); flash_set('ok', 'درخواست از صندوق بازیابی و به دیتابیس منتقل شد.'); }
    elseif ($result === 'invalid') { flash_set('err', 'شناسه صندوق نامعتبر است.'); }
    elseif ($result === 'stale') { flash_set('warn', 'فهرست صندوق تغییر کرده است؛ صفحه را تازه‌سازی و دوباره انتخاب کنید.'); }
    else { flash_set('err', 'بازیابی درخواست انجام نشد. وضعیت دیتابیس و صندوق فایل را بررسی کنید.'); }
    redirect('requests.php#fallback');
}

/* ---------- عملیات ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $do = (string)($_POST['do'] ?? '');
    $id = (int)($_POST['id'] ?? 0);
    if ($id > 0) {
        switch ($do) {
            case 'status':
                $new = (string)($_POST['status'] ?? '');
                if (isset($statusLabels[$new])) {
                    $st = $pdo->prepare('UPDATE demo_requests SET status = :s, updated_at = NOW() WHERE id = :id');
                    $st->execute([':s' => $new, ':id' => $id]);
                    log_activity('request_status', 'وضعیت درخواست #' . $id . ' → ' . $statusLabels[$new]);
                    flash_set('ok', 'وضعیت درخواست به «' . $statusLabels[$new] . '» تغییر کرد.');
                }
                break;
            case 'note':
                $note = mb_substr(trim((string)($_POST['internal_note'] ?? '')), 0, 1000);
                $st = $pdo->prepare('UPDATE demo_requests SET internal_note = :n, updated_at = NOW() WHERE id = :id');
                $st->execute([':n' => $note, ':id' => $id]);
                log_activity('request_note', 'ثبت یادداشت داخلی برای درخواست #' . $id);
                flash_set('ok', 'یادداشت داخلی ذخیره شد.');
                break;
            case 'archive':
                $st = $pdo->prepare('UPDATE demo_requests SET archived = IF(archived=1,0,1), updated_at = NOW() WHERE id = :id');
                $st->execute([':id' => $id]);
                log_activity('request_archive', 'تغییر وضعیت آرشیو درخواست #' . $id);
                flash_set('ok', 'وضعیت آرشیو تغییر کرد.');
                break;
            case 'delete':
                $st = $pdo->prepare('DELETE FROM demo_requests WHERE id = :id');
                $st->execute([':id' => $id]);
                log_activity('request_delete', 'حذف درخواست #' . $id);
                flash_set('ok', 'درخواست حذف شد.');
                redirect('requests.php');
                break;
        }
    }
    redirect('requests.php' . ($id ? '?id=' . $id . '#detail' : ''));
}

/* ---------- جزئیات یک درخواست ---------- */
$detail = null;
$detailId = (int)($_GET['id'] ?? 0);
if ($detailId > 0) {
    $st = $pdo->prepare('SELECT * FROM demo_requests WHERE id = :id');
    $st->execute([':id' => $detailId]);
    $detail = $st->fetch() ?: null;
}

/* ---------- فهرست با فیلتر ---------- */
$q = trim((string)($_GET['q'] ?? ''));
$fstatus = (string)($_GET['status'] ?? '');
$farch = (string)($_GET['archived'] ?? '0');
$page = max(1, (int)($_GET['p'] ?? 1));
$perPage = 15;

$where = [];
$params = [];
if ($q !== '') {
    $where[] = '(full_name LIKE :q OR organization LIKE :q OR phone LIKE :q OR email LIKE :q OR product_title LIKE :q)';
    $params[':q'] = '%' . $q . '%';
}
if (isset($statusLabels[$fstatus])) {
    $where[] = 'status = :st';
    $params[':st'] = $fstatus;
}
if ($farch === '1') { $where[] = 'archived = 1'; }
else { $where[] = 'archived = 0'; }
$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$stc = $pdo->prepare("SELECT COUNT(*) c FROM demo_requests $whereSql");
$stc->execute($params);
$total = (int)$stc->fetch()['c'];
$pages = max(1, (int)ceil($total / $perPage));
$page = min($page, $pages);

$stl = $pdo->prepare("SELECT * FROM demo_requests $whereSql ORDER BY id DESC LIMIT :lim OFFSET :off");
foreach ($params as $k => $v) { $stl->bindValue($k, $v); }
$stl->bindValue(':lim', $perPage, PDO::PARAM_INT);
$stl->bindValue(':off', ($page - 1) * $perPage, PDO::PARAM_INT);
$stl->execute();
$rows = $stl->fetchAll();

/* درخواست‌های ذخیره‌شده در صندوق فایل (حالت fallback) */
$fallbackItems = Store::fallbackRequests();
$inboxCount = count($fallbackItems);

/* قالب پنل: پس از پردازش POST (الگوی PRG) */
require __DIR__ . '/includes/admin-header.php';
?>
<?php if ($detail): ?>
<a class="btn btn-ghost btn-sm" href="requests.php" style="margin-bottom:16px">← بازگشت به فهرست</a>
<div class="panel" id="detail">
    <h2>جزئیات درخواست #<?= e(fa_num((string)$detail['id'])) ?></h2>
    <div class="detail-grid">
        <div><div class="dg-l">نام و نام خانوادگی</div><div class="dg-v"><?= e($detail['full_name']) ?></div></div>
        <div><div class="dg-l">سازمان</div><div class="dg-v"><?= e($detail['organization']) ?></div></div>
        <div><div class="dg-l">شماره تماس</div><div class="dg-v" dir="ltr" style="text-align:right"><?= e($detail['phone']) ?></div></div>
        <div><div class="dg-l">ایمیل</div><div class="dg-v" dir="ltr" style="text-align:right"><?= e($detail['email'] ?: '—') ?></div></div>
        <div><div class="dg-l">سامانه موردنظر</div><div class="dg-v"><?= e($detail['product_title']) ?></div></div>
        <div><div class="dg-l">تاریخ ثبت</div><div class="dg-v"><?= e(jdate($detail['created_at'], 'Y/m/d H:i')) ?></div></div>
        <div><div class="dg-l">وضعیت فعلی</div><div class="dg-v"><span class="st st-<?= e($detail['status']) ?>"><?= e($statusLabels[$detail['status']] ?? $detail['status']) ?></span></div></div>
        <div><div class="dg-l">آرشیو</div><div class="dg-v"><?= (int)$detail['archived'] === 1 ? 'بله' : 'خیر' ?></div></div>
    </div>
    <?php if ($detail['message']): ?>
    <div style="margin-top:14px">
        <div class="dg-l" style="color:var(--text-2);font-size:13px">توضیحات کاربر</div>
        <div class="msg-quote"><?= nl2br(e($detail['message'])) ?></div>
    </div>
    <?php endif; ?>

    <div class="f-grid" style="margin-top:20px">
        <div class="f-field">
            <label>تغییر وضعیت</label>
            <form method="post"><?= csrf_field() ?>
                <input type="hidden" name="do" value="status"><input type="hidden" name="id" value="<?= (int)$detail['id'] ?>">
                <div style="display:flex;gap:8px">
                    <select name="status">
                        <?php foreach ($statusLabels as $k => $lbl): ?>
                            <option value="<?= e($k) ?>" <?= $detail['status'] === $k ? 'selected' : '' ?>><?= e($lbl) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button class="btn btn-sm" type="submit">ذخیره وضعیت</button>
                </div>
            </form>
        </div>
        <div class="f-field">
            <label>یادداشت داخلی (فقط برای تیم شما)</label>
            <form method="post"><?= csrf_field() ?>
                <input type="hidden" name="do" value="note"><input type="hidden" name="id" value="<?= (int)$detail['id'] ?>">
                <div style="display:flex;gap:8px;align-items:flex-start">
                    <textarea name="internal_note" maxlength="1000" placeholder="نتیجه تماس، تاریخ جلسه، نکات مهم…"><?= e($detail['internal_note']) ?></textarea>
                    <button class="btn btn-sm" type="submit">ذخیره یادداشت</button>
                </div>
            </form>
        </div>
    </div>

    <div class="f-actions">
        <form method="post" style="display:inline"><?= csrf_field() ?>
            <input type="hidden" name="do" value="archive"><input type="hidden" name="id" value="<?= (int)$detail['id'] ?>">
            <button class="btn btn-ghost btn-sm" type="submit"><?= (int)$detail['archived'] === 1 ? 'خروج از آرشیو' : 'آرشیو کردن' ?></button>
        </form>
        <a class="btn btn-danger btn-sm" href="#"
           data-confirm="این درخواست برای همیشه حذف شود؟"
           data-confirm-title="حذف درخواست"
           data-url="requests.php"
           data-post="do:delete,id:<?= (int)$detail['id'] ?>">حذف درخواست</a>
    </div>
</div>
<?php endif; ?>

<div class="panel" id="fallback">
    <h2>صندوق درخواست‌های بازیابی‌نشده <?php if ($inboxCount): ?><span class="st st-new"><?= e(fa_num((string)$inboxCount)) ?></span><?php endif; ?></h2>
    <p class="p-desc">این درخواست‌ها هنگام قطع/خطای دیتابیس در فایل امن محلی ذخیره شده‌اند. پس از بازگشت دیتابیس، هر درخواست را به جدول اصلی منتقل کنید. import با شناسه یکتا انجام می‌شود تا دوباره ثبت نشود.</p>
    <?php if ($fallbackItems): ?>
    <div class="table-wrap"><table><thead><tr><th>زمان</th><th>نام</th><th>سازمان</th><th>تلفن</th><th>سامانه</th><th>عملیات</th></tr></thead><tbody>
    <?php foreach ($fallbackItems as $fi): $fr=$fi['request']; ?>
    <tr><td><?= e(jdate((string)($fr['created_at']??''),'Y/m/d H:i')) ?></td><td><?= e((string)($fr['full_name']??'')) ?></td><td><?= e((string)($fr['organization']??'')) ?></td><td dir="ltr"><?= e((string)($fr['phone']??'')) ?></td><td><?= e((string)($fr['product_title']??'')) ?></td><td><form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="do" value="import_fallback"><input type="hidden" name="fallback_file" value="<?= e($fi['file']) ?>"><input type="hidden" name="fallback_index" value="<?= (int)$fi['index'] ?>"><input type="hidden" name="fallback_ref" value="<?= e($fi['ref']) ?>"><button class="btn btn-sm" type="submit">بازیابی در دیتابیس</button></form></td></tr>
    <?php endforeach; ?></tbody></table></div>
    <?php else: ?><p class="p-desc">صندوق بازیابی خالی است؛ درخواست معوقی در فایل fallback وجود ندارد.</p><?php endif; ?>
</div>

<div class="panel">
    <div class="tbl-tools">
        <form method="get" style="display:flex;gap:12px;flex-wrap:wrap;align-items:center">
            <input type="search" name="q" value="<?= e($q) ?>" placeholder="جستجو: نام، سازمان، تماس…">
            <select name="status">
                <option value="">همه وضعیت‌ها</option>
                <?php foreach ($statusLabels as $k => $lbl): ?>
                    <option value="<?= e($k) ?>" <?= $fstatus === $k ? 'selected' : '' ?>><?= e($lbl) ?></option>
                <?php endforeach; ?>
            </select>
            <select name="archived">
                <option value="0" <?= $farch === '0' ? 'selected' : '' ?>>فعال (غیرآرشیو)</option>
                <option value="1" <?= $farch === '1' ? 'selected' : '' ?>>آرشیوشده</option>
            </select>
            <button class="btn btn-ghost btn-sm" type="submit">اعمال</button>
        </form>
        <span class="sp"></span>
        <span style="color:var(--text-2);font-size:14px"><?= e(fa_num((string)$total)) ?> درخواست</span>
    </div>

    <?php if ($rows): ?>
    <div class="table-wrap">
        <table class="tbl">
            <tr><th>#</th><th>نام</th><th>سازمان</th><th>تماس</th><th>سامانه</th><th>وضعیت</th><th>تاریخ</th><th>عملیات</th></tr>
            <?php foreach ($rows as $r): ?>
            <tr>
                <td><?= e(fa_num((string)$r['id'])) ?></td>
                <td><b><?= e($r['full_name']) ?></b></td>
                <td><?= e($r['organization']) ?></td>
                <td dir="ltr" style="text-align:right"><?= e($r['phone']) ?></td>
                <td><?= e($r['product_title']) ?></td>
                <td><span class="st st-<?= e($r['status']) ?>"><?= e($statusLabels[$r['status']] ?? $r['status']) ?></span></td>
                <td><?= e(jdate($r['created_at'])) ?></td>
                <td class="actions"><a class="btn btn-ghost btn-sm" href="requests.php?id=<?= (int)$r['id'] ?>">جزئیات</a></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
    <?php if ($pages > 1): ?>
    <div class="pager">
        <?php for ($i = 1; $i <= $pages; $i++): $qs = http_build_query(array_filter(['q' => $q, 'status' => $fstatus, 'archived' => $farch, 'p' => $i])); ?>
            <?php if ($i === $page): ?><span class="cur"><?= e(fa_num((string)$i)) ?></span>
            <?php else: ?><a href="requests.php?<?= e($qs) ?>"><?= e(fa_num((string)$i)) ?></a><?php endif; ?>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
    <?php else: ?>
    <p class="p-desc">درخواستی در این فیلتر یافت نشد. پس از ثبت فرم دمو در سایت، درخواست‌ها به‌صورت خودکار اینجا ظاهر می‌شوند.</p>
    <?php endif; ?>
</div>

<?php if ($inboxCount > 0): ?>
<div class="flash warn">
    <?= e(fa_num((string)$inboxCount)) ?> درخواست قدیمی در «صندوق فایلی» (حالت قبل از نصب دیتابیس) موجود است.
    پس از نصب پنل و ساخت جدول درخواست‌ها، این موارد را می‌توانید از مسیر data/inbox به‌صورت دستی وارد کنید؛ جزئیات در راهنمای مدیریت آمده است.
</div>
<?php endif; ?>

<?php require __DIR__ . '/includes/admin-footer.php'; ?>
