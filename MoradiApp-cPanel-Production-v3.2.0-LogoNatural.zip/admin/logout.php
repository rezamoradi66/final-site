<?php
/** خروج فقط با POST و توکن CSRF */
require_once __DIR__ . '/includes/auth.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); header('Allow: POST'); exit('Method Not Allowed'); }
csrf_check();
admin_logout();
