<?php
/**
 * admin/media.php — کتابخانه رسانه‌ها
 * آپلود امن: بررسی پسوند + MIME واقعی (finfo) + getimagesize + نام تصادفی
 * اجرای PHP در پوشه آپلود از طریق uploads/.htaccess مطلقاً مسدود است.
 */
$adminTitle = 'رسانه‌ها';
$adminActive = 'media';
require_once __DIR__ . '/includes/admin-boot.php';

$pdo = Store::db();
$allowedExt = (array)cfg('uploads.allowed', ['jpg', 'jpeg', 'png', 'webp', 'gif']);
$allowedMime = [
    'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png',
    'webp' => 'image/webp', 'gif' => 'image/gif',
];
$maxBytes = ((int)cfg('uploads.max_size_mb', 4)) * 1048576;
$uploadRoot = UPLOAD_DIR . '/media';

function ensure_upload_dir(string $dir): string
{
    $sub = $dir . '/' . date('Ym');
    if (!is_dir($sub)) { @mkdir($sub, 0755, true); }
    return is_dir($sub) ? $sub : $dir;
}

/* ---------- فهرست JSON برای انتخاب‌گر ---------- */
if (($_GET['action'] ?? '') === 'list') {
    header('Content-Type: application/json; charset=utf-8');
    $items = [];
    try {
        $rows = $pdo->query('SELECT id, filename, original_name, width, height FROM media ORDER BY id DESC LIMIT 200')->fetchAll();
        foreach ($rows as $r) {
            $path = (string)$r['filename']; /* مسیر نسبی از ریشه سایت */
            if (!preg_match('#^uploads/media/[A-Za-z0-9/_-]+\.(?:jpg|jpeg|png|webp|gif)$#i', $path) || str_contains($path, '..')) { continue; }
            if (!is_file(APP_ROOT . '/' . $path)) { continue; }
            $items[] = [
                'id' => (int)$r['id'],
                'filename' => mb_substr((string)($r['original_name'] ?: basename($r['filename'])), 0, 250),
                'path' => $path,
                'url' => base_url($path),
            ];
        }
    } catch (Throwable $ex) { @error_log('[MEDIA-LIST] ' . $ex->getMessage()); }
    echo json_encode(['ok' => true, 'items' => $items], JSON_UNESCAPED_UNICODE);
    exit;
}

/* ---------- آپلود ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'upload') {
    csrf_check();
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        flash_set('err', 'فایلی دریافت نشد یا آپلود ناقص بود. (حجم فایل ممکن است از حد مجاز PHP بیشتر باشد)');
        redirect('media.php');
    }
    $file = $_FILES['file'];
    if ($file['size'] <= 0 || $file['size'] > $maxBytes) {
        flash_set('err', 'حجم فایل باید بین ۱ کیلوبایت تا ' . fa_num((string)cfg('uploads.max_size_mb', 4)) . ' مگابایت باشد.');
        redirect('media.php');
    }
    $ext = strtolower(pathinfo((string)$file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExt, true) || !isset($allowedMime[$ext])) {
        flash_set('err', 'فرمت مجاز نیست. فقط: ' . e(implode('، ', $allowedExt)));
        redirect('media.php');
    }
    /* MIME واقعی فایل را بررسی کن — پسوند به‌تنهایی ملاک نیست */
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = (string)$finfo->file($file['tmp_name']);
    if ($mime !== $allowedMime[$ext]) {
        flash_set('err', 'محتوای فایل با فرمت اعلام‌شده هم‌خوان نیست.');
        redirect('media.php');
    }
    $dim = @getimagesize($file['tmp_name']);
    if ($dim === false) {
        flash_set('err', 'فایل معتبر تصویر نیست.');
        redirect('media.php');
    }
    $w = (int)$dim[0]; $h = (int)$dim[1];
    if ($w < 1 || $h < 1 || $w > 7000 || $h > 7000 || ($w * $h) > 12000000) {
        flash_set('err', 'ابعاد تصویر بیش از حد مجاز است (حداکثر ۷۰۰۰×۷۰۰۰ و ۱۲ مگاپیکسل).');
        redirect('media.php');
    }
    if (!function_exists('imagecreatefromstring')) {
        flash_set('err', 'افزونه GD برای پردازش امن تصویر روی هاست فعال نیست.');
        redirect('media.php');
    }
    $imgData = @file_get_contents($file['tmp_name']);
    $image = $imgData !== false ? @imagecreatefromstring($imgData) : false;
    if (!$image) { flash_set('err', 'رمزگشایی تصویر ناموفق بود.'); redirect('media.php'); }
    /* Re-encode decoded pixels to strip polyglot payloads/metadata. GIF is flattened to one frame. */
    $cleanTmp = tempnam(sys_get_temp_dir(), 'moradi_img_');
    if ($cleanTmp === false) { imagedestroy($image); flash_set('err', 'ایجاد فایل موقت تصویر ناموفق بود.'); redirect('media.php'); }
    $saved = false;
    if ($ext === 'jpg' || $ext === 'jpeg') { $saved = imagejpeg($image, $cleanTmp, 88); }
    elseif ($ext === 'png') { imagealphablending($image, false); imagesavealpha($image, true); $saved = imagepng($image, $cleanTmp, 6); }
    elseif ($ext === 'webp' && function_exists('imagewebp')) { $saved = imagewebp($image, $cleanTmp, 85); }
    elseif ($ext === 'gif') { $saved = imagegif($image, $cleanTmp); }
    imagedestroy($image); unset($imgData);
    if (!$saved || !is_file($cleanTmp) || filesize($cleanTmp) <= 0) { @unlink($cleanTmp); flash_set('err', 'بازرمزگذاری تصویر ناموفق بود.'); redirect('media.php'); }
    $dir = ensure_upload_dir($uploadRoot);
    $relSub = str_replace(APP_ROOT . '/', '', $dir);
    $newName = date('Ymd_His') . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
    $fullPath = $dir . '/' . $newName;
    if (!@copy($cleanTmp, $fullPath)) { @unlink($cleanTmp);
        flash_set('err', 'ذخیره فایل ناموفق بود؛ مجوز پوشه uploads را بررسی کنید.');
        redirect('media.php');
    }
    @unlink($cleanTmp);
    @chmod($fullPath, 0644);
    try {
        $st = $pdo->prepare('INSERT INTO media (filename, original_name, alt_text, mime_type, file_size, width, height, created_at)
                             VALUES (:fn, :on, :alt, :mime, :size, :w, :h, NOW())');
        $st->execute([
            ':fn' => $relSub . '/' . $newName,
            ':on' => mb_substr((string)$file['name'], 0, 250),
            ':alt' => mb_substr(trim((string)($_POST['alt'] ?? '')), 0, 250),
            ':mime' => $mime,
            ':size' => (int)filesize($fullPath),
            ':w' => $w, ':h' => $h,
        ]);
    } catch (Throwable $ex) {
        @unlink($fullPath); @error_log('[MEDIA-DB] '.$ex->getMessage());
        flash_set('err', 'ثبت تصویر در کتابخانه ناموفق بود؛ فایل موقت پاک شد.'); redirect('media.php');
    }
    log_activity('media_upload', 'آپلود تصویر: ' . (string)$file['name']);
    flash_set('ok', 'تصویر با موفقیت آپلود شد.');
    redirect('media.php');
}

/* ---------- حذف ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'delete') {
    csrf_check();
    $mid = (int)($_POST['id'] ?? 0);
    $st = $pdo->prepare('SELECT filename FROM media WHERE id = :id');
    $st->execute([':id' => $mid]);
    $row = $st->fetch();
    if ($row) {
        $full = APP_ROOT . '/' . $row['filename'];
        if (is_file($full)) { @unlink($full); }
        $st2 = $pdo->prepare('DELETE FROM media WHERE id = :id');
        $st2->execute([':id' => $mid]);
        log_activity('media_delete', 'حذف تصویر: ' . $row['filename']);
        flash_set('ok', 'تصویر حذف شد.');
    }
    redirect('media.php');
}

$rows = $pdo->query('SELECT id, filename, original_name, alt_text, file_size, width, height, created_at FROM media ORDER BY id DESC')->fetchAll();

/* قالب پنل: پس از پردازش POST (الگوی PRG) */
require __DIR__ . '/includes/admin-header.php';
?>
<div class="panel">
    <h2>آپلود تصویر جدید</h2>
    <p class="p-desc">فرمت‌های مجاز: <?= e(implode('، ', $allowedExt)) ?> — حداکثر حجم: <?= e(fa_num((string)cfg('uploads.max_size_mb', 4))) ?> مگابایت. فایل‌های اجرایی به‌هیچ‌وجه پذیرفته نمی‌شوند.</p>
    <form method="post" enctype="multipart/form-data" data-validate>
        <?= csrf_field() ?>
        <input type="hidden" name="do" value="upload">
        <div class="dropzone">
            <b>تصویر را اینجا رها کنید یا کلیک کنید</b>
            <div class="dz-name" style="margin-top:6px">JPG، PNG، WebP یا GIF</div>
        </div>
        <input type="file" id="mediaFile" name="file" accept=".jpg,.jpeg,.png,.webp,.gif" required style="position:absolute;opacity:0;width:1px;height:1px">
        <div class="f-grid">
            <div class="f-field">
                <label>متن جایگزین (Alt) — برای سئو</label>
                <input type="text" name="alt" maxlength="250" placeholder="توضیح کوتاه تصویر">
            </div>
            <div class="f-field" style="justify-content:flex-end">
                <button class="btn" type="submit">آپلود تصویر</button>
            </div>
        </div>
    </form>
</div>

<div class="panel">
    <h2>تصاویر آپلودشده</h2>
    <?php if ($rows): ?>
    <div class="media-grid">
        <?php foreach ($rows as $r): ?>
        <div class="media-item">
            <img src="<?= e(base_url($r['filename'])) ?>" alt="<?= e($r['alt_text']) ?>" loading="lazy">
            <div class="mi-meta" title="<?= e($r['original_name']) ?>"><?= e($r['original_name'] ?: basename($r['filename'])) ?></div>
            <div class="mi-meta" style="opacity:.7"><?= e(fa_num((string)(round(((int)$r['file_size']) / 1024)))) ?> KB · <?= e(fa_num((string)$r['width'])) ?>×<?= e(fa_num((string)$r['height'])) ?> · <?= e(jdate($r['created_at'])) ?></div>
            <div class="mi-actions">
                <a class="btn btn-ghost btn-sm" href="<?= e(base_url($r['filename'])) ?>" target="_blank" rel="noopener">مشاهده</a>
                <a class="btn btn-danger btn-sm" href="#"
                   data-confirm="تصویر «<?= e($r['original_name'] ?: basename($r['filename'])) ?>» حذف شود؟ اگر در محصولی استفاده شده باشد، تصویر آن خالی خواهد شد."
                   data-confirm-title="حذف تصویر"
                   data-url="media.php"
                   data-post="do:delete,id:<?= (int)$r['id'] ?>">حذف</a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <p class="p-desc">هنوز تصویری آپلود نشده است. تصاویر نمونه محصولات، داخل بسته پروژه موجود است و مستقیماً در فرم محصول قابل استفاده‌اند.</p>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/admin-footer.php'; ?>
