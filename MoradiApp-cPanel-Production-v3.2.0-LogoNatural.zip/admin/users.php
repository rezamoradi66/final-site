<?php
/**
 * admin/users.php — مدیریت کاربران مدیریتی
 * ایجاد، فعال/غیرفعال، تغییر رمز، حذف (با محافظت خودکار: آخرین مدیر فعال حذف نمی‌شود)
 */
$adminTitle = 'کاربران مدیر';
$adminActive = 'users';
require_once __DIR__ . '/includes/admin-boot.php';

$pdo = Store::db();
$selfId = admin_id();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $do = (string)($_POST['do'] ?? '');
    $id = (int)($_POST['id'] ?? 0);

    if ($do === 'create') {
        $username = trim((string)($_POST['username'] ?? ''));
        $email = trim((string)($_POST['email'] ?? ''));
        $fullName = trim((string)($_POST['full_name'] ?? ''));
        $pass = (string)($_POST['password'] ?? '');
        $pass2 = (string)($_POST['password2'] ?? '');
        $role = ($_POST['role'] ?? '') === 'manager' ? 'manager' : 'admin';

        $errors = [];
        if (!preg_match('/^[a-zA-Z0-9_\.\-]{4,60}$/', $username)) { $errors[] = 'نام کاربری باید ۴ تا ۶۰ کاراکتر انگلیسی/عدد/خط تیره باشد.'; }
        if ($email !== '' && !valid_email($email)) { $errors[] = 'ایمیل معتبر نیست.'; }
        if (mb_strlen($fullName) < 3 || mb_strlen($fullName) > 120) { $errors[] = 'نام کامل را وارد کنید.'; }
        if (mb_strlen($pass) < 12 || strlen($pass) > 72 || !preg_match('/[A-Za-z]/', $pass) || !preg_match('/[0-9]/', $pass)) {
            $errors[] = 'رمز عبور باید ۱۲ تا ۷۲ بایت، شامل حرف و عدد باشد.';
        }
        if ($pass !== $pass2) { $errors[] = 'تکرار رمز عبور مطابقت ندارد.'; }

        $exists = false;
        if (!$errors) {
            $st = $pdo->prepare('SELECT COUNT(*) c FROM admin_users WHERE username = :u');
            $st->execute([':u' => $username]);
            $exists = (int)$st->fetch()['c'] > 0;
        }
        if ($exists) { $errors[] = 'این نام کاربری قبلاً ثبت شده است.'; }

        if ($errors) {
            flash_set('err', implode(' ', $errors));
        } else {
            $st = $pdo->prepare('INSERT INTO admin_users (username, email, full_name, password_hash, role, is_active, created_at)
                                 VALUES (:u, :e, :fn, :ph, :r, 1, NOW())');
            $st->execute([':u' => $username, ':e' => $email, ':fn' => $fullName,
                          ':ph' => password_hash($pass, PASSWORD_DEFAULT), ':r' => $role]);
            log_activity('user_create', 'ایجاد کاربر مدیر: ' . $username);
            flash_set('ok', 'کاربر مدیر جدید ایجاد شد.');
        }
        redirect('users.php');
    }

    if ($do === 'toggle' && $id > 0 && $id !== $selfId) {
        /* محافظت: آخرین مدیر فعال غیرفعال نمی‌شود */
        $st = $pdo->query("SELECT COUNT(*) c FROM admin_users WHERE is_active = 1");
        $activeCount = (int)$st->fetch()['c'];
        $st2 = $pdo->prepare('SELECT is_active FROM admin_users WHERE id = :id');
        $st2->execute([':id' => $id]);
        $cur = $st2->fetch();
        if ($cur && (int)$cur['is_active'] === 1 && $activeCount <= 1) {
            flash_set('err', 'حداقل یک مدیر فعال باید وجود داشته باشد.');
        } else {
            $pdo->prepare('UPDATE admin_users SET is_active = IF(is_active=1,0,1) WHERE id = :id')->execute([':id' => $id]);
            log_activity('user_toggle', 'تغییر وضعیت فعال بودن کاربر #' . $id);
            flash_set('ok', 'وضعیت کاربر تغییر کرد.');
        }
        redirect('users.php');
    }

    if ($do === 'resetpass' && $id > 0) {
        $pass = (string)($_POST['password'] ?? '');
        $pass2 = (string)($_POST['password2'] ?? '');
        if (mb_strlen($pass) < 12 || strlen($pass) > 72 || !preg_match('/[A-Za-z]/', $pass) || !preg_match('/[0-9]/', $pass) || $pass !== $pass2) {
            flash_set('err', 'رمز جدید باید ۱۲ تا ۷۲ بایت، شامل حرف و عدد باشد و با تکرارش یکی باشد.');
        } else {
            $pdo->prepare('UPDATE admin_users SET password_hash = :p, failed_attempts = 0, locked_until = NULL WHERE id = :id')
                ->execute([':p' => password_hash($pass, PASSWORD_DEFAULT), ':id' => $id]);
            log_activity('user_resetpass', 'بازنشانی رمز عبور کاربر #' . $id);
            flash_set('ok', 'رمز عبور بازنشانی شد.');
        }
        redirect('users.php');
    }

    if ($do === 'delete' && $id > 0 && $id !== $selfId) {
        $st = $pdo->prepare('SELECT COUNT(*) c FROM admin_users WHERE is_active = 1 AND id <> :id');
        $st->execute([':id' => $id]);
        if ((int)$st->fetch()['c'] < 1) {
            flash_set('err', 'حداقل یک مدیر فعال باید باقی بماند.');
        } else {
            $pdo->prepare('DELETE FROM admin_users WHERE id = :id')->execute([':id' => $id]);
            log_activity('user_delete', 'حذف کاربر مدیر #' . $id);
            flash_set('ok', 'کاربر حذف شد.');
        }
        redirect('users.php');
    }
    redirect('users.php');
}

$rows = $pdo->query('SELECT id, username, email, full_name, role, is_active, last_login, created_at FROM admin_users ORDER BY id ASC')->fetchAll();

/* قالب پنل: پس از پردازش POST (الگوی PRG) */
require __DIR__ . '/includes/admin-header.php';
?>
<div class="panel">
    <h2>افزودن کاربر مدیر</h2>
    <form method="post" data-validate>
        <?= csrf_field() ?>
        <input type="hidden" name="do" value="create">
        <div class="f-grid">
            <div class="f-field">
                <label>نام کاربری <span class="req">*</span></label>
                <input type="text" name="username" maxlength="60" required dir="ltr" style="text-align:left" placeholder="admin2">
            </div>
            <div class="f-field">
                <label>نام کامل <span class="req">*</span></label>
                <input type="text" name="full_name" maxlength="120" required>
            </div>
            <div class="f-field">
                <label>ایمیل</label>
                <input type="email" name="email" maxlength="150" dir="ltr" style="text-align:left">
            </div>
            <div class="f-field">
                <label>نقش</label>
                <select name="role">
                    <option value="admin">مدیر کامل</option>
                    <option value="manager">مدیر محتوا</option>
                </select>
            </div>
            <div class="f-field">
                <label>رمز عبور <span class="req">*</span></label>
                <input type="password" name="password" maxlength="72" required autocomplete="new-password">
                <span class="hint">حداقل ۱۰ کاراکتر شامل حرف و عدد. پس از ثبت قابل مشاهده نیست و فقط هش آن ذخیره می‌شود.</span>
            </div>
            <div class="f-field">
                <label>تکرار رمز عبور <span class="req">*</span></label>
                <input type="password" name="password2" maxlength="72" required autocomplete="new-password">
            </div>
            <div class="f-actions full"><button class="btn" type="submit">ایجاد کاربر</button></div>
        </div>
    </form>
</div>

<div class="panel">
    <h2>کاربران فعلی</h2>
    <div class="table-wrap">
        <table class="tbl">
            <tr><th>نام کاربری</th><th>نام</th><th>نقش</th><th>وضعیت</th><th>آخرین ورود</th><th>عملیات</th></tr>
            <?php foreach ($rows as $r): ?>
            <tr>
                <td dir="ltr" style="text-align:right"><b><?= e($r['username']) ?></b><?= (int)$r['id'] === $selfId ? ' <span class="st st-new">شما</span>' : '' ?></td>
                <td><?= e($r['full_name']) ?></td>
                <td><?= $r['role'] === 'admin' ? 'مدیر کامل' : 'مدیر محتوا' ?></td>
                <td><span class="st st-<?= (int)$r['is_active'] === 1 ? 'active' : 'inactive' ?>"><?= (int)$r['is_active'] === 1 ? 'فعال' : 'غیرفعال' ?></span></td>
                <td><?= e($r['last_login'] ? jdate($r['last_login'], 'Y/m/d H:i') : '—') ?></td>
                <td class="actions">
                    <?php if ((int)$r['id'] !== $selfId): ?>
                        <form method="post" style="display:inline"><?= csrf_field() ?>
                            <input type="hidden" name="do" value="toggle"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                            <button class="btn btn-ghost btn-sm"><?= (int)$r['is_active'] === 1 ? 'غیرفعال کن' : 'فعال کن' ?></button>
                        </form>
                        <a class="btn btn-danger btn-sm" href="#"
                           data-confirm="کاربر «<?= e($r['username']) ?>» حذف شود؟"
                           data-confirm-title="حذف کاربر مدیر"
                           data-url="users.php"
                           data-post="do:delete,id:<?= (int)$r['id'] ?>">حذف</a>
                    <?php else: ?>
                        <span style="color:var(--text-2);font-size:13px">برای تغییر رمز خود از فرم زیر استفاده کنید.</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
</div>

<div class="panel">
    <h2>بازنشانی رمز عبور</h2>
    <p class="p-desc">برای بازنشانی رمز هر کاربر، نام کاربری را انتخاب و رمز جدید را دو بار وارد کنید.</p>
    <form method="post" data-validate>
        <?= csrf_field() ?>
        <input type="hidden" name="do" value="resetpass">
        <div class="f-grid">
            <div class="f-field">
                <label>کاربر</label>
                <select name="id">
                    <?php foreach ($rows as $r): ?>
                        <option value="<?= (int)$r['id'] ?>"><?= e($r['full_name'] . ' — ' . $r['username']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="f-field">
                <label>رمز جدید <span class="req">*</span></label>
                <input type="password" name="password" maxlength="72" required autocomplete="new-password">
            </div>
            <div class="f-field">
                <label>تکرار رمز جدید <span class="req">*</span></label>
                <input type="password" name="password2" maxlength="72" required autocomplete="new-password">
            </div>
            <div class="f-actions full"><button class="btn" type="submit">بازنشانی رمز</button></div>
        </div>
    </form>
</div>

<?php require __DIR__ . '/includes/admin-footer.php'; ?>
