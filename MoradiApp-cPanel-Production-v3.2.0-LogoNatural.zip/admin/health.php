<?php
$adminTitle = 'سلامت سامانه'; $adminActive = 'health';
require_once __DIR__ . '/includes/admin-boot.php';
$checks=[];
$checks['اتصال دیتابیس']=[Store::dbMode(), Store::dbMode()?'اتصال برقرار است':'اتصال برقرار نیست'];
$checks['PHP GD']=[extension_loaded('gd')&&function_exists('imagecreatefromstring'), extension_loaded('gd')?'فعال':'غیرفعال'];
$checks['PHP mbstring']=[extension_loaded('mbstring'), extension_loaded('mbstring')?'فعال':'غیرفعال'];
$checks['PHP zlib']=[extension_loaded('zlib')&&function_exists('gzopen'), extension_loaded('zlib')?'فعال':'غیرفعال'];
foreach ([DATA_DIR,CONFIG_DIR,UPLOAD_DIR.'/media',LOG_DIR] as $dir) $checks['دسترسی نوشتن: '.basename($dir)]=[is_dir($dir)&&is_writable($dir),is_dir($dir)&&is_writable($dir)?'قابل نوشتن':'غیرقابل نوشتن'];
$checks['HTTPS']=[is_https(),is_https()?'فعال':'غیرفعال'];
$fallback=count(Store::fallbackRequests());
$backupFiles=glob(DATA_DIR.'/backups/moradiapp-*.sql.gz')?:[]; usort($backupFiles,fn($a,$b)=>filemtime($b)<=>filemtime($a));
$backupAge=$backupFiles?time()-filemtime($backupFiles[0]):null;
$backupLabel=$backupAge===null?'بکاپی ثبت نشده':jdate(date('Y-m-d H:i:s',filemtime($backupFiles[0])),'Y/m/d H:i').' — '.fa_num((string)floor($backupAge/3600)).' ساعت قبل';
$checks['آخرین بکاپ دیتابیس']=[$backupAge!==null&&$backupAge<48*3600,$backupLabel];
require __DIR__ . '/includes/admin-header.php';
?>
<div class="panel"><h2>سلامت و آمادگی عملیاتی</h2><p class="p-desc">این صفحه فقط برای مدیران قابل دسترسی است و اطلاعات محرمانهٔ اتصال را نمایش نمی‌دهد.</p><div class="tbl-tools"><table><thead><tr><th>بررسی</th><th>وضعیت</th><th>توضیح</th></tr></thead><tbody><?php foreach($checks as $name=>$check): ?><tr><td><?=e($name)?></td><td><span class="st <?=$check[0]?'st-completed':'st-new'?>"><?=$check[0]?'OK':'نیازمند بررسی'?></span></td><td><?=e($check[1])?></td></tr><?php endforeach; ?><tr><td>صندوق درخواست fallback</td><td><span class="st <?=$fallback?'st-new':'st-completed'?>"><?=e(fa_num((string)$fallback))?></span></td><td><?=$fallback?'درخواست معوق برای بازیابی وجود دارد':'صندوق خالی است'?></td></tr></tbody></table></div></div>
<?php require __DIR__ . '/includes/admin-footer.php'; ?>
