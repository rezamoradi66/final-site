<?php
/**
 * admin/login.php — صفحه ورود امن مدیر سایت
 */
require_once __DIR__ . '/includes/auth.php';

/* اگر وارد شده، به داشبورد برو */
if (!empty($_SESSION['admin'])) { redirect(base_url('admin/index.php')); }

require_once dirname(__DIR__) . '/includes/icons.php';
$brand = Store::settings('brand_name') ?: 'مرادی‌اپ';
$logo = Store::settings('logo_image');
$error = '';
$mfaRequired = !empty($_SESSION['mfa_pending']) && (int)($_SESSION['mfa_pending']['expires'] ?? 0) >= time();
if (!empty($_SESSION['mfa_pending']) && !$mfaRequired) { unset($_SESSION['mfa_pending']); }

if (!Store::dbMode()) {
    redirect(base_url('install.php'));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    if (($_POST['do'] ?? '') === 'verify_totp' && $mfaRequired) {
        if (complete_totp_login(trim((string)($_POST['totp_code'] ?? '')))) { redirect(base_url('admin/index.php')); }
        $error = 'کد یک‌بارمصرف معتبر نیست یا منقضی شده است.';
    } else {
        $username = trim((string)($_POST['username'] ?? ''));
        $password = (string)($_POST['password'] ?? '');
        if ($username === '' || $password === '') { $error = 'نام کاربری و رمز عبور را وارد کنید.'; }
        elseif (mb_strlen($username) > 60 || mb_strlen($password) > 200) { $error = 'اطلاعات ورود نامعتبر است.'; }
        else {
            [$ok, $msg] = attempt_login($username, $password);
            if ($ok) { redirect(base_url('admin/index.php')); }
            $mfaRequired = ($msg === 'mfa_required');
            $error = $mfaRequired ? '' : $msg;
        }
    }
}
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ورود مدیر | <?= e($brand) ?></title>
<meta name="robots" content="noindex, nofollow">
<link rel="icon" type="image/svg+xml" href="<?= base_url('assets/images/brand/favicon.png') ?>">
<link rel="stylesheet" href="<?= asset_url('admin/assets/admin.css') ?>">
<link rel="stylesheet" href="<?= asset_url('assets/css/approved-fonts.css') ?>">
</head>
<body>
<div class="login-page">
    <div class="login-box">
        <div class="lb-brand">
            <?php if ($logo): ?>
                <img src="<?= e(base_url($logo)) ?>" alt="لوگو" width="40" height="40">
            <?php else: ?>
                <?= brand_logo_svg('40') ?>
            <?php endif; ?>
            <span>
                <h1>پنل مدیریت <?= e($brand) ?></h1>
            </span>
        </div>
        <div class="lb-sub">برای مدیریت سامانه‌ها، محتوا و درخواست‌ها وارد شوید.</div>

        <?php if ($error): ?><div class="flash err"><?= e($error) ?></div><?php endif; ?>

        <form method="post" data-validate>
            <?= csrf_field() ?>
            <?php if ($mfaRequired): ?>
                <input type="hidden" name="do" value="verify_totp">
                <div class="f-field"><label for="totp">کد ۶ رقمی برنامه Authenticator</label><input id="totp" type="text" name="totp_code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" required autocomplete="one-time-code" autofocus></div>
                <div class="f-actions"><button class="btn btn-block" type="submit">تأیید و ورود</button></div>
                <div class="login-note">مرحله دوم ورود فعال است. این کد هر ۳۰ ثانیه تغییر می‌کند.</div>
            <?php else: ?>
                <div class="f-field"><label for="lu">نام کاربری <span class="req">*</span></label><input id="lu" type="text" name="username" required maxlength="60" autocomplete="username" autofocus></div>
                <div class="f-field"><label for="lp">رمز عبور <span class="req">*</span></label><input id="lp" type="password" name="password" required maxlength="200" autocomplete="current-password"></div>
                <div class="f-actions"><button class="btn btn-block" type="submit">ورود به پنل مدیریت</button></div>
            <?php endif; ?>
        </form>
        <div class="login-note"><?= icon('lock') ?> دسترسی به این بخش فقط برای مدیران مجاز است. اطلاعات ورود شما هش‌شده ذخیره می‌شود.</div>
        <div class="login-note" style="justify-content:center"><a href="<?= base_url() ?>"><?= icon('arrow') ?> بازگشت به سایت</a></div>
    </div>
</div>
</body>
</html>
