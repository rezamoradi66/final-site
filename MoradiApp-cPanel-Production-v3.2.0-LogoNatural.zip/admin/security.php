<?php
$adminTitle='امنیت ورود';$adminActive='security';require_once __DIR__.'/includes/admin-boot.php';
$pdo=Store::db();$error='';$success='';$schemaReady=true;
try {
    $cols=$pdo->query("SHOW COLUMNS FROM admin_users LIKE 'totp_secret'")->fetchAll();
    if(!$cols){$pdo->exec('ALTER TABLE admin_users ADD COLUMN totp_secret VARCHAR(255) NULL');} else { $col=$cols[0]; if (preg_match('/varchar\((\d+)\)/i',(string)($col['Type']??''),$m) && (int)$m[1] < 255) { $pdo->exec('ALTER TABLE admin_users MODIFY COLUMN totp_secret VARCHAR(255) NULL'); } }
    $cols=$pdo->query("SHOW COLUMNS FROM admin_users LIKE 'totp_enabled'")->fetchAll();
    if(!$cols){$pdo->exec('ALTER TABLE admin_users ADD COLUMN totp_enabled TINYINT(1) NOT NULL DEFAULT 0');}
} catch(Throwable $ex){@error_log('[TOTP-MIGRATION] '.$ex->getMessage());$schemaReady=false;$error='به‌روزرسانی ساختار دیتابیس برای MFA انجام نشد؛ مجوز ALTER TABLE را بررسی کنید.';}
$me=[]; if($schemaReady){$st=$pdo->prepare('SELECT id,username,totp_secret,totp_enabled FROM admin_users WHERE id=:id');$st->execute([':id'=>admin_id()]);$me=$st->fetch()?:[];}
if($schemaReady && $_SERVER['REQUEST_METHOD']==='POST' && (string)($_POST['do']??'')==='generate_mfa_key'){
 csrf_check();
 if(preg_match('/^[a-f0-9]{64}$/i',(string)cfg('security.mfa_encryption_key',''))){$error='کلید رمزنگاری MFA قبلاً تنظیم شده است؛ برای تغییر آن ابتدا MFA همه مدیران را بازنشانی کنید.';}
 else {
  try {
   $configPath=CONFIG_DIR.'/config.php';$config=require $configPath;if(!is_array($config))throw new RuntimeException('Invalid config');
   if(!isset($config['security'])||!is_array($config['security']))$config['security']=[];
   $config['security']['mfa_encryption_key']=bin2hex(random_bytes(32));
   $tmp=$configPath.'.tmp-'.bin2hex(random_bytes(5));$contents="<?php\nreturn ".var_export($config,true).";\n";
   if(@file_put_contents($tmp,$contents,LOCK_EX)!==strlen($contents)||!@chmod($tmp,0600)||!@rename($tmp,$configPath)){@unlink($tmp);throw new RuntimeException('Cannot securely update config');}
   @chmod(CONFIG_DIR,0700);$GLOBALS['APP_CONFIG']=$config;log_activity('mfa_key_generate','تولید و ذخیره کلید مستقل رمزنگاری MFA');flash_set('ok','کلید مستقل MFA با مجوز خصوصی در config ذخیره شد. اکنون می‌توانید MFA را راه‌اندازی کنید.');redirect('security.php');
  } catch(Throwable $ex){@error_log('[MFA-KEY] '.$ex->getMessage());$error='ذخیره کلید رمزنگاری MFA ناموفق بود؛ مجوز خصوصی config را بررسی کنید.';}
 }
}
if($schemaReady && $_SERVER['REQUEST_METHOD']==='POST'){
 csrf_check();$do=(string)($_POST['do']??'');
 if($do==='generate' && empty($me['totp_enabled'])){
  if(!preg_match('/^[a-f0-9]{64}$/i',(string)cfg('security.mfa_encryption_key',''))){$error='ابتدا کلید مستقل رمزنگاری MFA را در همین صفحه ایجاد کنید.';} else {
  $secret=totp_base32_encode(random_bytes(20));$stored=mfa_encrypt_secret($secret);$st=$pdo->prepare('UPDATE admin_users SET totp_secret=:s,totp_enabled=0 WHERE id=:id');$st->execute([':s'=>$stored,':id'=>admin_id()]);log_activity('totp_generate','تولید کلید راه‌اندازی MFA');flash_set('ok','کلید جدید تولید شد؛ آن را در برنامه Authenticator ثبت و سپس کد را تأیید کنید.');redirect('security.php');
  }
 }
 if($do==='enable' && !empty($me['totp_secret']) && empty($me['totp_enabled'])){
  if(totp_verify(mfa_decrypt_secret((string)$me['totp_secret']),trim((string)($_POST['code']??'')))){$pdo->prepare('UPDATE admin_users SET totp_enabled=1 WHERE id=:id')->execute([':id'=>admin_id()]);log_activity('totp_enable','فعال‌سازی MFA');flash_set('ok','احراز هویت دومرحله‌ای فعال شد.');redirect('security.php');}
  $error='کد تأیید نادرست است؛ ساعت تلفن را همگام کنید.';
 }
 if($do==='disable' && !empty($me['totp_enabled'])){
  if(totp_verify(mfa_decrypt_secret((string)$me['totp_secret']),trim((string)($_POST['code']??'')))){$pdo->prepare('UPDATE admin_users SET totp_enabled=0,totp_secret=NULL WHERE id=:id')->execute([':id'=>admin_id()]);log_activity('totp_disable','غیرفعال‌سازی MFA');flash_set('ok','احراز هویت دومرحله‌ای غیرفعال شد.');redirect('security.php');}
  $error='برای غیرفعال‌سازی، کد فعلی Authenticator را وارد کنید.';
 }
}
$enabled=!empty($me['totp_enabled']);$secret=mfa_decrypt_secret((string)($me['totp_secret']??''));$uri=$secret?'otpauth://totp/MoradiApp:'.rawurlencode((string)$me['username']).'?secret='.$secret.'&issuer=MoradiApp&algorithm=SHA1&digits=6&period=30':'';
require __DIR__.'/includes/admin-header.php';
?>
<?php if(!$schemaReady): ?><?php if(!preg_match('/^[a-f0-9]{64}$/i',(string)cfg('security.mfa_encryption_key',''))): ?><div class="panel"><h2>کلید رمزنگاری MFA</h2><p class="p-desc">برای ذخیره امن secretهای TOTP، یک کلید مستقل و تصادفی در فایل config خصوصی سایت ساخته می‌شود. این کلید را در بکاپ امن config نگه دارید و در صورت تغییر/گم‌شدن آن، MFA باید برای مدیران بازنشانی شود.</p><form method="post"><?=csrf_field()?><input type="hidden" name="do" value="generate_mfa_key"><button class="btn" type="submit">ایجاد و ذخیره کلید رمزنگاری</button></form></div><?php endif; ?>
<div class="panel"><h2>احراز هویت دومرحله‌ای (TOTP)</h2><div class="flash err"><?=e($error)?></div><p class="p-desc">ابتدا مجوز ALTER TABLE را برای کاربر دیتابیس فعال کنید یا migration را طبق راهنمای نصب اجرا کنید.</p></div><?php require __DIR__.'/includes/admin-footer.php'; exit; endif; ?>
<?php if(!preg_match('/^[a-f0-9]{64}$/i',(string)cfg('security.mfa_encryption_key',''))): ?><div class="panel"><h2>کلید رمزنگاری MFA</h2><p class="p-desc">برای ذخیره امن secretهای TOTP، یک کلید مستقل و تصادفی در فایل config خصوصی سایت ساخته می‌شود. این کلید را در بکاپ امن config نگه دارید و در صورت تغییر/گم‌شدن آن، MFA باید برای مدیران بازنشانی شود.</p><form method="post"><?=csrf_field()?><input type="hidden" name="do" value="generate_mfa_key"><button class="btn" type="submit">ایجاد و ذخیره کلید رمزنگاری</button></form></div><?php endif; ?>
<div class="panel"><h2>احراز هویت دومرحله‌ای (TOTP)</h2><p class="p-desc">با فعال‌سازی، ورود به پنل علاوه بر رمز عبور به کد ۶ رقمی برنامه Authenticator نیاز دارد. این قابلیت برای حساب فعلی شما تنظیم می‌شود.</p>
<?php if($error): ?><div class="flash err"><?=e($error)?></div><?php endif; ?>
<?php if($enabled): ?><div class="flash ok">MFA فعال است و در ورودهای بعدی کد یک‌بارمصرف لازم خواهد بود.</div><form method="post"><?=csrf_field()?><input type="hidden" name="do" value="disable"><div class="f-field"><label>کد فعلی Authenticator برای غیرفعال‌سازی</label><input type="text" name="code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" required autocomplete="one-time-code"></div><button class="btn btn-danger" type="submit">غیرفعال‌سازی MFA</button></form>
<?php elseif($secret): ?><div class="f-field"><label>کلید دستی (Secret)</label><input readonly dir="ltr" value="<?=e($secret)?>"></div><p class="p-desc">در برنامه Authenticator، گزینه افزودن حساب با کلید دستی را انتخاب کنید. نام حساب MoradiApp و نوع کد TOTP (۶ رقم، هر ۳۰ ثانیه) باشد.</p><div class="f-field"><label>URI سازگار (در صورت نیاز)</label><textarea readonly dir="ltr" rows="3"><?=e($uri)?></textarea></div><form method="post"><?=csrf_field()?><input type="hidden" name="do" value="enable"><div class="f-field"><label>کد ۶ رقمی برای فعال‌سازی</label><input type="text" name="code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" required autocomplete="one-time-code"></div><button class="btn" type="submit">تأیید و فعال‌سازی MFA</button></form><form method="post" style="margin-top:12px"><?=csrf_field()?><input type="hidden" name="do" value="generate"><button class="btn btn-ghost" type="submit">تولید کلید جدید</button></form>
<?php else: ?><p class="p-desc">هنوز احراز هویت دومرحله‌ای برای حساب شما تنظیم نشده است.</p><form method="post"><?=csrf_field()?><input type="hidden" name="do" value="generate"><button class="btn" type="submit">راه‌اندازی Authenticator</button></form><?php endif; ?></div>
<div class="panel"><h2>توصیه امنیتی</h2><ul><li>کلید Secret را در اختیار دیگران قرار ندهید.</li><li>قبل از خروج از این صفحه، کد را تأیید و MFA را فعال کنید.</li><li>اگر تلفن را از دست دادید، مدیر اصلی باید از طریق دیتابیس یا فرایند بازیابی امن MFA را reset کند.</li></ul></div>
<?php require __DIR__.'/includes/admin-footer.php'; ?>
