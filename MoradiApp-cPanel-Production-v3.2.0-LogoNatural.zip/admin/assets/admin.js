/* =====================================================================
   مرادی‌اپ — admin.js | تعاملات پنل مدیریت (بدون وابستگی خارجی)
   ===================================================================== */
(function () {
    'use strict';
    var d = document;

    /* ---------- سایدبار موبایل ---------- */
    var toggle = d.querySelector('.side-toggle');
    var sidebar = d.querySelector('.sidebar');
    if (toggle && sidebar) {
        toggle.addEventListener('click', function () {
            sidebar.classList.toggle('open');
        });
        d.addEventListener('click', function (ev) {
            if (!sidebar.contains(ev.target) && !toggle.contains(ev.target)) {
                sidebar.classList.remove('open');
            }
        });
    }

    /* ---------- تأیید حذف ---------- */
    var overlay = d.querySelector('.modal-overlay[data-confirm-modal]');
    if (overlay) {
        var mTitle = overlay.querySelector('.m-title');
        var mText = overlay.querySelector('.m-text');
        var mForm = overlay.querySelector('form');
        d.querySelectorAll('[data-confirm]').forEach(function (el) {
            el.addEventListener('click', function (ev) {
                ev.preventDefault();
                mTitle.textContent = el.getAttribute('data-confirm-title') || 'تأیید عملیات';
                mText.textContent = el.getAttribute('data-confirm') || 'آیا مطمئن هستید؟';
                mForm.setAttribute('action', el.getAttribute('data-url') || el.getAttribute('href') || '#');
                /* فیلدهای POST ناشی از data-post="action:delete,id:5" */
                mForm.querySelectorAll('input[data-posted]').forEach(function (i) { i.remove(); });
                var post = el.getAttribute('data-post') || '';
                post.split(',').forEach(function (pair) {
                    if (!pair) return;
                    var kv = pair.split(':');
                    if (kv.length !== 2) return;
                    var inp = d.createElement('input');
                    inp.type = 'hidden';
                    inp.name = kv[0].trim();
                    inp.value = kv[1].trim();
                    inp.setAttribute('data-posted', '1');
                    mForm.appendChild(inp);
                });
                overlay.classList.add('open');
            });
        });
        overlay.addEventListener('click', function (ev) {
            if (ev.target === overlay) overlay.classList.remove('open');
        });
        var cancelBtn = overlay.querySelector('[data-cancel]');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', function () { overlay.classList.remove('open'); });
        }
    }

    /* ---------- فیلدهای تکرارشونده (features / technologies / modules) ---------- */
    d.querySelectorAll('[data-repeater]').forEach(function (box) {
        var tpl = box.querySelector('.rep-tpl');
        var list = box.querySelector('.rep-list');
        var addBtn = box.querySelector('[data-rep-add]');
        var max = parseInt(box.getAttribute('data-repeater') || '0', 10);

        function wire(row) {
            var del = row.querySelector('[data-rep-del]');
            if (del) {
                del.addEventListener('click', function () {
                    if (list.children.length > 1) {
                        row.remove();
                    } else {
                        row.querySelectorAll('input,textarea').forEach(function (i) { i.value = ''; });
                    }
                });
            }
        }
        if (tpl && list) {
            Array.prototype.forEach.call(list.children, wire);
            if (addBtn) {
                addBtn.addEventListener('click', function () {
                    if (max && list.children.length >= max) return;
                    var node = tpl.content ? tpl.content.firstElementChild.cloneNode(true) : null;
                    if (!node) return;
                    list.appendChild(node);
                    wire(node);
                });
            }
        }
    });

    /* ---------- انتخاب‌گر رسانه ---------- */
    d.querySelectorAll('[data-media-picker]').forEach(function (field) {
        var input = d.querySelector(field.getAttribute('data-media-picker'));
        var preview = d.querySelector(field.getAttribute('data-media-preview') || '#noop');
        if (!input || !field) return;
        field.addEventListener('click', function () {
            openMediaPicker(function (path) {
                input.value = path;
                if (preview && preview.tagName === 'IMG') {
                    preview.src = (window.ADMIN_BASE || '/') + path;
                    preview.style.display = 'block';
                }
            });
        });
    });

    /* ---------- گالری چندتایی محصول ---------- */
    var galleryPick = d.getElementById('galleryPick');
    if (galleryPick) {
        var hidden = d.getElementById('galleryInput');
        function syncGallery() {
            var urls = [];
            galleryPick.querySelectorAll('.gp.on').forEach(function (g) {
                urls.push(g.getAttribute('data-url'));
            });
            if (hidden) hidden.value = JSON.stringify(urls);
        }
        galleryPick.addEventListener('click', function (ev) {
            var item = ev.target.closest('.gp');
            if (!item) return;
            item.classList.toggle('on');
            syncGallery();
        });
        window.__addGalleryChip = function (url) {
            var existing = Array.prototype.find.call(galleryPick.querySelectorAll('.gp'), function (el) { return el.getAttribute('data-url') === url; });
            if (existing) { existing.classList.add('on'); }
            else {
                var chip = d.createElement('span');
                chip.className = 'gp on';
                chip.setAttribute('data-url', url);
                var img = d.createElement('img'); img.alt = ''; img.src = (window.ADMIN_BASE || '/') + url; chip.appendChild(img);
                galleryPick.appendChild(chip);
            }
            syncGallery();
        };
        syncGallery();
    }

    /* ---------- انتخاب تصاویر گالری از پنل رسانه ---------- */
    var addGalleryBtn = d.getElementById('addGalleryImages');
    if (addGalleryBtn) {
        addGalleryBtn.addEventListener('click', function () {
            openMediaPicker(function (url) {
                if (window.__addGalleryChip) window.__addGalleryChip(url);
            });
        });
    }

    /* ---------- ویرایشگر آمار صفحه اصلی ---------- */
    var statsBox = d.getElementById('statsRepeater');
    if (statsBox) {
        var stAdd = d.getElementById('statsAdd');
        var stHidden = d.getElementById('statsInput');
        function collectStats() {
            var rows = [];
            statsBox.querySelectorAll('.stat-row').forEach(function (r) {
                var label = r.querySelector('.stat-label').value.trim();
                var value = r.querySelector('.stat-value').value.trim();
                var suffix = r.querySelector('.stat-suffix').value.trim();
                if (label && value !== '') rows.push({ label: label, value: value, suffix: suffix });
            });
            stHidden.value = JSON.stringify(rows);
        }
        function wireStat(row) {
            row.querySelectorAll('input').forEach(function (i) { i.addEventListener('input', collectStats); });
            var del = row.querySelector('[data-rep-del]');
            if (del) del.addEventListener('click', function () { row.remove(); collectStats(); });
        }
        statsBox.querySelectorAll('.stat-row').forEach(wireStat);
        if (stAdd) {
            stAdd.addEventListener('click', function () {
                var tpl = d.getElementById('statRowTpl');
                var node = tpl.content.firstElementChild.cloneNode(true);
                statsBox.appendChild(node);
                wireStat(node);
            });
        }
        statsBox.closest('form').addEventListener('submit', collectStats);
    }

    /* ---------- پیش‌نمایش فیلد آپلود ---------- */
    var fileInput = d.getElementById('mediaFile');
    if (fileInput) {
        fileInput.addEventListener('change', function () {
            var f = fileInput.files && fileInput.files[0];
            if (!f) return;
            var ok = /\.(jpe?g|png|webp|gif)$/i.test(f.name);
            var zone = d.querySelector('.dropzone .dz-name');
            if (zone) zone.textContent = ok ? 'فایل انتخاب‌شده: ' + f.name + ' (' + Math.round(f.size / 1024) + ' کیلوبایت)' : 'فرمت مجاز نیست';
        });
    }
    var dropzone = d.querySelector('.dropzone');
    if (dropzone && fileInput) {
        dropzone.addEventListener('click', function () { fileInput.click(); });
        ['dragover', 'dragenter'].forEach(function (evName) {
            dropzone.addEventListener(evName, function (ev) { ev.preventDefault(); dropzone.classList.add('dragover'); });
        });
        ['dragleave', 'drop'].forEach(function (evName) {
            dropzone.addEventListener(evName, function (ev) { ev.preventDefault(); dropzone.classList.remove('dragover'); });
        });
        dropzone.addEventListener('drop', function (ev) {
            if (ev.dataTransfer && ev.dataTransfer.files && ev.dataTransfer.files.length) {
                fileInput.files = ev.dataTransfer.files;
                fileInput.dispatchEvent(new Event('change'));
            }
        });
    }

    /* ---------- اعتبارسنجی سریع فرم‌های مدیریتی ---------- */
    d.querySelectorAll('form[data-validate]').forEach(function (form) {
        form.addEventListener('submit', function (ev) {
            var bad = null;
            form.querySelectorAll('[required]').forEach(function (input) {
                var field = input.closest('.f-field');
                if (!input.value.trim()) {
                    if (field) field.classList.add('has-err');
                    if (!bad) bad = input;
                } else if (field) {
                    field.classList.remove('has-err');
                }
            });
            var slug = form.querySelector('[name="slug"]');
            if (slug && slug.value && !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug.value)) {
                slug.closest('.f-field').classList.add('has-err');
                if (!bad) bad = slug;
            }
            if (bad) { ev.preventDefault(); bad.focus(); }
        });
    });
})();

/* ---------- انتخاب‌گر رسانه (هم‌زمان با صفحات مختلف) ---------- */
var _mpOverlay = null;
function openMediaPicker(onPick, multi) {
    var d = document;
    if (!_mpOverlay) {
        _mpOverlay = d.createElement('div');
        _mpOverlay.className = 'media-pick-overlay';
        var box = d.createElement('div'); box.className = 'media-pick-box';
        var head = d.createElement('div'); head.className = 'mp-head';
        var title = d.createElement('h3'); title.style.margin = '0'; title.style.fontSize = '18px'; title.textContent = 'انتخاب تصویر';
        var spacer = d.createElement('span'); spacer.style.flex = '1';
        var close = d.createElement('button'); close.type = 'button'; close.className = 'btn btn-ghost btn-sm'; close.setAttribute('data-mp-close',''); close.textContent = 'بستن';
        head.appendChild(title); head.appendChild(spacer); head.appendChild(close);
        var list = d.createElement('div'); list.className = 'media-grid'; list.setAttribute('data-mp-list','');
        var loading = d.createElement('span'); loading.className = 'mi-meta'; loading.textContent = 'در حال بارگذاری…'; list.appendChild(loading);
        box.appendChild(head); box.appendChild(list); _mpOverlay.appendChild(box);
        d.body.appendChild(_mpOverlay);
        _mpOverlay.addEventListener('click', function (ev) {
            if (ev.target === _mpOverlay || ev.target.hasAttribute('data-mp-close')) _mpOverlay.classList.remove('open');
        });
        /* دریافت فهرست رسانه‌ها از سرور */
        fetch('media.php?action=list', { headers: { 'X-Requested-With': 'fetch' } })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                var list = _mpOverlay.querySelector('[data-mp-list]');
                list.replaceChildren();
                if (!data.ok || !data.items.length) {
                    var empty = d.createElement('span'); empty.className = 'mi-meta'; empty.textContent = 'رسانه‌ای موجود نیست؛ ابتدا از بخش رسانه‌ها آپلود کنید.'; list.appendChild(empty);
                    return;
                }
                data.items.forEach(function (m) {
                    if (!m || typeof m.path !== 'string' || !/^uploads\/media\/[A-Za-z0-9_\/-]+\.(jpg|jpeg|png|webp|gif)$/i.test(m.path) || m.path.indexOf('..') !== -1) return;
                    var cell = d.createElement('div'); cell.className = 'media-item';
                    var img = d.createElement('img'); img.alt = ''; img.loading = 'lazy'; img.src = String(m.url || '');
                    var meta = d.createElement('div'); meta.className = 'mi-meta'; meta.textContent = String(m.filename || 'تصویر');
                    var actions = d.createElement('div'); actions.className = 'mi-actions';
                    var btn = d.createElement('button'); btn.type = 'button'; btn.className = 'btn btn-sm'; btn.textContent = 'انتخاب'; btn.setAttribute('data-mp-path', m.path);
                    actions.appendChild(btn); cell.appendChild(img); cell.appendChild(meta); cell.appendChild(actions); list.appendChild(cell);
                });
            })
            .catch(function () {
                var list = _mpOverlay.querySelector('[data-mp-list]'); list.replaceChildren(); var err = d.createElement('span'); err.className = 'mi-meta'; err.textContent = 'خطا در دریافت فهرست رسانه‌ها.'; list.appendChild(err);
            });
    }
    _mpOverlay.classList.add('open');
    _mpOverlay.onclick = function (ev) {
        if (ev.target === _mpOverlay || ev.target.hasAttribute('data-mp-close')) { _mpOverlay.classList.remove('open'); return; }
        var btn = ev.target.closest('[data-mp-path]');
        if (btn && onPick) { onPick(btn.getAttribute('data-mp-path')); _mpOverlay.classList.remove('open'); }
    };
}
