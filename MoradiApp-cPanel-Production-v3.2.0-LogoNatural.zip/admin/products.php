<?php
/**
 * admin/products.php — فهرست و مدیریت محصولات (فعال/غیرفعال، منتخب، ترتیب، حذف)
 */
$adminTitle = 'محصولات و سامانه‌ها';
$adminActive = 'products';
require_once __DIR__ . '/includes/admin-boot.php';

$pdo = Store::db();
$flash = fn($t, $m) => flash_set($t, $m);

/* ---------- عملیات ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $action = (string)($_POST['action'] ?? '');
    $id = (int)($_POST['id'] ?? 0);
    if ($id > 0) {
        switch ($action) {
            case 'toggle':
                $st = $pdo->prepare("UPDATE products SET status = IF(status='active','inactive','active'), updated_at = NOW() WHERE id = :id");
                $st->execute([':id' => $id]);
                Store::syncStaticData();
                log_activity('product_toggle', 'تغییر وضعیت نمایش محصول #' . $id);
                $flash('ok', 'وضعیت نمایش محصول تغییر کرد.');
                break;
            case 'featured':
                $st = $pdo->prepare('UPDATE products SET featured = IF(featured=1,0,1), updated_at = NOW() WHERE id = :id');
                $st->execute([':id' => $id]);
                Store::syncStaticData();
                log_activity('product_featured', 'تغییر وضعیت منتخب محصول #' . $id);
                $flash('ok', 'وضعیت «منتخب» محصول تغییر کرد.');
                break;
            case 'move':
                $dir = (string)($_POST['dir'] ?? 'up');
                $st = $pdo->prepare('SELECT display_order FROM products WHERE id = :id');
                $st->execute([':id' => $id]);
                $row = $st->fetch();
                if ($row) {
                    $cur = (int)$row['display_order'];
                    $other = $pdo->prepare('SELECT id, display_order FROM products WHERE display_order = :o AND id <> :id LIMIT 1');
                    $other->execute([':o' => $dir === 'up' ? $cur - 1 : $cur + 1, ':id' => $id]);
                    $sw = $other->fetch();
                    if ($sw) {
                        $u1 = $pdo->prepare('UPDATE products SET display_order = :o, updated_at = NOW() WHERE id = :id');
                        $u1->execute([':o' => $cur, ':id' => $sw['id']]);
                        $u2 = $pdo->prepare('UPDATE products SET display_order = :o, updated_at = NOW() WHERE id = :id');
                        $u2->execute([':o' => (int)$sw['display_order'], ':id' => $id]);
                    } else {
                        $new = $dir === 'up' ? max(0, $cur - 1) : $cur + 1;
                        $u = $pdo->prepare('UPDATE products SET display_order = :o, updated_at = NOW() WHERE id = :id');
                        $u->execute([':o' => $new, ':id' => $id]);
                    }
                    Store::syncStaticData();
                log_activity('product_move', 'تغییر ترتیب محصول #' . $id);
                    $flash('ok', 'ترتیب نمایش به‌روزرسانی شد.');
                }
                break;
            case 'delete':
                $st = $pdo->prepare('DELETE FROM products WHERE id = :id');
                $st->execute([':id' => $id]);
                Store::syncStaticData();
                log_activity('product_delete', 'حذف محصول #' . $id);
                $flash('ok', 'محصول حذف شد.');
                break;
        }
    }
    redirect('products.php');
}

/* ---------- جستجو و فیلتر ---------- */
$q = trim((string)($_GET['q'] ?? ''));
$fstatus = (string)($_GET['status'] ?? '');
$sql = 'SELECT id, slug, title, category, image, status, featured, display_order, updated_at FROM products';
$where = [];
$params = [];
if ($q !== '') {
    $where[] = '(title LIKE :q OR slug LIKE :q OR category LIKE :q)';
    $params[':q'] = '%' . $q . '%';
}
if (in_array($fstatus, ['active', 'inactive'], true)) {
    $where[] = 'status = :st';
    $params[':st'] = $fstatus;
}
if ($where) { $sql .= ' WHERE ' . implode(' AND ', $where); }
$sql .= ' ORDER BY display_order ASC, id ASC';

$st = $pdo->prepare($sql);
$st->execute($params);
$rows = $st->fetchAll();

/* قالب پنل: پس از پردازش POST (الگوی PRG) */
require __DIR__ . '/includes/admin-header.php';
?>
<div class="panel">
    <div class="tbl-tools">
        <form method="get" style="display:flex;gap:12px;flex-wrap:wrap;align-items:center">
            <input type="search" name="q" value="<?= e($q) ?>" placeholder="جستجو: نام، مسیر یا دسته…">
            <select name="status">
                <option value="">همه وضعیت‌ها</option>
                <option value="active" <?= $fstatus === 'active' ? 'selected' : '' ?>>فعال</option>
                <option value="inactive" <?= $fstatus === 'inactive' ? 'selected' : '' ?>>غیرفعال</option>
            </select>
            <button class="btn btn-ghost btn-sm" type="submit">اعمال فیلتر</button>
        </form>
        <span class="sp"></span>
        <a class="btn" href="product-form.php">+ افزودن سامانه جدید</a>
    </div>

    <?php if ($rows): ?>
    <div class="table-wrap">
        <table class="tbl">
            <tr>
                <th>ترتیب</th><th>تصویر</th><th>عنوان</th><th>دسته</th><th>مسیر</th>
                <th>وضعیت</th><th>منتخب</th><th>عملیات</th>
            </tr>
            <?php foreach ($rows as $r): ?>
            <tr>
                <td style="white-space:nowrap">
                    <?= e(fa_num((string)$r['display_order'])) ?>
                    <form method="post" style="display:inline"><?= csrf_field() ?>
                        <input type="hidden" name="action" value="move"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                        <button class="btn btn-ghost btn-sm" name="dir" value="up" title="انتقال به بالا">↑</button>
                        <button class="btn btn-ghost btn-sm" name="dir" value="down" title="انتقال به پایین">↓</button>
                    </form>
                </td>
                <td>
                    <?php if ($r['image']): ?>
                        <img class="thumb-sm" src="<?= e(base_url($r['image'])) ?>" alt="">
                    <?php else: ?><span style="color:var(--text-2)">—</span><?php endif; ?>
                </td>
                <td><a href="product-form.php?id=<?= (int)$r['id'] ?>"><b><?= e($r['title']) ?></b></a></td>
                <td><?= e($r['category'] ?: '—') ?></td>
                <td dir="ltr" style="text-align:right"><a href="<?= e(base_url('products/' . $r['slug'])) ?>" target="_blank" rel="noopener"><?= e($r['slug']) ?></a></td>
                <td><span class="st st-<?= e($r['status']) ?>"><?= $r['status'] === 'active' ? 'فعال' : 'غیرفعال' ?></span></td>
                <td><?= $r['featured'] ? '<span class="st st-yes">منتخب</span>' : '<span style="color:var(--text-2)">—</span>' ?></td>
                <td class="actions">
                    <a class="btn btn-ghost btn-sm" href="product-form.php?id=<?= (int)$r['id'] ?>">ویرایش</a>
                    <form method="post" style="display:inline"><?= csrf_field() ?>
                        <input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                        <button class="btn btn-ghost btn-sm"><?= $r['status'] === 'active' ? 'غیرفعال کن' : 'فعال کن' ?></button>
                    </form>
                    <form method="post" style="display:inline"><?= csrf_field() ?>
                        <input type="hidden" name="action" value="featured"><input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                        <button class="btn btn-ghost btn-sm"><?= $r['featured'] ? 'حذف منتخب' : 'انتخاب منتخب' ?></button>
                    </form>
                    <a class="btn btn-danger btn-sm" href="#"
                       data-confirm="محصول «<?= e($r['title']) ?>» برای همیشه حذف شود؟ این عملیات بازگشت‌پذیر نیست."
                       data-confirm-title="حذف محصول"
                       data-url="products.php"
                       data-post="action:delete,id:<?= (int)$r['id'] ?>">حذف</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
    <?php else: ?>
    <p class="p-desc">محصولی یافت نشد. با دکمه «افزودن سامانه جدید» اولین سامانه را ثبت کنید.</p>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/admin-footer.php'; ?>
