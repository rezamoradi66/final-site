<?php
/**
 * admin/logs.php — گزارش فعالیت‌های مدیریتی
 */
$adminTitle = 'گزارش فعالیت‌ها';
$adminActive = 'logs';
require_once __DIR__ . '/includes/admin-boot.php';

$pdo = Store::db();
$page = max(1, (int)($_GET['p'] ?? 1));
$perPage = 20;
$action = trim((string)($_GET['action'] ?? ''));

$total = 0;
$params = [];
$whereSql = '';
if ($action !== '') {
    $whereSql = 'WHERE action = :a';
    $params[':a'] = $action;
}
$st = $pdo->prepare("SELECT COUNT(*) c FROM activity_log $whereSql");
$st->execute($params);
$total = (int)$st->fetch()['c'];
$pages = max(1, (int)ceil($total / $perPage));
$page = min($page, $pages);

$sql = "SELECT * FROM activity_log $whereSql ORDER BY id DESC LIMIT :lim OFFSET :off";
$st = $pdo->prepare($sql);
foreach ($params as $k => $v) { $st->bindValue($k, $v); }
$st->bindValue(':lim', $perPage, PDO::PARAM_INT);
$st->bindValue(':off', ($page - 1) * $perPage, PDO::PARAM_INT);
$st->execute();
$rows = $st->fetchAll();

/* انواع رویداد موجود برای فیلتر */
$actions = $pdo->query('SELECT DISTINCT action FROM activity_log ORDER BY action')->fetchAll(PDO::FETCH_COLUMN);
$actionLabels = [
    'login' => 'ورود', 'logout' => 'خروج',
    'product_create' => 'ایجاد محصول', 'product_update' => 'ویرایش محصول',
    'product_delete' => 'حذف محصول', 'product_toggle' => 'تغییر وضعیت محصول',
    'product_featured' => 'محصول منتخب', 'product_move' => 'ترتیب محصولات',
    'media_upload' => 'آپلود رسانه', 'media_delete' => 'حذف رسانه',
    'homepage_update' => 'ویرایش صفحه اصلی', 'settings_update' => 'تنظیمات سایت',
    'request_status' => 'وضعیت درخواست', 'request_note' => 'یادداشت درخواست',
    'request_archive' => 'آرشیو درخواست', 'request_delete' => 'حذف درخواست',
    'user_create' => 'ایجاد کاربر', 'user_toggle' => 'وضعیت کاربر',
    'user_resetpass' => 'بازنشانی رمز', 'user_delete' => 'حذف کاربر',
];

/* قالب پنل: پس از پردازش POST (الگوی PRG) */
require __DIR__ . '/includes/admin-header.php';
?>
<div class="panel">
    <div class="tbl-tools">
        <form method="get" style="display:flex;gap:12px;align-items:center">
            <select name="action">
                <option value="">همه رویدادها</option>
                <?php foreach ($actions as $a): ?>
                    <option value="<?= e($a) ?>" <?= $action === $a ? 'selected' : '' ?>><?= e($actionLabels[$a] ?? $a) ?></option>
                <?php endforeach; ?>
            </select>
            <button class="btn btn-ghost btn-sm" type="submit">فیلتر</button>
        </form>
        <span class="sp"></span>
        <span style="color:var(--text-2);font-size:14px"><?= e(fa_num((string)$total)) ?> رویداد ثبت‌شده</span>
    </div>

    <?php if ($rows): ?>
    <div class="table-wrap">
        <table class="tbl">
            <tr><th>کاربر</th><th>رویداد</th><th>جزئیات</th><th>IP</th><th>زمان</th></tr>
            <?php foreach ($rows as $r): ?>
            <tr>
                <td><?= e($r['username'] ?: '—') ?></td>
                <td><span class="st st-reviewing"><?= e($actionLabels[$r['action']] ?? $r['action']) ?></span></td>
                <td><?= e($r['details']) ?></td>
                <td dir="ltr" style="text-align:right"><?= e($r['ip_address']) ?></td>
                <td><?= e(jdate($r['created_at'], 'Y/m/d H:i')) ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
    <?php if ($pages > 1): ?>
    <div class="pager">
        <?php for ($i = 1; $i <= $pages; $i++): ?>
            <?php if ($i === $page): ?><span class="cur"><?= e(fa_num((string)$i)) ?></span>
            <?php else: ?><a href="logs.php?action=<?= e($action) ?>&p=<?= $i ?>"><?= e(fa_num((string)$i)) ?></a><?php endif; ?>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
    <?php else: ?>
    <p class="p-desc">هنوز رویدادی ثبت نشده است. پس از انجام عملیات مدیریتی، گزارش اینجا ثبت می‌شود.</p>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/includes/admin-footer.php'; ?>
