<?php
/**
 * admin/settings.php — تنظیمات عمومی سایت: برند، تماس، شبکه‌های اجتماعی، سئو، فوتر
 */
$adminTitle = 'تنظیمات سایت';
$adminActive = 'settings';
require_once __DIR__ . '/includes/admin-boot.php';

$S = Store::settings();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $kv = [
        'brand_name'      => mb_substr(trim((string)($_POST['brand_name'] ?? '')), 0, 80),
        'brand_tagline'   => mb_substr(trim((string)($_POST['brand_tagline'] ?? '')), 0, 120),
        'brand_desc'      => mb_substr(trim((string)($_POST['brand_desc'] ?? '')), 0, 400),
        'logo_image'      => mb_substr(trim((string)($_POST['logo_image'] ?? '')), 0, 255),
        'site_title'      => mb_substr(trim((string)($_POST['site_title'] ?? '')), 0, 150),
        'site_description'=> mb_substr(trim((string)($_POST['site_description'] ?? '')), 0, 300),
        'seo_keywords'    => mb_substr(trim((string)($_POST['seo_keywords'] ?? '')), 0, 300),
        'site_url'        => mb_substr(trim((string)($_POST['site_url'] ?? '')), 0, 200),
        'og_image'        => mb_substr(trim((string)($_POST['og_image'] ?? '')), 0, 255),
        'contact_phone'   => mb_substr(trim((string)($_POST['contact_phone'] ?? '')), 0, 40),
        'contact_email'   => mb_substr(trim((string)($_POST['contact_email'] ?? '')), 0, 150),
        'contact_address' => mb_substr(trim((string)($_POST['contact_address'] ?? '')), 0, 300),
        'client_portal_url' => mb_substr(trim((string)($_POST['client_portal_url'] ?? '')), 0, 250),
        'registration_url' => mb_substr(trim((string)($_POST['registration_url'] ?? '')), 0, 250),
        'footer_text'     => mb_substr(trim((string)($_POST['footer_text'] ?? '')), 0, 400),
        'copyright'       => mb_substr(trim((string)($_POST['copyright'] ?? '')), 0, 160),
        'social'          => [
            'telegram'  => trim((string)($_POST['social_telegram'] ?? '')),
            'instagram' => trim((string)($_POST['social_instagram'] ?? '')),
            'linkedin'  => trim((string)($_POST['social_linkedin'] ?? '')),
            'whatsapp'  => trim((string)($_POST['social_whatsapp'] ?? '')),
        ],
    ];
    if ($kv['brand_name'] === '') { $kv['brand_name'] = 'مرادی‌اپ'; }
    if ($kv['logo_image'] !== '' && (!preg_match('#^(?:uploads/media|assets/images)/[A-Za-z0-9_./-]+\.(?:jpg|jpeg|png|webp|gif|svg)$#i', $kv['logo_image']) || str_contains($kv['logo_image'], '..') || str_starts_with($kv['logo_image'], '/'))) { flash_set('err', 'مسیر لوگو باید یک فایل تصویری محلی معتبر باشد.'); redirect('settings.php'); }
    if ($kv['site_url'] !== '' && (!filter_var($kv['site_url'], FILTER_VALIDATE_URL) || !in_array(strtolower((string)parse_url($kv['site_url'], PHP_URL_SCHEME)), ['http','https'], true))) {
        flash_set('err', 'آدرس سایت باید یک URL معتبر باشد (مثال: https://moradiapp.ir).');
        redirect('settings.php');
    }
    foreach (['client_portal_url','registration_url'] as $urlKey) {
        $urlValue = trim($kv[$urlKey]);
        if ($urlValue !== '') {
            $scheme = strtolower((string)(parse_url($urlValue, PHP_URL_SCHEME) ?? ''));
            $isInternal = str_starts_with($urlValue, '/') && !str_starts_with($urlValue, '//') && !str_contains($urlValue, '\\') && !str_contains($urlValue, '..');
            if (!$isInternal && (str_starts_with($urlValue, '//') || !in_array($scheme, ['http','https'], true) || !filter_var($urlValue, FILTER_VALIDATE_URL))) {
                flash_set('err', 'آدرس ورود/ثبت‌نام باید URL معتبر HTTP/HTTPS یا مسیر داخلی سایت باشد.');
                redirect('settings.php');
            }
        }
    }
    foreach ($kv['social'] as $socialKey => $socialUrl) {
        if ($socialUrl !== '' && (!filter_var($socialUrl, FILTER_VALIDATE_URL) || !in_array(strtolower((string)parse_url($socialUrl, PHP_URL_SCHEME)), ['http','https'], true))) {
            flash_set('err', 'لینک شبکه اجتماعی باید با HTTP یا HTTPS معتبر باشد.'); redirect('settings.php');
        }
        $kv['social'][$socialKey] = mb_substr($socialUrl, 0, 250);
    }
    $ok = Store::saveSettings($kv);
    if ($ok) {
        Store::syncStaticData();
        log_activity('settings_update', 'به‌روزرسانی تنظیمات عمومی سایت');
        flash_set('ok', 'تنظیمات ذخیره شد.');
    } else {
        flash_set('err', 'ذخیره‌سازی تنظیمات ناموفق بود.');
    }
    redirect('settings.php');
}

/* قالب پنل: پس از پردازش POST (الگوی PRG) */
require __DIR__ . '/includes/admin-header.php';
?>
<form method="post" data-validate>
    <?= csrf_field() ?>

    <div class="panel">
        <h2>برند و لوگو</h2>
        <div class="f-grid">
            <div class="f-field">
                <label>نام برند <span class="req">*</span></label>
                <input type="text" name="brand_name" value="<?= e($S['brand_name']) ?>" maxlength="80" required>
            </div>
            <div class="f-field">
                <label>شعار / توضیح کوتاه برند</label>
                <input type="text" name="brand_tagline" value="<?= e($S['brand_tagline']) ?>" maxlength="120">
            </div>
            <div class="f-field full">
                <label>توضیح معرفی برند</label>
                <textarea name="brand_desc" rows="2" maxlength="400"><?= e($S['brand_desc']) ?></textarea>
            </div>
            <div class="f-field">
                <label>لوگوی اختصاصی (PNG/WebP)</label>
                <div style="display:flex;gap:10px;align-items:center">
                    <input type="text" name="logo_image" id="logoInput" value="<?= e($S['logo_image']) ?>" dir="ltr" style="text-align:left" placeholder="uploads/media/logo.png">
                    <button class="btn btn-ghost btn-sm" type="button" data-media-picker="#logoInput" data-media-preview="#logoPreview">انتخاب</button>
                </div>
                <span class="hint">در حالت خالی، لوگوی پیش‌فرض SVG سایت استفاده می‌شود. برای آپلود لوگو ابتدا از بخش رسانه‌ها اقدام کنید.</span>
                <img id="logoPreview" src="<?= $S['logo_image'] ? e(base_url($S['logo_image'])) : '' ?>" alt="" style="<?= $S['logo_image'] ? '' : 'display:none' ?>width:120px;margin-top:8px;border-radius:10px;border:1px solid var(--line)">
            </div>
        </div>
    </div>

    <div class="panel">
        <h2>اطلاعات تماس</h2>
        <div class="f-grid">
            <div class="f-field">
                <label>شماره تلفن</label>
                <input type="text" name="contact_phone" value="<?= e($S['contact_phone']) ?>" maxlength="40" dir="ltr" style="text-align:left">
            </div>
            <div class="f-field">
                <label>ایمیل</label>
                <input type="email" name="contact_email" value="<?= e($S['contact_email']) ?>" maxlength="150" dir="ltr" style="text-align:left">
            </div>
            <div class="f-field full">
                <label>نشانی</label>
                <input type="text" name="contact_address" value="<?= e($S['contact_address']) ?>" maxlength="300">
            </div>
        </div>
    </div>

    <div class="panel">
        <h2>ورود و ثبت‌نام مشتریان</h2>
        <div class="f-grid">
            <div class="f-field full">
                <label>آدرس ورود مشتریان</label>
                <input type="text" name="client_portal_url" value="<?= e($S['client_portal_url'] ?? 'https://plan.moradiapp.ir') ?>" maxlength="250" dir="ltr" style="text-align:left">
                <span class="hint">پیش‌فرض به سامانه plan.moradiapp.ir متصل است؛ در صورت تغییر سامانه، اینجا اصلاح کنید.</span>
            </div>
            <div class="f-field full">
                <label>آدرس ثبت‌نام / درخواست دسترسی</label>
                <input type="text" name="registration_url" value="<?= e($S['registration_url'] ?? 'contact.php#request-form') ?>" maxlength="250" dir="ltr" style="text-align:left">
                <span class="hint">می‌تواند مسیر داخلی مانند contact.php#request-form یا یک آدرس HTTPS باشد.</span>
            </div>
        </div>
    </div>

    <div class="panel">
        <h2>شبکه‌های اجتماعی</h2>
        <p class="p-desc">لینک‌های خالی در فوتر و صفحه تماس نمایش داده نمی‌شوند.</p>
        <div class="f-grid">
            <div class="f-field"><label>تلگرام</label><input type="url" name="social_telegram" value="<?= e($S['social']['telegram'] ?? '') ?>" dir="ltr" style="text-align:left"></div>
            <div class="f-field"><label>اینستاگرام</label><input type="url" name="social_instagram" value="<?= e($S['social']['instagram'] ?? '') ?>" dir="ltr" style="text-align:left"></div>
            <div class="f-field"><label>لینکدین</label><input type="url" name="social_linkedin" value="<?= e($S['social']['linkedin'] ?? '') ?>" dir="ltr" style="text-align:left"></div>
            <div class="f-field"><label>واتس‌اپ</label><input type="url" name="social_whatsapp" value="<?= e($S['social']['whatsapp'] ?? '') ?>" dir="ltr" style="text-align:left"></div>
        </div>
    </div>

    <div class="panel">
        <h2>سئو (SEO)</h2>
        <div class="f-grid">
            <div class="f-field">
                <label>عنوان سایت (Title)</label>
                <input type="text" name="site_title" value="<?= e($S['site_title']) ?>" maxlength="150">
                <span class="hint">روی تب مرورگر و نتایج جستجو نمایش داده می‌شود.</span>
            </div>
            <div class="f-field">
                <label>آدرس اصلی سایت (برای Canonical و Sitemap)</label>
                <input type="url" name="site_url" value="<?= e($S['site_url']) ?>" maxlength="200" dir="ltr" style="text-align:left" placeholder="https://moradiapp.ir">
                <span class="hint">اگر خالی بگذارید به‌صورت خودکار از دامنه فعلی تشخیص داده می‌شود.</span>
            </div>
            <div class="f-field full">
                <label>توضیحات متا (Meta Description)</label>
                <textarea name="site_description" rows="2" maxlength="300"><?= e($S['site_description']) ?></textarea>
            </div>
            <div class="f-field full">
                <label>کلمات کلیدی</label>
                <input type="text" name="seo_keywords" value="<?= e($S['seo_keywords']) ?>" maxlength="300">
            </div>
            <div class="f-field">
                <label>تصویر Open Graph (اشتراک‌گذاری در شبکه‌ها)</label>
                <input type="text" name="og_image" value="<?= e($S['og_image']) ?>" maxlength="255" dir="ltr" style="text-align:left" placeholder="assets/images/og-image.webp">
            </div>
        </div>
    </div>

    <div class="panel">
        <h2>فوتر و کپی‌رایت</h2>
        <div class="f-grid">
            <div class="f-field full">
                <label>متن معرفی فوتر</label>
                <textarea name="footer_text" rows="2" maxlength="400"><?= e($S['footer_text']) ?></textarea>
            </div>
            <div class="f-field full">
                <label>متن کپی‌رایت</label>
                <input type="text" name="copyright" value="<?= e($S['copyright']) ?>" maxlength="160">
            </div>
        </div>
    </div>

    <div class="f-actions">
        <button class="btn" type="submit">ذخیره تنظیمات</button>
        <a class="btn btn-ghost" href="<?= e(base_url()) ?>" target="_blank" rel="noopener">مشاهده سایت</a>
    </div>
</form>

<?php require __DIR__ . '/includes/admin-footer.php'; ?>
