<?php
/**
 * admin/index.php — داشبورد مدیریتی
 */
$adminTitle = 'داشبورد مدیریت';
$adminActive = 'dashboard';
require_once __DIR__ . '/includes/admin-boot.php';

$pdo = Store::db();
$stat = [
    'products' => 0, 'active' => 0, 'featured' => 0,
    'req_total' => 0, 'req_new' => 0, 'req_week' => 0, 'media' => 0,
];
try {
    $stat['products'] = (int)$pdo->query('SELECT COUNT(*) c FROM products')->fetch()['c'];
    $stat['active']   = (int)$pdo->query("SELECT COUNT(*) c FROM products WHERE status='active'")->fetch()['c'];
    $stat['featured'] = (int)$pdo->query('SELECT COUNT(*) c FROM products WHERE featured=1')->fetch()['c'];
    $stat['req_total'] = (int)$pdo->query('SELECT COUNT(*) c FROM demo_requests')->fetch()['c'];
    $stat['req_new']   = (int)$pdo->query("SELECT COUNT(*) c FROM demo_requests WHERE status='new' AND archived=0")->fetch()['c'];
    $stat['req_week']  = (int)$pdo->query('SELECT COUNT(*) c FROM demo_requests WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)')->fetch()['c'];
    $stat['media']     = (int)$pdo->query('SELECT COUNT(*) c FROM media')->fetch()['c'];
} catch (Throwable $ex) { @error_log('[DASH] ' . $ex->getMessage()); }

$latest = [];
try {
    $latest = $pdo->query('SELECT id, full_name, organization, product_title, status, created_at FROM demo_requests WHERE archived = 0 ORDER BY id DESC LIMIT 6')->fetchAll();
} catch (Throwable $ex) { /* جدول ممکن است خالی باشد */ }

$statusLabels = [
    'new' => 'جدید', 'reviewing' => 'در حال بررسی', 'contacted' => 'تماس گرفته شد',
    'meeting' => 'جلسه تعیین شد', 'completed' => 'تکمیل‌شده', 'cancelled' => 'لغوشده',
];
$installExists = is_file(dirname(__DIR__) . '/install.php');
$lockExists = is_file(DATA_DIR . '/install.lock');
$uploadsOk = is_writable(UPLOAD_DIR . '/media') || is_writable(UPLOAD_DIR);

/* قالب پنل: پس از پردازش POST (الگوی PRG) */
require __DIR__ . '/includes/admin-header.php';
?>
<div class="cards">
    <div class="card accent"><div class="k-label">سامانه‌های ثبت‌شده</div><div class="k-value"><?= e(fa_num((string)$stat['products'])) ?><span class="u">سامانه</span></div><div class="k-hint"><?= e(fa_num((string)$stat['active'])) ?> فعال · <?= e(fa_num((string)$stat['featured'])) ?> منتخب</div></div>
    <div class="card"><div class="k-label">درخواست‌های دمو</div><div class="k-value"><?= e(fa_num((string)$stat['req_total'])) ?></div><div class="k-hint"><?= e(fa_num((string)$stat['req_week'])) ?> درخواست در ۷ روز اخیر</div></div>
    <div class="card <?= $stat['req_new'] ? 'accent' : '' ?>"><div class="k-label">درخواست‌های جدید</div><div class="k-value"><?= e(fa_num((string)$stat['req_new'])) ?></div><div class="k-hint">در انتظار بررسی و پاسخ</div></div>
    <div class="card"><div class="k-label">رسانه‌های آپلودشده</div><div class="k-value"><?= e(fa_num((string)$stat['media'])) ?></div><div class="k-hint">تصاویر محصولات و صفحه اصلی</div></div>
</div>

<?php if ($installExists && $lockExists): ?>
<div class="flash warn">فایل install.php هنوز در ریشه سایت وجود دارد. پس از نصب موفق، برای امنیت آن را حذف کنید. <a href="#" data-confirm="فایل install.php حذف شود؟ این کار پس از نصب پیشنهاد می‌شود." data-confirm-title="حذف install.php" data-url="install.php" data-post="selfdestruct:1">حذف فایل نصب</a></div>
<?php endif; ?>
<?php if (!$uploadsOk): ?>
<div class="flash err">پوشه uploads قابل نوشتن نیست؛ آپلود تصاویر کار نخواهد کرد. مجوز پوشه را در File Manager روی 755 تنظیم کنید.</div>
<?php endif; ?>

<div class="panel">
    <h2>آخرین درخواست‌های دمو</h2>
    <?php if ($latest): ?>
    <div class="table-wrap">
        <table class="tbl">
            <tr><th>نام</th><th>سازمان</th><th>سامانه</th><th>وضعیت</th><th>تاریخ</th><th></th></tr>
            <?php foreach ($latest as $r): ?>
            <tr>
                <td><?= e($r['full_name']) ?></td>
                <td><?= e($r['organization']) ?></td>
                <td><?= e($r['product_title']) ?></td>
                <td><span class="st st-<?= e($r['status']) ?>"><?= e($statusLabels[$r['status']] ?? $r['status']) ?></span></td>
                <td><?= e(jdate($r['created_at'])) ?></td>
                <td class="actions"><a class="btn btn-ghost btn-sm" href="requests.php?id=<?= (int)$r['id'] ?>">جزئیات</a></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
    <?php else: ?>
    <p class="p-desc">هنوز درخواستی ثبت نشده است. با انتشار سایت و ثبت فرم دمو، درخواست‌ها اینجا نمایش داده می‌شوند.</p>
    <?php endif; ?>
</div>

<div class="panel">
    <h2>عملیات سریع</h2>
    <div class="f-actions" style="margin-top:4px">
        <a class="btn" href="product-form.php">افزودن سامانه جدید</a>
        <a class="btn btn-ghost" href="media.php">آپلود تصویر</a>
        <a class="btn btn-ghost" href="homepage.php">ویرایش صفحه اصلی</a>
        <a class="btn btn-ghost" href="requests.php">مدیریت درخواست‌ها</a>
        <a class="btn btn-ghost" href="settings.php">تنظیمات برند و سئو</a>
    </div>
</div>

<div class="panel">
    <h2>وضعیت سیستم</h2>
    <table class="req-table">
        <tr><td>نسخه PHP</td><td><?= e(PHP_VERSION) ?></td></tr>
        <tr><td>اتصال دیتابیس</td><td class="req-pass"><?= e(Store::dbMode() ? 'برقرار است (حالت دیتابیس فعال)' : 'پیکربندی نشده — سایت در حالت استاتیک کار می‌کند') ?></td></tr>
        <tr><td>پوشه آپلود</td><td class="<?= $uploadsOk ? 'req-pass' : 'req-fail' ?>"><?= e($uploadsOk ? 'قابل نوشتن' : 'غیرقابل نوشتن') ?></td></tr>
        <tr><td>فایل نصب (install.php)</td><td class="<?= $installExists ? ($lockExists ? 'req-fail' : 'req-pass') : 'req-pass' ?>"><?= e($installExists ? ($lockExists ? 'موجود است — پس از نصب حذف کنید' : 'در دسترس نصب') : 'حذف شده (امن)') ?></td></tr>
    </table>
</div>

<?php require __DIR__ . '/includes/admin-footer.php'; ?>
