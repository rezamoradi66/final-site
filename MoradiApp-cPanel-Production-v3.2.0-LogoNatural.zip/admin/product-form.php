<?php
/**
 * admin/product-form.php — ایجاد و ویرایش محصول/سامانه
 */
$adminTitle = 'ویرایش سامانه';
$adminActive = 'products';
require_once __DIR__ . '/includes/admin-boot.php';

$pdo = Store::db();
$id = (int)($_GET['id'] ?? 0);
$product = null;

if ($id > 0) {
    $st = $pdo->prepare('SELECT * FROM products WHERE id = :id');
    $st->execute([':id' => $id]);
    $row = $st->fetch();
    if ($row) {
        $product = Store::normalizeProduct($row);
        $adminTitle = 'ویرایش: ' . $product['title'];
    }
}

$errors = [];
$old = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();
    $in = [
        'title' => trim((string)($_POST['title'] ?? '')),
        'slug' => trim((string)($_POST['slug'] ?? '')),
        'subtitle' => trim((string)($_POST['subtitle'] ?? '')),
        'description' => trim((string)($_POST['description'] ?? '')),
        'category' => trim((string)($_POST['category'] ?? '')),
        'image' => trim((string)($_POST['image'] ?? '')),
        'demo_url' => trim((string)($_POST['demo_url'] ?? '')),
        'demo_type' => (string)($_POST['demo_type'] ?? 'placeholder'),
        'status' => (string)($_POST['status'] ?? 'active'),
        'featured' => isset($_POST['featured']),
        'display_order' => (int)($_POST['display_order'] ?? 0),
    ];
    /* آرایه‌ها از فیلدهای تکرارشونده */
    $features = [];
    foreach ((array)($_POST['features'] ?? []) as $f) {
        $f = trim((string)$f);
        if ($f !== '') { $features[] = mb_substr($f, 0, 200); }
    }
    $technologies = [];
    foreach ((array)($_POST['technologies'] ?? []) as $t) {
        $t = trim((string)$t);
        if ($t !== '') { $technologies[] = mb_substr($t, 0, 120); }
    }
    $modules = [];
    $mTitles = (array)($_POST['module_title'] ?? []);
    $mDescs = (array)($_POST['module_desc'] ?? []);
    foreach ($mTitles as $i => $mt) {
        $mt = trim((string)$mt);
        if ($mt === '') { continue; }
        $modules[] = ['title' => mb_substr($mt, 0, 150), 'description' => mb_substr(trim((string)($mDescs[$i] ?? '')), 0, 600)];
    }
    $gallery = [];
    $galleryRaw = (string)($_POST['gallery'] ?? '[]');
    $galleryDec = json_decode($galleryRaw, true);
    if (is_array($galleryDec)) {
        foreach ($galleryDec as $g) {
            $g = trim((string)$g);
            if ($g !== '' && !str_contains($g, '..') && !str_starts_with($g, '/')) { $gallery[] = mb_substr($g, 0, 255); }
        }
    }

    /* ---------- اعتبارسنجی ---------- */
    if (mb_strlen($in['title']) < 3 || mb_strlen($in['title']) > 180) { $errors['title'] = 'عنوان باید بین ۳ تا ۱۸۰ کاراکتر باشد.'; }
    if (!valid_slug($in['slug'])) { $errors['slug'] = 'مسیر فقط شامل حروف کوچک انگلیسی، عدد و خط تیره باشد (مثال: budget-planning).'; }
    if (Store::slugExists($in['slug'], $id)) { $errors['slug'] = 'این مسیر قبلاً برای محصول دیگری ثبت شده است.'; }
    if (!in_array($in['demo_type'], ['direct', 'iframe', 'media', 'placeholder'], true)) { $in['demo_type'] = 'placeholder'; }
    if (!in_array($in['status'], ['active', 'inactive'], true)) { $in['status'] = 'active'; }
    if ($in['demo_url'] !== '') {
        $scheme = strtolower((string)(parse_url($in['demo_url'], PHP_URL_SCHEME) ?? ''));
        $isLocalMedia = $in['demo_type'] === 'media' && preg_match('#^uploads/media/[A-Za-z0-9_/-]+\.(?:jpg|jpeg|png|webp|gif|mp4|webm)$#i', $in['demo_url']) && !str_contains($in['demo_url'], '..');
        if (!$isLocalMedia && (!in_array($scheme, ['http','https'], true) || !filter_var($in['demo_url'], FILTER_VALIDATE_URL) || str_starts_with($in['demo_url'], '//'))) { $errors['demo_url'] = 'لینک دمو فقط باید URL معتبر HTTP/HTTPS یا مسیر رسانه مجاز باشد.'; }
    }
    if ($in['image'] !== '' && (!preg_match('#^(?:uploads/media|assets/images)/[A-Za-z0-9_./-]+\.(?:jpg|jpeg|png|webp|gif|svg)$#i', $in['image']) || str_contains($in['image'], '..') || str_starts_with($in['image'], '/'))) { $errors['image'] = 'مسیر تصویر باید فایل تصویری محلی در uploads/media یا assets/images باشد.'; }
    foreach ($gallery as $g) { if (!preg_match('#^(?:uploads/media|assets/images)/[A-Za-z0-9_./-]+\.(?:jpg|jpeg|png|webp|gif|svg)$#i', $g) || str_contains($g, '..') || str_starts_with($g, '/')) { $errors['gallery'] = 'یکی از مسیرهای گالری نامعتبر است.'; break; } }

    if (!$errors) {
        $data = $in + ['gallery' => $gallery, 'features' => $features, 'modules' => $modules, 'technologies' => $technologies, 'id' => $id ?: null];
        try {
            $newId = Store::saveProduct($data);
            log_activity($id ? 'product_update' : 'product_create', ($id ? 'ویرایش' : 'ایجاد') . ' محصول: ' . $in['title']);
            Store::syncStaticData(); /* به‌روزرسانی فایل‌های استاتیک پشتیبان */
            flash_set('ok', $id ? 'تغییرات محصول ذخیره شد.' : 'محصول جدید ایجاد و منتشر شد.');
            redirect('products.php');
        } catch (Throwable $ex) {
            @error_log('[PRODUCT-SAVE] '.$ex->getMessage());
            $errors['form'] = 'ذخیره‌سازی با خطا مواجه شد. جزئیات فنی در لاگ سرور ثبت شده است.';
        }
    }
    $product = $in + ['gallery' => $gallery, 'features' => $features, 'modules' => $modules, 'technologies' => $technologies];
}

if (!$product) {
    $product = ['id' => 0, 'title' => '', 'slug' => '', 'subtitle' => '', 'description' => '', 'category' => '',
        'image' => '', 'gallery' => [], 'features' => [''], 'modules' => [['title' => '', 'description' => '']],
        'technologies' => [''], 'demo_url' => '', 'demo_type' => 'placeholder', 'status' => 'active', 'featured' => false, 'display_order' => (int)(Store::products(false) ? count(Store::products(false)) : 0) + 1];
}

/* تصاویر موجود برای گالری (از رسانه‌ها + نمونه‌های داخلی) */
$mediaList = [];
try {
    $mediaList = $pdo->query('SELECT filename, original_name FROM media ORDER BY id DESC LIMIT 60')->fetchAll();
} catch (Throwable $ex) { /* خالی */ }

function media_url_guess(string $filename): string {
    return 'uploads/media/' . $filename;
}

/* قالب پنل: پس از پردازش POST (الگوی PRG) */
require __DIR__ . '/includes/admin-header.php';
?>
<div class="panel">
    <h2><?= $id ? 'ویرایش سامانه' : 'افزودن سامانه جدید' ?></h2>
    <p class="p-desc">تمام بخش‌های صفحه اختصاصی محصول از همین فرم کنترل می‌شود. افزودن محصول جدید بدون نیاز به هیچ برنامه‌نویسی انجام می‌شود.</p>
    <?php if (!empty($errors['form'])): ?><div class="flash err"><?= e($errors['form']) ?></div><?php endif; ?>

    <form method="post" data-validate novalidate>
        <?= csrf_field() ?>
        <div class="f-grid">
            <div class="f-field full <?= isset($errors['title']) ? 'has-err' : '' ?>">
                <label>عنوان سامانه <span class="req">*</span></label>
                <input type="text" name="title" value="<?= e($product['title']) ?>" maxlength="180" required>
                <span class="f-err"><?= e($errors['title'] ?? '') ?></span>
            </div>
            <div class="f-field <?= isset($errors['slug']) ? 'has-err' : '' ?>">
                <label>مسیر URL (slug) <span class="req">*</span></label>
                <input type="text" name="slug" id="slugInput" value="<?= e($product['slug']) ?>" maxlength="120" required dir="ltr" style="text-align:left">
                <span class="hint">مثال: budget-planning — آدرس صفحه: /products/این-مسیر</span>
                <span class="f-err"><?= e($errors['slug'] ?? '') ?></span>
            </div>
            <div class="f-field">
                <label>دسته‌بندی</label>
                <input type="text" name="category" value="<?= e($product['category']) ?>" maxlength="80" list="catList" placeholder="مثال: مالی و بودجه">
                <datalist id="catList">
                    <?php foreach (['مالی و بودجه', 'مدیریت پروژه', 'مالی', 'منابع انسانی', 'تحلیل داده'] as $c): ?>
                        <option value="<?= e($c) ?>"></option>
                    <?php endforeach; ?>
                </datalist>
            </div>
            <div class="f-field full">
                <label>زیرعنوان (معرفی کوتاه روی کارت‌ها)</label>
                <input type="text" name="subtitle" value="<?= e($product['subtitle']) ?>" maxlength="220">
            </div>
            <div class="f-field full">
                <label>توضیح کامل سامانه</label>
                <textarea name="description" rows="5" maxlength="4000" placeholder="مسئله‌ای که سامانه حل می‌کند، مخاطب آن و مزیت‌های اصلی…"><?= e($product['description']) ?></textarea>
            </div>

            <div class="f-field <?= isset($errors['image']) ? 'has-err' : '' ?>">
                <label>تصویر اصلی محصول</label>
                <div style="display:flex;gap:10px;align-items:center">
                    <input type="text" name="image" id="imageInput" value="<?= e($product['image']) ?>" dir="ltr" style="text-align:left" placeholder="assets/images/products/…">
                    <button class="btn btn-ghost btn-sm" type="button" data-media-picker="#imageInput" data-media-preview="#imagePreview">انتخاب از رسانه‌ها</button>
                </div>
                <img id="imagePreview" src="<?= $product['image'] ? e(base_url($product['image'])) : '' ?>" alt="" style="<?= $product['image'] ? '' : 'display:none' ?>width:220px;border-radius:10px;border:1px solid var(--line);margin-top:8px">
                <span class="f-err"><?= e($errors['image'] ?? '') ?></span>
            </div>
            <div class="f-field">
                <label>گالری تصاویر محصول</label>
                <input type="hidden" name="gallery" id="galleryInput" value="<?= e(json_encode($product['gallery'] ?: [], JSON_UNESCAPED_UNICODE)) ?>">
                <button class="btn btn-ghost btn-sm" type="button" id="addGalleryImages">+ انتخاب تصاویر گالری</button>
                <div class="gallery-pick" id="galleryPick" style="margin-top:10px">
                    <?php foreach (($product['gallery'] ?? []) as $g): ?>
                        <span class="gp on" data-url="<?= e($g) ?>"><img src="<?= e(base_url($g)) ?>" alt=""></span>
                    <?php endforeach; ?>
                </div>
                <span class="hint">تصاویر انتخابی به‌صورت گالری در صفحه محصول نمایش داده می‌شوند.</span>
            </div>

            <div class="f-field full" data-repeater="30">
                <label>قابلیت‌های کلیدی</label>
                <div class="repeater">
                    <div class="rep-list">
                        <?php foreach (($product['features'] ?: ['']) as $f): ?>
                        <div class="rep-row">
                            <input type="text" name="features[]" value="<?= e($f) ?>" maxlength="200" placeholder="یک قابلیت مهم سامانه…">
                            <button class="btn btn-ghost btn-sm" type="button" data-rep-del>✕</button>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <template class="rep-tpl"><div class="rep-row">
                        <input type="text" name="features[]" value="" maxlength="200" placeholder="یک قابلیت مهم سامانه…">
                        <button class="btn btn-ghost btn-sm" type="button" data-rep-del>✕</button>
                    </div></template>
                    <div><button class="btn btn-ghost btn-sm" type="button" data-rep-add>+ افزودن قابلیت</button></div>
                </div>
            </div>

            <div class="f-field full" data-repeater="20">
                <label>ماژول‌های سامانه</label>
                <div class="repeater">
                    <div class="rep-list">
                        <?php foreach (($product['modules'] ?: [['title' => '', 'description' => '']]) as $m): ?>
                        <div class="rep-row">
                            <input type="text" name="module_title[]" value="<?= e($m['title']) ?>" maxlength="150" placeholder="عنوان ماژول">
                            <textarea name="module_desc[]" maxlength="600" placeholder="شرح کوتاه ماژول"><?= e($m['description']) ?></textarea>
                            <button class="btn btn-ghost btn-sm" type="button" data-rep-del>✕</button>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <template class="rep-tpl"><div class="rep-row">
                        <input type="text" name="module_title[]" value="" maxlength="150" placeholder="عنوان ماژول">
                        <textarea name="module_desc[]" maxlength="600" placeholder="شرح کوتاه ماژول"></textarea>
                        <button class="btn btn-ghost btn-sm" type="button" data-rep-del>✕</button>
                    </div></template>
                    <div><button class="btn btn-ghost btn-sm" type="button" data-rep-add>+ افزودن ماژول</button></div>
                </div>
            </div>

            <div class="f-field full" data-repeater="20">
                <label>فناوری‌ها (برچسب‌های صفحه محصول)</label>
                <div class="repeater">
                    <div class="rep-list">
                        <?php foreach (($product['technologies'] ?: ['']) as $t): ?>
                        <div class="rep-row">
                            <input type="text" name="technologies[]" value="<?= e($t) ?>" maxlength="120" placeholder="مثال: پشتیبانی از SQL Server">
                            <button class="btn btn-ghost btn-sm" type="button" data-rep-del>✕</button>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <template class="rep-tpl"><div class="rep-row">
                        <input type="text" name="technologies[]" value="" maxlength="120">
                        <button class="btn btn-ghost btn-sm" type="button" data-rep-del>✕</button>
                    </div></template>
                    <div><button class="btn btn-ghost btn-sm" type="button" data-rep-add>+ افزودن فناوری</button></div>
                </div>
            </div>

            <div class="f-field">
                <label>نوع نسخه آزمایشی (Demo)</label>
                <select name="demo_type">
                    <option value="placeholder" <?= $product['demo_type'] === 'placeholder' ? 'selected' : '' ?>>صفحه «به‌زودی» (بدون لینک)</option>
                    <option value="direct" <?= $product['demo_type'] === 'direct' ? 'selected' : '' ?>>لینک مستقیم / زیردامنه</option>
                    <option value="iframe" <?= $product['demo_type'] === 'iframe' ? 'selected' : '' ?>>نمایش داخل صفحه (iframe)</option>
                    <option value="media" <?= $product['demo_type'] === 'media' ? 'selected' : '' ?>>تصویر یا ویدئوی معرفی</option>
                </select>
            </div>
            <div class="f-field <?= isset($errors['demo_url']) ? 'has-err' : '' ?>">
                <label>لینک نسخه آزمایشی</label>
                <input type="url" name="demo_url" value="<?= e($product['demo_url']) ?>" maxlength="500" dir="ltr" style="text-align:left" placeholder="https://demo.example.com">
                <span class="hint">برای نوع «تصویر/ویدئو» می‌توانید مسیر فایل داخل سایت را بدهید (مثال: uploads/media/intro.mp4).</span>
                <span class="f-err"><?= e($errors['demo_url'] ?? '') ?></span>
            </div>

            <div class="f-field">
                <label>وضعیت انتشار</label>
                <select name="status">
                    <option value="active" <?= $product['status'] === 'active' ? 'selected' : '' ?>>فعال (نمایش در سایت)</option>
                    <option value="inactive" <?= $product['status'] === 'inactive' ? 'selected' : '' ?>>غیرفعال (مخفی)</option>
                </select>
            </div>
            <div class="f-field">
                <label>ترتیب نمایش</label>
                <input type="number" name="display_order" value="<?= (int)$product['display_order'] ?>" min="0" max="999">
                <span class="hint">عدد کوچک‌تر = نمایش بالاتر در صفحه اصلی.</span>
            </div>
            <div class="f-check full">
                <input type="checkbox" name="featured" id="featuredChk" <?= !empty($product['featured']) ? 'checked' : '' ?>>
                <label for="featuredChk" style="cursor:pointer">نمایش به‌عنوان «سامانه منتخب» در ویترین صفحه اصلی</label>
            </div>

            <div class="f-actions full">
                <button class="btn" type="submit"><?= $id ? 'ذخیره تغییرات' : 'ایجاد و انتشار محصول' ?></button>
                <a class="btn btn-ghost" href="products.php">بازگشت به فهرست</a>
                <?php if ($id): ?>
                    <a class="btn btn-ghost" href="<?= e(base_url('products/' . $product['slug'])) ?>" target="_blank" rel="noopener">مشاهده صفحه محصول در سایت</a>
                <?php endif; ?>
            </div>
        </div>
    </form>
</div>

<script nonce="<?= e($GLOBALS['CSP_NONCE'] ?? '') ?>">
/* تولید خودکار slug از عنوان فارسی با ترجمه‌ی حرف‌به‌حرف حروف انگلیسی موجود */
document.getElementById('slugInput').addEventListener('focus', function(){});
</script>

<?php require __DIR__ . '/includes/admin-footer.php'; ?>
