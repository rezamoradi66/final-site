<?php
/**
 * admin/includes/admin-header.php — قالب مشترک پنل (سایدبار + نوار بالا)
 * متغیرها: $adminTitle، $adminActive، $pendingRequests
 * توجه: پردازش POST باید «قبل از» این فایل انجام شود (الگوی PRG)؛
 * احراز هویت قبلاً توسط admin-boot.php انجام شده است.
 */
require_once __DIR__ . '/admin-boot.php';

require_once dirname(__DIR__, 2) . '/includes/icons.php';
$adminTitle = $adminTitle ?? 'پنل مدیریت';
$adminActive = $adminActive ?? '';
$brand = Store::settings('brand_name') ?: 'مرادی‌اپ';
$logo = Store::settings('logo_image');
$menu = [
    'dashboard' => ['داشبورد', 'index.php', 'dashboard'],
    'products'  => ['محصولات و سامانه‌ها', 'products.php', 'layers'],
    'media'     => ['رسانه‌ها', 'media.php', 'docs'],
    'homepage'  => ['صفحه اصلی', 'homepage.php', 'monitor'],
    'requests'  => ['درخواست‌های دمو', 'requests.php', 'mail'],
    'settings'  => ['تنظیمات سایت', 'settings.php', 'process'],
    'users'     => ['کاربران مدیر', 'users.php', 'users'],
    'logs'      => ['گزارش فعالیت‌ها', 'logs.php', 'clock'],
    'health'    => ['سلامت سامانه', 'health.php', 'reports'],
    'security'  => ['امنیت ورود', 'security.php', 'roles'],
];
if ((string)($_SESSION['admin']['role'] ?? 'manager') !== 'admin') {
    unset($menu['settings'], $menu['users'], $menu['logs']);
}
try {
    $st = Store::db()->query("SELECT COUNT(*) c FROM demo_requests WHERE status = 'new' AND archived = 0");
    $pendingRequests = (int)$st->fetch()['c'];
} catch (Throwable $ex) {
    $pendingRequests = 0;
}
$initial = mb_substr(admin_name(), 0, 1);
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($adminTitle) ?> | پنل مدیریت <?= e($brand) ?></title>
<meta name="robots" content="noindex, nofollow">
<link rel="icon" type="image/svg+xml" href="<?= base_url('assets/images/brand/favicon.png') ?>">
<link rel="stylesheet" href="<?= asset_url('admin/assets/admin.css') ?>">
<link rel="stylesheet" href="<?= asset_url('assets/css/approved-fonts.css') ?>">
<script nonce="<?= e($GLOBALS['CSP_NONCE'] ?? '') ?>">var ADMIN_BASE = <?= json_encode(app_base() . '/') ?>;</script>
</head>
<body>
<div class="layout">
    <aside class="sidebar">
        <div class="side-brand">
            <?php if ($logo): ?>
                <img src="<?= e(base_url($logo)) ?>" alt="لوگو">
            <?php else: ?>
                <?= brand_logo_svg('38') ?>
            <?php endif; ?>
            <span><span class="bn"><?= e($brand) ?></span><br><span class="bt">پنل مدیریت</span></span>
        </div>
        <div class="nav-label">مدیریت</div>
        <?php foreach ($menu as $key => $item): ?>
        <a class="side-link <?= $adminActive === $key ? 'active' : '' ?>" href="<?= e(base_url('admin/' . $item[1])) ?>">
            <?= icon($item[2]) ?><span><?= e($item[0]) ?></span>
            <?php if ($key === 'requests' && $pendingRequests > 0): ?>
                <span class="badge-n"><?= e(fa_num((string)$pendingRequests)) ?></span>
            <?php endif; ?>
        </a>
        <?php endforeach; ?>
        <div class="side-foot">
            نسخه <?= e(fa_num(APP_VERSION)) ?><br>
            حالت: <?= Store::dbMode() ? 'دیتابیس' : 'بدون دیتابیس' ?>
        </div>
    </aside>
    <div class="content">
        <div class="topbar">
            <button class="side-toggle" type="button">☰ منو</button>
            <span class="tb-title"><?= e($adminTitle) ?></span>
            <span class="sp"></span>
            <a class="view-site" href="<?= base_url() ?>" target="_blank" rel="noopener"><?= icon('monitor') ?>مشاهده سایت</a>
            <span class="who">
                <span class="avatar"><?= e($initial) ?></span>
                <span><?= e(admin_name()) ?></span>
                <form method="post" action="<?= e(base_url('admin/logout.php')) ?>" style="display:inline"><?= csrf_field() ?><button class="btn btn-ghost btn-sm" type="submit">خروج</button></form>
            </span>
        </div>
        <?php foreach (flash_take() as $f): ?>
            <div class="flash <?= $f['t'] === 'ok' ? 'ok' : ($f['t'] === 'warn' ? 'warn' : 'err') ?>"><?= e($f['m']) ?></div>
        <?php endforeach; ?>
