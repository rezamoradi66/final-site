<?php
/**
 * auth.php — احراز هویت و امنیت پنل مدیریت
 * هر صفحه مدیریتی باید در ابتدای خود این فایل را require و require_login() را فراخوانی کند.
 */
require_once dirname(__DIR__, 2) . '/includes/bootstrap.php';

secure_session_start();

/* اگر دیتابیس پیکربندی نشده، کار مدیریتی ممکن نیست → هدایت به نصب */
if (!Store::dbMode()) {
    if (basename($_SERVER['SCRIPT_NAME'] ?? '') !== 'install.php') {
        redirect(base_url('install.php'));
    }
}

/** Rate limit by remote IP + normalized username, using locked file storage. */
function login_rate_state(string $username, bool $success = false): array
{
    $ip = (string)($_SERVER['REMOTE_ADDR'] ?? 'unknown');
    $keys = [hash('sha256', 'ip|' . $ip), hash('sha256', 'pair|' . strtolower(trim($username)) . '|' . $ip)];
    $dir = DATA_DIR . '/security'; if (!is_dir($dir)) { @mkdir($dir, 0700, true); }
    @chmod($dir, 0700);
    $file = $dir . '/login-rate.json'; $fh = @fopen($file, 'c+');
    if (!$fh) { @error_log('[LOGIN-RATE] Cannot open rate-limit storage; fail closed.'); return ['blocked'=>true,'wait'=>60]; }
    flock($fh, LOCK_EX); rewind($fh); $data = json_decode((string)stream_get_contents($fh), true); if (!is_array($data)) $data=[];
    $now=time(); $blocked=false; $maxWait=0;
    foreach ($keys as $key) {
        $state=$data[$key] ?? ['times'=>[],'blocked_until'=>0];
        $state['times']=array_values(array_filter((array)($state['times']??[]), fn($t)=>is_int($t)&&$t>$now-900));
        $wait=max(0,(int)($state['blocked_until']??0)-$now); if ($wait>0) {$blocked=true;$maxWait=max($maxWait,$wait);}
        if ($success) { unset($data[$key]); continue; }
        if (count($state['times']) >= 12) { $state['blocked_until']=max((int)($state['blocked_until']??0),$now+min(900,30*(2**min(5,count($state['times'])-12)))); }
        $state['times'][]=$now; $data[$key]=$state;
    }
    foreach ($data as $k=>$v) { if (!is_array($v) || ((int)($v['blocked_until']??0)<$now-900 && empty($v['times']))) unset($data[$k]); }
    if (count($data)>5000) $data=array_slice($data,-4000,null,true);
    rewind($fh); ftruncate($fh,0); fwrite($fh,json_encode($data)); fflush($fh); @chmod($file,0600); flock($fh,LOCK_UN); fclose($fh);
    return ['blocked'=>$blocked,'wait'=>$maxWait];
}

/** Encrypt TOTP secrets at rest; new installs use a random key in config. Legacy config derives a stable compatibility key from DB credentials until the owner adds a dedicated key. */
function mfa_key_bytes(): string
{
    $configured = (string)cfg('security.mfa_encryption_key', '');
    if (!preg_match('/^[a-f0-9]{64}$/i', $configured)) { throw new RuntimeException('Dedicated MFA encryption key is not configured'); }
    $raw = hex2bin($configured);
    if ($raw === false || strlen($raw) !== 32) { throw new RuntimeException('Invalid MFA encryption key'); }
    return hash('sha256', $raw, true);
}
function mfa_encrypt_secret(string $secret): string
{
    if (str_starts_with($secret, 'enc:v1:')) { return $secret; }
    $nonce = random_bytes(12); $tag = '';
    $cipher = openssl_encrypt($secret, 'aes-256-gcm', mfa_key_bytes(), OPENSSL_RAW_DATA, $nonce, $tag, 'MoradiApp TOTP v1', 16);
    if ($cipher === false) { throw new RuntimeException('MFA secret encryption failed'); }
    return 'enc:v1:' . base64_encode($nonce . $tag . $cipher);
}
function mfa_decrypt_secret(string $stored): string
{
    if (!str_starts_with($stored, 'enc:v1:')) { return $stored; } // legacy v3.1 secret; rotate from Security page
    $raw = base64_decode(substr($stored, 7), true);
    if ($raw === false || strlen($raw) < 29) { return ''; }
    $nonce = substr($raw, 0, 12); $tag = substr($raw, 12, 16); $cipher = substr($raw, 28);
    $plain = openssl_decrypt($cipher, 'aes-256-gcm', mfa_key_bytes(), OPENSSL_RAW_DATA, $nonce, $tag, 'MoradiApp TOTP v1');
    return $plain === false ? '' : $plain;
}

/** Base32 helpers for RFC 6238 TOTP (no external package). */
function totp_base32_encode(string $data): string
{
    $alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $bits='';
    foreach (str_split($data) as $c) $bits.=str_pad(decbin(ord($c)),8,'0',STR_PAD_LEFT);
    $out=''; foreach(str_split($bits,5) as $chunk){ if(strlen($chunk)<5)$chunk=str_pad($chunk,5,'0'); $out.=$alphabet[bindec($chunk)]; }
    return $out;
}
function totp_base32_decode(string $s): string
{
    $s=strtoupper(preg_replace('/[^A-Z2-7]/','',$s)); $alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $bits='';
    foreach(str_split($s) as $c){$pos=strpos($alphabet,$c);if($pos===false)continue;$bits.=str_pad(decbin($pos),5,'0',STR_PAD_LEFT);}
    $out=''; foreach(str_split($bits,8) as $chunk){if(strlen($chunk)===8)$out.=chr(bindec($chunk));} return $out;
}
function totp_verify(string $secret, string $code, ?int $now=null): bool
{
    if(!preg_match('/^\\d{6}$/',$code))return false; $key=totp_base32_decode($secret); if($key==='')return false;
    $time=floor(($now??time())/30);
    for($offset=-1;$offset<=1;$offset++){
        $counter=(int)($time+$offset); $bin=pack('N*',0,$counter); $hash=hash_hmac('sha1',$bin,$key,true); $o=ord($hash[19])&0x0f;
        $num=((ord($hash[$o])&0x7f)<<24)|((ord($hash[$o+1])&0xff)<<16)|((ord($hash[$o+2])&0xff)<<8)|(ord($hash[$o+3])&0xff);
        if(hash_equals(str_pad((string)($num%1000000),6,'0',STR_PAD_LEFT),$code))return true;
    } return false;
}
function establish_admin_session(array $user): void
{
    session_regenerate_id(true);
    $_SESSION['admin']=['id'=>(int)$user['id'],'username'=>$user['username'],'name'=>$user['full_name']?:$user['username'],'role'=>$user['role']?:'admin','auth_hash'=>hash('sha256',(string)($user['password_hash']??'')),'login_at'=>time(),'fprint'=>admin_fingerprint()];
    unset($_SESSION['mfa_pending']); $_SESSION['admin_last_seen']=time();
    log_activity('login','ورود موفق به پنل مدیریت');
}
function complete_totp_login(string $code): bool
{
    $pending=$_SESSION['mfa_pending']??null;
    if(!is_array($pending)||(int)($pending['expires']??0)<time()){unset($_SESSION['mfa_pending']);return false;}
    $rate=login_rate_state((string)$pending['username'],false); if($rate['blocked'])return false;
    $st=Store::db()->prepare('SELECT * FROM admin_users WHERE id=:id AND is_active=1 LIMIT 1');$st->execute([':id'=>(int)$pending['id']]);$user=$st->fetch();
    if(!$user||empty($user['totp_enabled'])||empty($user['totp_secret'])||!totp_verify(mfa_decrypt_secret((string)$user['totp_secret']),$code))return false;
    login_rate_state((string)$user['username'],true);
    Store::db()->prepare('UPDATE admin_users SET failed_attempts=0,locked_until=NULL,last_login=NOW() WHERE id=:id')->execute([':id'=>(int)$user['id']]);
    establish_admin_session($user);return true;
}

/**
 * ورود با نام کاربری/رمز عبور — محدودیت IP + نام کاربری و backoff
 */
function attempt_login(string $username, string $password): array
{
    $rate = login_rate_state($username, false);
    if ($rate['blocked']) { return [false, 'تلاش‌های ورود بیش از حد بوده است. چند دقیقه بعد دوباره امتحان کنید.']; }
    $st = Store::db()->prepare('SELECT * FROM admin_users WHERE username = :u LIMIT 1');
    $st->execute([':u' => $username]);
    $user = $st->fetch();

    /* پاسخ یکسان برای کاربر ناموجود و رمز غلط (جلوگیری از شمارش نام کاربری) */
    if (!$user) {
        usleep(random_int(120000, 260000));
        return [false, 'نام کاربری یا رمز عبور نادرست است.'];
    }
    if ((int)$user['is_active'] !== 1) {
        return [false, 'این حساب غیرفعال شده است. با مدیر اصلی سایت تماس بگیرید.'];
    }
    if (password_verify($password, (string)$user['password_hash'])) {
        if (!empty($user['totp_enabled']) && !empty($user['totp_secret'])) {
            $_SESSION['mfa_pending']=['id'=>(int)$user['id'],'username'=>$user['username'],'expires'=>time()+300];
            return [false, 'mfa_required'];
        }
        login_rate_state($username, true);
        $st2 = Store::db()->prepare('UPDATE admin_users SET failed_attempts = 0, locked_until = NULL, last_login = NOW() WHERE id = :id');
        $st2->execute([':id' => $user['id']]);
        establish_admin_session($user);
        return [true, ''];
    }

    /* ورود ناموفق */
    $failed = min(1000000, (int)$user['failed_attempts'] + 1);
    $st3 = Store::db()->prepare('UPDATE admin_users SET failed_attempts = :f, locked_until = NULL WHERE id = :id');
    $st3->execute([':f' => $failed, ':id' => $user['id']]);
    usleep(random_int(120000, 260000));
    return [false, 'نام کاربری یا رمز عبور نادرست است.'];
}

/** اثر انگشت ساده نشست برای مقابله با سرقت کوکی (UA) */
function admin_fingerprint(): string
{
    return hash('sha256', (string)($_SERVER['HTTP_USER_AGENT'] ?? '') . '|' . APP_VERSION);
}

/** بررسی نشست ورود کرده — در هر درخواست */
function require_login(): void
{
    if (empty($_SESSION['admin'])) { redirect(base_url('admin/login.php')); }
    $a = $_SESSION['admin'];
    if (($a['fprint'] ?? '') !== admin_fingerprint() || !Store::dbMode()) { admin_logout(true); }
    // Check account status, role and password version on every privileged request.
    try {
        $st = Store::db()->prepare('SELECT username, full_name, role, is_active, password_hash FROM admin_users WHERE id = :id LIMIT 1');
        $st->execute([':id' => (int)($a['id'] ?? 0)]);
        $current = $st->fetch();
    } catch (Throwable $ex) { @error_log('[AUTH-SESSION] account check failed: ' . $ex->getMessage()); admin_logout(true); }
    if (!$current || (int)$current['is_active'] !== 1 || !in_array((string)$current['role'], ['admin','manager'], true)) { admin_logout(true); }
    $currentHash = hash('sha256', (string)$current['password_hash']);
    if (empty($a['auth_hash']) || !hash_equals((string)$a['auth_hash'], $currentHash)) { admin_logout(true); }
    // Apply role/name changes immediately so UI and server authorization stay in sync.
    $_SESSION['admin']['role'] = (string)$current['role'];
    $_SESSION['admin']['username'] = (string)$current['username'];
    $_SESSION['admin']['name'] = (string)($current['full_name'] ?: $current['username']);
    $idleLimit  = ((int)cfg('app.admin_idle_minutes', 45)) * 60;
    $maxLife    = ((int)cfg('app.admin_max_hours', 8)) * 3600;
    $lastSeen   = (int)($_SESSION['admin_last_seen'] ?? time());
    if (time() - $lastSeen > $idleLimit || time() - (int)$a['login_at'] > $maxLife) {
        admin_logout(true);
    }
    $_SESSION['admin_last_seen'] = time();
}

function admin_name(): string { return $_SESSION['admin']['name'] ?? 'مدیر'; }
function admin_id(): int { return (int)($_SESSION['admin']['id'] ?? 0); }

function admin_logout(bool $silent = false): void
{
    if (!$silent && !empty($_SESSION['admin'])) {
        log_activity('logout', 'خروج از پنل مدیریت');
    }
    unset($_SESSION['admin'], $_SESSION['admin_last_seen']);
    session_regenerate_id(true);
    redirect(base_url('admin/login.php'));
}

/** ثبت فعالیت مدیریتی در گزارش */
function log_activity(string $action, string $details = ''): void
{
    if (!Store::dbMode()) { return; }
    try {
        $st = Store::db()->prepare(
            'INSERT INTO activity_log (admin_user_id, username, action, details, ip_address, created_at)
             VALUES (:uid, :un, :a, :d, :ip, NOW())'
        );
        $st->execute([
            ':uid' => admin_id() ?: null,
            ':un'  => $_SESSION['admin']['username'] ?? 'system',
            ':a'   => $action,
            ':d'   => mb_substr($details, 0, 480),
            ':ip'  => substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45),
        ]);
    } catch (Throwable $ex) {
        @error_log('[LOG] ' . $ex->getMessage());
    }
}

/* همه صفحات مدیریتی: توکن CSRF باید فعال باشد */
secure_session_start();
