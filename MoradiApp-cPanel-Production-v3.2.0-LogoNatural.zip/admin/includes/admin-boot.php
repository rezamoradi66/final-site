<?php
/**
 * admin-boot.php — راه‌اندازی پنل بدون هیچ خروجی HTML
 * هر صفحه مدیریتی باید این فایل را «قبل از» پردازش POST	require کند تا
 * ریدایرکت‌های PRG (الگوی Post/Redirect/Get) درست کار کنند.
 * سپس پس از پردازش POST، قالب از admin-header.php بارگذاری می‌شود.
 */
require_once __DIR__ . '/auth.php';
require_login();
$currentAdminFile = basename((string)($_SERVER['SCRIPT_NAME'] ?? ''));
$currentAdminRole = (string)($_SESSION['admin']['role'] ?? 'manager');
$adminOnlyFiles = ['users.php', 'settings.php', 'logs.php'];
if ($currentAdminRole !== 'admin' && in_array($currentAdminFile, $adminOnlyFiles, true)) {
    http_response_code(403);
    exit('<meta charset="utf-8"><div style="font-family:BYekan,Tahoma;direction:rtl;padding:40px">دسترسی شما به این بخش مجاز نیست.</div>');
}

