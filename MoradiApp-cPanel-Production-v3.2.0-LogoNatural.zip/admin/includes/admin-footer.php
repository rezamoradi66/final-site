<!-- admin/includes/admin-footer.php — پایان قالب مشترک پنل -->
    </div><!-- /.content -->
</div><!-- /.layout -->

<!-- مودال تأیید حذف -->
<div class="modal-overlay" data-confirm-modal role="dialog" aria-modal="true">
    <div class="modal-box">
        <h3 class="m-title">تأیید عملیات</h3>
        <p class="m-text">آیا مطمئن هستید؟</p>
        <div class="m-actions">
            <form method="post">
                <?= csrf_field() ?>
                <button class="btn btn-danger" type="submit">بله، انجام بده</button>
            </form>
            <button class="btn btn-ghost" type="button" data-cancel="1">انصراف</button>
        </div>
    </div>
</div>

<script nonce="<?= e($GLOBALS['CSP_NONCE'] ?? '') ?>" src="<?= asset_url('admin/assets/admin.js') ?>" defer></script>
</body>
</html>
