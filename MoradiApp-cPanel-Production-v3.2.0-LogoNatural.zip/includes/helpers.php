<?php
/**
 * helpers.php — توابع کمکی عمومی: URL، خروجی امن، CSRF، فلش‌پیام، تاریخ شمسی
 */

/* ---------- URL ---------- */

/** پیشوند مسیر سایت (پشتیبانی از نصب در زیرپوشه یا ساب‌دامنه) */
function app_base(): string {
    static $base = null;
    if ($base === null) {
        $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '/');
        $base = rtrim(dirname($script), '/');
        /* برای صفحات مدیریتی، ریشه سایت را محاسبه کن */
        if (substr($base, -6) === '/admin') { $base = substr($base, 0, -6); }
    }
    return $base;
}

/** ساخت لینک نسبی از ریشه سایت — مستقل از زیرپوشه نصب */
function base_url(string $path = ''): string {
    return app_base() . '/' . ltrim($path, '/');
}

/** آدرس کامل (برای canonical / sitemap / og) */
function full_url(string $path = ''): string {
    static $host = null;
    if ($host === null) { $host = (string)($_SERVER['HTTP_HOST'] ?? 'localhost'); }
    $scheme = is_https() ? 'https' : 'http';
    $configured = trim((string)Store::settings('site_url'));
    if ($configured !== '') {
        $root = rtrim($configured, '/');
    } else {
        $root = $scheme . '://' . $host . app_base();
    }
    return $root . '/' . ltrim($path, '/');
}

/** آدرس دارایی با نسخه (cache-busting) */
function asset_url(string $path): string {
    $file = APP_ROOT . '/' . ltrim($path, '/');
    $v = is_file($file) ? filemtime($file) : APP_VERSION;
    return base_url($path) . '?v=' . $v;
}

function redirect(string $url): void {
    header('Location: ' . $url);
    exit;
}

/* ---------- خروجی امن ---------- */
function e(?string $s): string {
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

/* ---------- CSRF ---------- */
function csrf_token(): string {
    secure_session_start();
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}
function csrf_field(): string {
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}
/** اعتبارسنجی توکن — در صورت نامعتبر بودن درخواست را متوقف می‌کند */
function csrf_check(): void {
    secure_session_start();
    $sent = (string)($_POST['_csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
    if ($sent === '' || !isset($_SESSION['csrf']) || !hash_equals($_SESSION['csrf'], $sent)) {
        http_response_code(403);
        exit('<meta charset="utf-8"><div style="font-family:\'B Nazanin\',\'BNazanin\',sans-serif;direction:rtl;padding:40px;background:#F7F4EE;color:#101E32;min-height:100vh">درخواست نامعتبر است (خطای امنیتی CSRF).</div>');
    }
}

/* ---------- فلش پیام ---------- */
function flash_set(string $type, string $msg): void {
    secure_session_start();
    $_SESSION['flash'][] = ['t' => $type, 'm' => $msg];
}
function flash_take(): array {
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}


/** Persistent public request rate limiter: max 12 submissions per IP per 15 minutes, 15s minimum gap. */
function contact_rate_limit_allow(string $ip): bool {
    $dir = DATA_DIR . '/security';
    if (!is_dir($dir) && !@mkdir($dir, 0700, true)) { return false; }
    @chmod($dir, 0700);
    $lockPath = $dir . '/contact-rate.lock';
    $lock = @fopen($lockPath, 'c');
    if (!$lock) { @error_log('[CONTACT-RATE] Cannot open lock file; fail closed.'); return false; }
    @chmod($lockPath, 0600);
    try {
        if (!flock($lock, LOCK_EX)) { return false; }
        $file = $dir . '/contact-rate.json';
        $data = json_decode((string)@file_get_contents($file), true);
        if (!is_array($data)) { $data = []; }
        $key = hash('sha256', 'contact|' . $ip);
        $now = time();
        $times = array_values(array_filter((array)($data[$key] ?? []), static fn($t) => is_int($t) && $t > $now - 900));
        if (count($times) >= 12 || ($times && $now - end($times) < 15)) { $data[$key] = $times; return false; }
        $times[] = $now; $data[$key] = $times;
        foreach ($data as $k => $v) { if (!is_array($v) || !$v || max($v) < $now - 900) unset($data[$k]); }
        if (count($data) > 6000) { $data = array_slice($data, -5000, null, true); }
        $tmp = $file . '.tmp-' . bin2hex(random_bytes(6));
        $json = json_encode($data, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
        if (@file_put_contents($tmp, $json, LOCK_EX) !== strlen($json)) { @unlink($tmp); return false; }
        @chmod($tmp, 0600);
        if (!@rename($tmp, $file)) { @unlink($tmp); return false; }
        @chmod($file, 0600);
        return true;
    } catch (Throwable $e) { @error_log('[CONTACT-RATE] ' . $e->getMessage()); return false; }
    finally { @flock($lock, LOCK_UN); fclose($lock); }
}

/* ---------- اعتبارسنجی ---------- */
function valid_slug(string $s): bool {
    return (bool)preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/', $s);
}
function valid_phone(string $s): bool {
    return (bool)preg_match('/^[0-9\+\-\(\)\s]{8,22}$/', $s);
}
function valid_email(string $s): bool {
    return (bool)filter_var($s, FILTER_VALIDATE_EMAIL);
}

/* ---------- تاریخ شمسی ---------- */
/** تبدیل میلادی به جلالی (الگوریتم استاندارد) */
function g2j(int $gy, int $gm, int $gd): array {
    static $g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = 355666 + (365 * $gy)
        + intdiv($gy2 + 3, 4) - intdiv($gy2 + 99, 100) + intdiv($gy2 + 399, 400)
        + $gd + $g_d_m[$gm - 1];
    $jy = -1595 + (33 * intdiv($days, 12053));
    $days %= 12053;
    $jy += 4 * intdiv($days, 1461);
    $days %= 1461;
    if ($days > 365) {
        $jy += intdiv($days - 1, 365);
        $days = ($days - 1) % 365;
    }
    if ($days < 186) {
        $jm = 1 + intdiv($days, 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + intdiv($days - 186, 30);
        $jd = 1 + (($days - 186) % 30);
    }
    return [$jy, $jm, $jd];
}

/** نمایش تاریخ/زمان شمسی از رشته DATETIME — jdate('Y/m/d H:i', $dt) */
function jdate(?string $dt, string $format = 'Y/m/d'): string {
    if (!$dt) { return '—'; }
    $ts = strtotime($dt);
    if ($ts === false) { return '—'; }
    [$jy, $jm, $jd] = g2j((int)date('Y', $ts), (int)date('n', $ts), (int)date('j', $ts));
    $months = ['', 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
    $out = str_replace(
        ['Y', 'm', 'n', 'd'],
        [(string)$jy, sprintf('%02d', $jm), (string)$jm, sprintf('%02d', $jd)],
        $format
    );
    if (strpos($out, 'H') !== false || strpos($out, 'i') !== false) {
        $out = str_replace(['H', 'i'], [date('H', $ts), date('i', $ts)], $out);
    }
    return $out;
}

/** تبدیل ارقام لاتین به فارسی برای نمایش */
function fa_num(string $s): string {
    return str_replace(['0','1','2','3','4','5','6','7','8','9'], ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'], $s);
}


/** تبدیل ارقام فارسی/عربی به لاتین (برای اعتبارسنجی تلفن و اعداد ورودی) */
function latin_digits(string $s): string {
    return str_replace(
        ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹','٠','١','٢','٣','٤','٥','٦','٧','٨','٩'],
        ['0','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6','7','8','9'],
        $s
    );
}

/** برش امن متن برای خلاصه */
function excerpt(?string $s, int $len = 160): string {
    $s = trim(strip_tags((string)$s));
    if (mb_strlen($s) <= $len) { return $s; }
    return mb_substr($s, 0, $len) . '…';
}
