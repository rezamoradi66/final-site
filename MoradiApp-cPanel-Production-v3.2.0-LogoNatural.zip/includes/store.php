<?php
/**
 * store.php — لایه دسترسی به داده‌ها
 *
 * حالت دومظاهری:
 *  1) حالت دیتابیس: پس از نصب پنل مدیریت و پیکربندی config/config.php،
 *     تمام محتوا از MySQL خوانده و نوشته می‌شود (PDO + Prepared Statements).
 *  2) حالت استاتیک: اگر دیتابیس پیکربندی نشده یا در دسترس نباشد، سایت عمومی
 *     از فایل‌های seed در پوشه data/ خوانده می‌شود تا سایت هرگز از کار نیفتد.
 *
 * ساختار داده‌ها در هر دو حالت یکسان است تا صفحات بدون تغییر کار کنند.
 */
class Store
{
    private static ?PDO $pdo = null;
    private static bool $dbMode = false;
    private static ?array $settingsCache = null;
    private static ?array $productsCache = null;
    private static ?array $defaults = null;

    /* ============================================================
       اتصال و حالت
    ============================================================ */
    public static function init(): void
    {
        $db = (array)(cfg('db') ?? []);
        if (empty($db['name']) || empty($db['user'])) { return; } // پیکربندی نشده → حالت استاتیک
        try {
            $dsn = sprintf(
                'mysql:host=%s;port=%s;dbname=%s;charset=%s',
                $db['host'] ?? 'localhost',
                $db['port'] ?? '3306',
                $db['name'],
                $db['charset'] ?? 'utf8mb4'
            );
            self::$pdo = new PDO($dsn, $db['user'], $db['pass'] ?? '', [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::ATTR_TIMEOUT            => 5,
            ]);
            self::$dbMode = true;
        } catch (Throwable $ex) {
            self::$dbMode = false;
            @error_log('[DB] اتصال ناموفق: ' . $ex->getMessage());
        }
    }

    public static function db(): ?PDO { return self::$pdo; }
    public static function dbMode(): bool { return self::$dbMode; }

    /* ============================================================
       پیش‌فرض‌ها (فایل‌های seed)
    ============================================================ */
    private static function defaults(): array
    {
        if (self::$defaults === null) {
            $settingsFile  = DATA_DIR . '/site-content.json';
            $productsFile  = DATA_DIR . '/products.json';
            self::$defaults = [
                'settings' => is_file($settingsFile) ? (json_decode((string)file_get_contents($settingsFile), true) ?: []) : [],
                'products' => is_file($productsFile) ? (json_decode((string)file_get_contents($productsFile), true) ?: []) : [],
            ];
        }
        return self::$defaults;
    }

    /* ============================================================
       تنظیمات سایت
    ============================================================ */
    /** خواندن تنظیمات؛ با کلید مشخص یا کل آرایه */
    public static function settings(?string $key = null, $default = null)
    {
        $all = self::settingsAll();
        if ($key === null) { return $all; }
        return $all[$key] ?? $default;
    }

    private static function settingsAll(): array
    {
        if (self::$settingsCache !== null) { return self::$settingsCache; }
        $out = self::defaults()['settings'];
        if (self::$dbMode) {
            try {
                $rows = self::$pdo->query('SELECT setting_key, setting_value FROM site_settings')->fetchAll();
                foreach ($rows as $r) {
                    $k = $r['setting_key'];
                    $v = $r['setting_value'];
                    /* مقادیر آرایه‌ای به‌صورت JSON ذخیره می‌شوند */
                    $decoded = json_decode((string)$v, true);
                    $out[$k] = (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) ? $decoded : $v;
                }
            } catch (Throwable $ex) {
                @error_log('[DB] settings: ' . $ex->getMessage());
            }
        }
        self::$settingsCache = $out;
        return $out;
    }

    /** ذخیره چند کلید تنظیمات (فقط حالت دیتابیس) */
    public static function saveSettings(array $kv): bool
    {
        if (!self::$dbMode) { return false; }
        try {
            $st = self::$pdo->prepare(
                'INSERT INTO site_settings (setting_key, setting_value, updated_at)
                 VALUES (:k, :v, NOW())
                 ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = NOW()'
            );
            foreach ($kv as $k => $v) {
                $st->execute([
                    ':k' => $k,
                    ':v' => is_array($v) ? json_encode($v, JSON_UNESCAPED_UNICODE) : (string)$v,
                ]);
            }
            self::$settingsCache = null;
            return true;
        } catch (Throwable $ex) {
            @error_log('[DB] saveSettings: ' . $ex->getMessage());
            return false;
        }
    }

    /* ============================================================
       محصولات
    ============================================================ */
    public static function products(bool $onlyActive = true): array
    {
        $items = self::productsAll();
        if ($onlyActive) {
            $items = array_values(array_filter($items, fn($p) => ($p['status'] ?? 'active') === 'active'));
        }
        usort($items, fn($a, $b) => [$a['display_order'] ?? 0, $a['id'] ?? 0] <=> [$b['display_order'] ?? 0, $b['id'] ?? 0]);
        return $items;
    }

    public static function product(string $slug): ?array
    {
        foreach (self::productsAll() as $p) {
            if (($p['slug'] ?? '') === $slug) { return $p; }
        }
        return null;
    }

    private static function productsAll(): array
    {
        if (self::$productsCache !== null) { return self::$productsCache; }
        $out = [];
        $dbReadSucceeded = false;
        if (self::$dbMode) {
            try {
                $rows = self::$pdo->query(
                    'SELECT id, slug, title, subtitle, description, category, image, gallery, features,
                            modules, technologies, demo_url, demo_type, status, featured, display_order,
                            created_at, updated_at
                     FROM products'
                )->fetchAll();
                $dbReadSucceeded = true;
                foreach ($rows as $r) { $out[] = self::normalizeProduct($r); }
            } catch (Throwable $ex) {
                @error_log('[DB] products: ' . $ex->getMessage());
            }
        }
        /* Empty table is a valid state (all products intentionally removed). */
        if (!self::$dbMode || !$dbReadSucceeded) {
            $seed = self::defaults()['products'];
            foreach ($seed as $i => $p) { $p['id'] = $i + 1; $out[] = $p; }
        }
        self::$productsCache = $out;
        return $out;
    }

    public static function normalizeProduct(array $r): array
    {
        $jsonFields = ['gallery', 'features', 'modules', 'technologies'];
        foreach ($jsonFields as $f) {
            $dec = json_decode((string)($r[$f] ?? '[]'), true);
            $r[$f] = is_array($dec) ? $dec : [];
        }
        $r['featured']      = (int)($r['featured'] ?? 0) === 1;
        $r['display_order'] = (int)($r['display_order'] ?? 0);
        $r['id']            = (int)$r['id'];
        return $r;
    }

    /** ذخیره محصول (ایجاد/ویرایش) — فقط حالت دیتابیس */
    public static function saveProduct(array $p): int
    {
        if (!self::$dbMode) { return 0; }
        $cols = [
            'slug' => $p['slug'], 'title' => $p['title'],
            'subtitle' => $p['subtitle'] ?? '', 'description' => $p['description'] ?? '',
            'category' => $p['category'] ?? '', 'image' => $p['image'] ?? '',
            'gallery' => json_encode(array_values($p['gallery'] ?? []), JSON_UNESCAPED_UNICODE),
            'features' => json_encode(array_values($p['features'] ?? []), JSON_UNESCAPED_UNICODE),
            'modules' => json_encode(array_values($p['modules'] ?? []), JSON_UNESCAPED_UNICODE),
            'technologies' => json_encode(array_values($p['technologies'] ?? []), JSON_UNESCAPED_UNICODE),
            'demo_url' => $p['demo_url'] ?? '', 'demo_type' => $p['demo_type'] ?? 'placeholder',
            'status' => $p['status'] ?? 'active',
            'featured' => !empty($p['featured']) ? 1 : 0,
            'display_order' => (int)($p['display_order'] ?? 0),
        ];
        try {
            if (!empty($p['id'])) {
                $set = implode(', ', array_map(fn($c) => "$c = :$c", array_keys($cols)));
                $cols['id'] = (int)$p['id'];
                $st = self::$pdo->prepare("UPDATE products SET $set, updated_at = NOW() WHERE id = :id");
                $st->execute($cols);
                self::$productsCache = null;
                return (int)$p['id'];
            }
            $names = implode(', ', array_keys($cols));
            $marks = implode(', ', array_map(fn($c) => ":$c", array_keys($cols)));
            $st = self::$pdo->prepare("INSERT INTO products ($names) VALUES ($marks)");
            $st->execute($cols);
            self::$productsCache = null;
            return (int)self::$pdo->lastInsertId();
        } catch (Throwable $ex) {
            @error_log('[DB] saveProduct: ' . $ex->getMessage());
            throw $ex;
        }
    }

    public static function deleteProduct(int $id): bool
    {
        if (!self::$dbMode) { return false; }
        try {
            $st = self::$pdo->prepare('DELETE FROM products WHERE id = :id');
            $st->execute([':id' => $id]);
            self::$productsCache = null;
            return true;
        } catch (Throwable $ex) {
            @error_log('[DB] deleteProduct: ' . $ex->getMessage());
            return false;
        }
    }

    public static function slugExists(string $slug, int $exceptId = 0): bool
    {
        if (!self::$dbMode) {
            foreach (self::defaults()['products'] as $p) {
                if ($p['slug'] === $slug && (int)($p['id'] ?? 0) !== $exceptId) { return true; }
            }
            return false;
        }
        $st = self::$pdo->prepare('SELECT COUNT(*) c FROM products WHERE slug = :s AND id <> :id');
        $st->execute([':s' => $slug, ':id' => $exceptId]);
        return (int)$st->fetch()['c'] > 0;
    }

    /* ============================================================
       درخواست‌های دمو
    ============================================================ */
    /** ثبت درخواست عمومی — اگر DB باشد در جدول، وگرنه در صندوق فایلی ذخیره می‌شود */
    public static function saveRequest(array $req): bool
    {
        if (self::$dbMode) {
            try {
                $st = self::$pdo->prepare(
                    'INSERT INTO demo_requests
                        (full_name, organization, phone, email, product_id, product_title, message, status, ip_address, created_at)
                     VALUES (:fn, :org, :ph, :em, :pid, :pt, :msg, :st, :ip, NOW())'
                );
                $st->execute([
                    ':fn'  => $req['full_name'], ':org' => $req['organization'],
                    ':ph'  => $req['phone'], ':em' => $req['email'],
                    ':pid' => $req['product_id'] ?: null, ':pt' => $req['product_title'],
                    ':msg' => $req['message'], ':st' => 'new', ':ip' => $req['ip_address'],
                ]);
                return true;
            } catch (Throwable $ex) {
                @error_log('[DB] saveRequest: ' . $ex->getMessage());
                /* در صورت خطا، به صندوق فایلی برمی‌گردیم تا هیچ درخواستی از دست نرود */
            }
        }
        return self::saveRequestFallback($req);
    }

    private static function saveRequestFallback(array $req): bool
    {
        $dir = DATA_DIR . '/inbox';
        if (!is_dir($dir) && !@mkdir($dir, 0700, true)) { return false; }
        @chmod($dir, 0700);
        $file = $dir . '/requests-' . date('Y-m') . '.json';
        $lockPath = $dir . '/.requests-' . date('Y-m') . '.lock';
        $lock = @fopen($lockPath, 'c');
        if (!$lock) { return false; }
        @chmod($lockPath, 0600);
        try {
            if (!flock($lock, LOCK_EX)) { return false; }
            $raw = is_file($file) ? (string)@file_get_contents($file) : '[]';
            $items = json_decode($raw, true);
            if (!is_array($items)) { $items = []; }
            $req['status'] = 'new';
            $req['created_at'] = date('Y-m-d H:i:s');
            $req['_fallback_id'] = bin2hex(random_bytes(16));
            $items[] = $req;
            return self::writeFallbackQueueLocked($file, $items);
        } catch (Throwable $ex) { @error_log('[FALLBACK-SAVE] ' . $ex->getMessage()); return false; }
        finally { @flock($lock, LOCK_UN); fclose($lock); }
    }

    /** Caller must hold the stable month lock file; replace queue atomically. */
    private static function writeFallbackQueueLocked(string $file, array $items): bool
    {
        $json = json_encode(array_values($items), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR);
        $tmp = $file . '.tmp-' . bin2hex(random_bytes(6));
        $bytes = @file_put_contents($tmp, $json, LOCK_EX);
        if ($bytes !== strlen($json)) { @unlink($tmp); return false; }
        @chmod($tmp, 0600);
        if (!@rename($tmp, $file)) { @unlink($tmp); return false; }
        @chmod($file, 0600);
        return true;
    }

    /** فهرست امن صندوق درخواست‌های ذخیره‌شده هنگام اختلال دیتابیس */
    public static function fallbackRequests(): array
    {
        $out = [];
        $dir = DATA_DIR . '/inbox';
        foreach (glob($dir . '/requests-????-??.json') ?: [] as $file) {
            $name = basename($file);
            if (!preg_match('/^requests-(\\d{4}-\\d{2})\\.json$/', $name, $m)) { continue; }
            $items = json_decode((string)@file_get_contents($file), true);
            if (!is_array($items)) { continue; }
            foreach ($items as $idx => $req) {
                if (!is_array($req)) { continue; }
                $out[] = ['file' => $name, 'month' => $m[1], 'index' => (int)$idx, 'ref' => hash('sha256', $name . '|' . json_encode($req, JSON_UNESCAPED_UNICODE)), 'request' => $req];
            }
        }
        usort($out, fn($a,$b) => strcmp((string)($b['request']['created_at'] ?? ''),(string)($a['request']['created_at'] ?? '')));
        return $out;
    }

    /** Import one fallback item idempotently and remove it atomically from the file queue. */
    public static function importFallbackRequest(string $fileName, int $index, string $expectedRef): string
    {
        if (!self::$dbMode || !preg_match('/^requests-\d{4}-\d{2}\.json$/', $fileName) || $index < 0) { return 'invalid'; }
        $path = DATA_DIR . '/inbox/' . $fileName;
        if (!is_file($path)) { return 'missing'; }
        $month = substr($fileName, 9, 7);
        $lockPath = DATA_DIR . '/inbox/.requests-' . $month . '.lock';
        $lock = @fopen($lockPath, 'c');
        if (!$lock) { return 'unavailable'; }
        @chmod($lockPath, 0600);
        try {
            if (!flock($lock, LOCK_EX)) { return 'unavailable'; }
            $items = json_decode((string)@file_get_contents($path), true);
            if (!is_array($items) || !isset($items[$index]) || !is_array($items[$index])) { return 'missing'; }
            $req = $items[$index];
            $ref = hash('sha256', $fileName . '|' . json_encode($req, JSON_UNESCAPED_UNICODE));
            if (!hash_equals($expectedRef, $ref)) { return 'stale'; }
            self::$pdo->exec("CREATE TABLE IF NOT EXISTS request_fallback_imports (fallback_ref CHAR(64) NOT NULL PRIMARY KEY, request_id INT UNSIGNED NOT NULL, imported_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, KEY idx_fallback_request (request_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $check = self::$pdo->prepare('SELECT request_id FROM request_fallback_imports WHERE fallback_ref = :r');
            $check->execute([':r' => $ref]);
            if (!$check->fetchColumn()) {
                self::$pdo->beginTransaction();
                $ins = self::$pdo->prepare('INSERT INTO demo_requests (full_name, organization, phone, email, product_id, product_title, message, status, ip_address, created_at) VALUES (:fn,:org,:ph,:em,:pid,:pt,:msg,:st,:ip,:created)');
                $ins->execute([
                    ':fn'=>mb_substr((string)($req['full_name']??''),0,120), ':org'=>mb_substr((string)($req['organization']??''),0,150),
                    ':ph'=>mb_substr((string)($req['phone']??''),0,30), ':em'=>mb_substr((string)($req['email']??''),0,150),
                    ':pid'=>!empty($req['product_id'])?(int)$req['product_id']:null, ':pt'=>mb_substr((string)($req['product_title']??''),0,180),
                    ':msg'=>mb_substr((string)($req['message']??''),0,5000), ':st'=>'new',
                    ':ip'=>mb_substr((string)($req['ip_address']??''),0,45), ':created'=>date('Y-m-d H:i:s', strtotime((string)($req['created_at']??'now')) ?: time())
                ]);
                $rid=(int)self::$pdo->lastInsertId();
                $mark=self::$pdo->prepare('INSERT INTO request_fallback_imports (fallback_ref, request_id) VALUES (:r,:id)');
                $mark->execute([':r'=>$ref,':id'=>$rid]);
                self::$pdo->commit();
            }
            unset($items[$index]);
            return self::writeFallbackQueueLocked($path, array_values($items)) ? 'ok' : 'error';
        } catch (Throwable $ex) {
            if (self::$pdo && self::$pdo->inTransaction()) { self::$pdo->rollBack(); }
            @error_log('[FALLBACK-IMPORT] '.$ex->getMessage());
            return 'error';
        } finally { @flock($lock, LOCK_UN); fclose($lock); }
    }

    /* ============================================================
       همگام‌سازی DB → فایل‌های استاتیک (پشتیبان/حالت آفلاین)
    ============================================================ */
    public static function syncStaticData(): bool
    {
        if (!self::$dbMode) { return false; }
        $ok = true;
        self::$productsCache = null;
        self::$defaults = null;
        $products = array_map(function ($p) {
            unset($p['created_at'], $p['updated_at']);
            return $p;
        }, self::products(false));
        $settings = self::settings();

        $ok = $ok && (bool)@file_put_contents(
            DATA_DIR . '/products.json',
            json_encode($products, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX
        );
        $ok = $ok && (bool)@file_put_contents(
            DATA_DIR . '/site-content.json',
            json_encode($settings, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX
        );
        self::$defaults = null;
        self::$productsCache = null;
        self::$settingsCache = null;
        return $ok;
    }
}
