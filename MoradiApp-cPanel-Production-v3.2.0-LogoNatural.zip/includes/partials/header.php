<?php
/**
 * partials/header.php — سربرگ مشترک صفحات عمومی (نسخه ۲.۰ پریمیوم)
 * متغیرهای موردنیاز پیش از include:
 *   $pageTitle (string)  عنوان صفحه
 *   $pageDesc  (string)  توضیحات متا
 *   $pageBodyClass (string|null) کلاس body
 */
require_once dirname(__DIR__) . '/icons.php';
$S = Store::settings();
$brand = $S['brand_name'] ?: 'مرادی‌اپ';
$logoPath = (string)($S['logo_image'] ?? '');
if ($logoPath === 'assets/images/brand/logo.png' && is_file(APP_ROOT . '/assets/images/brand/logo.webp')) { $logoPath = 'assets/images/brand/logo.webp'; }
$logo  = $logoPath !== '' ? base_url($logoPath) : '';
$navItems = [
    ['label' => 'محصولات',   'href' => base_url('products')],
    ['label' => 'قابلیت‌ها', 'href' => base_url('#services')],
    ['label' => 'درباره ما', 'href' => base_url('about')],
    ['label' => 'ارتباط با ما', 'href' => base_url('contact')],
];
$ogPath = (string)($S['og_image'] ?: 'assets/images/og-image.webp');
if ($ogPath === 'assets/images/brand/logo.png' && is_file(APP_ROOT . '/assets/images/brand/logo.webp')) { $ogPath = 'assets/images/brand/logo.webp'; }
$ogImage = full_url($ogPath);
// canonical همیشه path تمیز و بدون query/UTM است؛ مسیرهای مستقیم PHP به نسخه clean نگاشت می‌شوند.
$reqPath = parse_url((string)($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH) ?: '/';
$basePath = rtrim(app_base(), '/');
if ($basePath !== '' && str_starts_with($reqPath, $basePath . '/')) { $reqPath = substr($reqPath, strlen($basePath)); }
$reqPath = '/' . ltrim($reqPath, '/');
$script = basename((string)($_SERVER['SCRIPT_NAME'] ?? ''));
$canonicalPath = match ($script) {
    'index.php' => '', 'about.php' => 'about', 'contact.php' => 'contact', 'products.php' => 'products',
    'product.php' => 'products/' . (string)($_GET['slug'] ?? ''), 'demo.php' => 'demos/' . (string)($_GET['slug'] ?? ''),
    'sitemap.php' => 'sitemap.xml', default => trim($reqPath, '/')
};
$canonical = full_url($canonicalPath);
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle ?? $S['site_title']) ?></title>
<meta name="description" content="<?= e($pageDesc ?? $S['site_description']) ?>">
<meta name="keywords" content="<?= e($S['seo_keywords'] ?? '') ?>">
<meta name="robots" content="index, follow">
<link rel="canonical" href="<?= e($canonical) ?>">
<meta property="og:type" content="website">
<meta property="og:site_name" content="<?= e($brand) ?>">
<meta property="og:title" content="<?= e($pageTitle ?? $S['site_title']) ?>">
<meta property="og:description" content="<?= e($pageDesc ?? $S['site_description']) ?>">
<meta property="og:image" content="<?= e($ogImage) ?>">
<meta property="og:locale" content="fa_IR">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" type="image/png" href="<?= base_url('assets/images/brand/favicon.png') ?>">
<link rel="stylesheet" href="<?= asset_url('assets/css/main.css') ?>">
<link rel="stylesheet" href="<?= asset_url('assets/css/approved-fonts.css') ?>">
</head>
<body<?= isset($pageBodyClass) && $pageBodyClass ? ' class="' . e($pageBodyClass) . '"' : '' ?>>

<div class="scroll-progress" aria-hidden="true"></div>

<header class="site-header">
    <div class="container header-in">
        <a class="brand" href="<?= base_url() ?>" aria-label="<?= e($brand) ?>">
            <?php if ($logo): ?>
                <img class="mark" src="<?= e($logo) ?>" alt="لوگوی <?= e($brand) ?>" width="86" height="45">
            <?php else: ?>
                <?= brand_logo_svg() ?>
            <?php endif; ?>
            <span>
                <span class="bname"><?= e($brand) ?></span>
                <span class="btag"><?= e($S['brand_tagline']) ?></span>
            </span>
        </a>
        <nav class="main-nav" aria-label="منوی اصلی">
            <?php foreach ($navItems as $item): ?>
                <a href="<?= e($item['href']) ?>"><?= e($item['label']) ?></a>
            <?php endforeach; ?>
        </nav>
        <a class="btn btn-primary btn-sm header-cta" href="<?= base_url('contact#request-form') ?>">درخواست دمو</a>
        <button class="burger" type="button" aria-label="باز کردن منو" aria-expanded="false"><span></span></button>
    </div>
</header>

<nav class="mobile-menu" id="mobileMenu" aria-label="منوی موبایل">
    <?php foreach ($navItems as $item): ?>
        <a href="<?= e($item['href']) ?>"><?= e($item['label']) ?></a>
    <?php endforeach; ?>
    <a href="<?= base_url('contact#request-form') ?>">درخواست دمو</a>
</nav>

<main>
