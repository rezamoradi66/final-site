<?php
/**
 * partials/footer.php — فوتر مینیمال مشترک صفحات عمومی
 */
$Sf = Store::settings();
$fBrand = $Sf['brand_name'] ?: 'مرادی‌اپ';
$socials = (array)($Sf['social'] ?? []);
$socialLinks = [
    'telegram'  => ['telegram',  'تلگرام'],
    'instagram' => ['instagram', 'اینستاگرام'],
    'linkedin'  => ['linkedin',  'لینکدین'],
    'whatsapp'  => ['whatsapp',  'واتس‌اپ'],
];
$productLinks = array_slice(Store::products(), 0, 5);
$footerLogoPath = (string)($Sf['logo_image'] ?? '');
if ($footerLogoPath === 'assets/images/brand/logo.png' && is_file(APP_ROOT . '/assets/images/brand/logo.webp')) { $footerLogoPath = 'assets/images/brand/logo.webp'; }
?>
</main>

<footer class="site-footer">
    <div class="container">
        <div class="footer-grid">
            <div>
                <a class="brand" href="<?= base_url() ?>">
                    <?php if (!empty($Sf['logo_image'])): ?>
                        <img class="mark" src="<?= e(base_url($footerLogoPath)) ?>" alt="لوگوی <?= e($fBrand) ?>" width="86" height="45">
                    <?php else: ?>
                        <?= brand_logo_svg() ?>
                    <?php endif; ?>
                    <span>
                        <span class="bname"><?= e($fBrand) ?></span>
                        <span class="btag"><?= e($Sf['brand_tagline']) ?></span>
                    </span>
                </a>
                <p style="margin-top:14px"><?= e($Sf['footer_text'] ?: $Sf['brand_desc']) ?></p>
                <?php $hasSocial = false; ob_start(); ?>
                <?php foreach ($socialLinks as $key => $meta): ?>
                    <?php if (!empty($socials[$key])): $hasSocial = true; ?>
                        <a href="<?= e($socials[$key]) ?>" target="_blank" rel="noopener" aria-label="<?= e($meta[1]) ?>" title="<?= e($meta[1]) ?>"><?= icon($meta[0]) ?></a>
                    <?php endif; ?>
                <?php endforeach; ?>
                <?php $socialHtml = ob_get_clean(); ?>
                <?php if ($hasSocial): ?><div class="footer-social"><?= $socialHtml ?></div><?php endif; ?>
            </div>
            <div>
                <h4>دسترسی سریع</h4>
                <ul>
                    <li><a href="<?= base_url() ?>">صفحه اصلی</a></li>
                    <li><a href="<?= base_url('products') ?>">همه سامانه‌ها</a></li>
                    <li><a href="<?= base_url('about') ?>">درباره ما</a></li>
                    <li><a href="<?= base_url('contact') ?>">ارتباط با ما</a></li>
                    <li><a href="<?= base_url('contact#request-form') ?>">درخواست دمو</a></li>
                    <li><a href="<?= base_url('privacy') ?>">سیاست حریم خصوصی</a></li>
                </ul>
            </div>
            <div>
                <h4>سامانه‌ها</h4>
                <ul>
                    <?php foreach ($productLinks as $p): ?>
                        <li><a href="<?= e(base_url('products/' . $p['slug'])) ?>"><?= e($p['title']) ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <div>
                <h4>اطلاعات تماس</h4>
                <ul class="footer-contact">
                    <li><?= icon('phone') ?><span><?= e($Sf['contact_phone'] ?: '—') ?></span></li>
                    <li><?= icon('mail') ?><span><?= e($Sf['contact_email'] ?: '—') ?></span></li>
                    <li><?= icon('location') ?><span><?= e($Sf['contact_address'] ?: '—') ?></span></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <span><?= e($Sf["copyright"] ?: ("© " . $fBrand)) ?></span>
            <span>نسخه <?= e(fa_num(APP_VERSION)) ?></span>
        </div>
    </div>
</footer>

<script nonce="<?= e($GLOBALS['CSP_NONCE'] ?? '') ?>" src="<?= asset_url('assets/js/main.js') ?>" defer></script>
</body>
</html>
