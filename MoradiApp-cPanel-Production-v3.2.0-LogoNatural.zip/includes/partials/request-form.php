<?php
/**
 * partials/request-form.php — فرم درخواست دمو (مشترک در صفحات مختلف)
 * متغیرهای اختیاری: $prefillProduct (slug)، $formSuccess (bool)، $formError (bool)
 * منطق فیلدها، نام‌ها، CSRF و تله اسپم دقیقاً مطابق نسخه پشتیبان حفظ شده است.
 */
$products = Store::products();
$old = $_SESSION['form_old'] ?? []; unset($_SESSION['form_old']);
$errs = $_SESSION['form_errors'] ?? []; unset($_SESSION['form_errors']);
$val = fn($k, $d = '') => e($old[$k] ?? $d);
$selProduct = (string)($prefillProduct ?? $old['product'] ?? '');
$formSuccess = !empty($formSuccess);
$formError = !empty($formError);
?>
<div class="request-wrap" id="request-form">
    <div class="sec-head center" style="margin-bottom:30px">
        <span class="eyebrow"><span class="idx">۰۷</span>درخواست دمو</span>
        <h2 class="sec-title">آماده تجربه یک راهکار هوشمند هستید؟</h2>
        <p class="sec-lead">اطلاعات خود را ثبت کنید تا برای ارائه نسخه آزمایشی و توضیح امکانات سامانه موردنظر با شما تماس بگیریم.</p>
    </div>

    <div class="request-card">
        <div class="form-msg<?= $formSuccess ? ' ok' : '' ?>" role="status">درخواست شما با موفقیت ثبت شد. کارشناسان ما در نخستین فرصت با شما تماس خواهند گرفت.</div>
        <div class="form-msg<?= $formError ? ' bad' : '' ?>" role="alert">ثبت درخواست انجام نشد. لطفاً اطلاعات واردشده را بررسی کنید و دوباره تلاش نمایید.</div>

        <form id="demoRequestForm" method="post" action="<?= base_url('contact') ?>" novalidate>
            <?= csrf_field() ?>
            <!-- تله ضد اسپم: کاربران واقعی این فیلد را نمی‌بینند و پر نمی‌کنند -->
            <div class="hp-field" aria-hidden="true">
                <label>وب‌سایت</label>
                <input type="text" name="website" tabindex="-1" autocomplete="off">
            </div>
            <div class="form-grid">
                <div class="form-field">
                    <label for="rf_name">نام و نام خانوادگی <span class="req">*</span></label>
                    <input id="rf_name" type="text" name="full_name" value="<?= $val('full_name') ?>" maxlength="120" placeholder="مثال: علی محمدی">
                    <span class="form-err" data-for="full_name">نام و نام خانوادگی را کامل وارد کنید.</span>
                </div>
                <div class="form-field">
                    <label for="rf_org">نام سازمان <span class="req">*</span></label>
                    <input id="rf_org" type="text" name="organization" value="<?= $val('organization') ?>" maxlength="150" placeholder="نام شرکت یا سازمان">
                    <span class="form-err" data-for="organization">نام سازمان را وارد کنید.</span>
                </div>
                <div class="form-field">
                    <label for="rf_phone">شماره تماس <span class="req">*</span></label>
                    <input id="rf_phone" type="tel" name="phone" value="<?= $val('phone') ?>" maxlength="22" placeholder="مثال: 09121234567" dir="ltr" style="text-align:right">
                    <span class="form-err" data-for="phone">شماره تماس معتبر نیست.</span>
                </div>
                <div class="form-field">
                    <label for="rf_email">ایمیل</label>
                    <input id="rf_email" type="email" name="email" value="<?= $val('email') ?>" maxlength="150" placeholder="name@example.com" dir="ltr" style="text-align:right">
                    <span class="form-err" data-for="email">ایمیل معتبر نیست.</span>
                </div>
                <div class="form-field full">
                    <label for="rf_product">سامانه موردنظر</label>
                    <select id="rf_product" name="product">
                        <option value="">— انتخاب کنید —</option>
                        <?php foreach ($products as $p): ?>
                            <option value="<?= e($p['slug']) ?>" <?= $selProduct === $p['slug'] ? 'selected' : '' ?>><?= e($p['title']) ?></option>
                        <?php endforeach; ?>
                        <option value="other" <?= $selProduct === 'other' ? 'selected' : '' ?>>سامانه‌های دیگر / مشاوره</option>
                    </select>
                </div>
                <div class="form-field full">
                    <label for="rf_msg">توضیحات</label>
                    <textarea id="rf_msg" name="message" maxlength="2000" placeholder="نیاز سازمان خود را در چند جمله بنویسید تا ارائه هدفمندتری داشته باشیم…"><?= $val('message') ?></textarea>
                    <span class="form-err" data-for="message">توضیحات طولانی است.</span>
                </div>
                <div class="form-actions full">
                    <button class="btn btn-primary" type="submit">ثبت درخواست دمو</button>
                    <span class="note">اطلاعات شما فقط برای تماس درباره همین درخواست استفاده می‌شود.</span>
                </div>
            </div>
        </form>
    </div>
</div>
