<?php
/**
 * partials/hero-visual.php — صحنه سینمایی Hero (نسخه ۲.۰)
 * پنجره‌های نرم‌افزاری شناور با پارالاکس چندلایه + خطوط داده متحرک
 * کاملاً CSS/SVG داخلی؛ بدون تصویر خارجی و بدون وابستگی.
 */
?>
<div class="hero-stage" aria-hidden="true">
    <!-- لایه خطوط داده (پارالاکس کم‌عمق) -->
    <span class="hs-layer" data-depth="0.14">
        <svg class="hs-lines" viewBox="0 0 600 560" preserveAspectRatio="none">
            <path d="M 150 120 C 260 60, 340 90, 435 148" />
            <path d="M 430 300 C 360 360, 280 380, 190 420" />
            <circle class="pulse" r="4">
                <animateMotion dur="5.5s" repeatCount="indefinite" path="M 150 120 C 260 60, 340 90, 435 148" />
            </circle>
            <circle class="pulse" r="4">
                <animateMotion dur="6.5s" repeatCount="indefinite" path="M 430 300 C 360 360, 280 380, 190 420" />
            </circle>
        </svg>
    </span>

    <!-- لایه پنجره گردش کار -->
    <span class="hs-layer" data-depth="0.26">
        <div class="hs-window hs-w3" style="--tilt: 1.6deg">
            <div class="w-head"><i></i><i></i><i></i><b>گردش کار و تأییدات</b></div>
            <div class="hs-flow"><i></i><i></i><i></i><i></i><i></i><i></i></div>
        </div>
    </span>

    <!-- لایه پنجره اصلی داشبورد -->
    <span class="hs-layer" data-depth="0.4">
        <div class="hs-window hs-w1" style="--tilt: -1.2deg">
            <div class="w-head"><i></i><i></i><i></i><b>داشبورد مدیریت — نمای کلان</b></div>
            <div class="hs-kpis">
                <div class="hs-kpi"><span class="l">اعتبار مصوب</span><span class="v">۱۲٬۸۴۵</span><span class="trend">▲ ۸٪</span></div>
                <div class="hs-kpi"><span class="l">پروژه فعال</span><span class="v">۲۳</span></div>
                <div class="hs-kpi"><span class="l">درخواست در گردش</span><span class="v">۱۲</span></div>
            </div>
            <div class="hs-bars">
                <i style="--h:52; --i:0"></i><i style="--h:74; --i:1"></i><i style="--h:38; --i:2"></i>
                <i style="--h:86; --i:3"></i><i style="--h:60; --i:4"></i><i style="--h:92; --i:5"></i>
                <i style="--h:48; --i:6"></i>
            </div>
        </div>
    </span>

    <!-- لایه پنجره تحلیل -->
    <span class="hs-layer" data-depth="0.55">
        <div class="hs-window hs-w2" style="--tilt: 1.1deg">
            <div class="w-head"><i></i><i></i><i></i><b>تحلیل داده</b></div>
            <div class="hs-donut-row">
                <div class="hs-donut"></div>
                <div class="hs-legend">
                    <span><i style="background:var(--primary)"></i>پروژه‌های عمرانی ۳۸٪</span>
                    <span><i style="background:var(--accent)"></i>خرید و تأمین ۳۲٪</span>
                    <span><i style="background:var(--sky)"></i>سایر ۳۰٪</span>
                </div>
            </div>
        </div>
    </span>

    <!-- چیپ‌های شناور -->
    <div class="hs-chip c1">
        <span class="ico"><?= icon('check') ?></span>
        <span><b>تأیید نهایی اعتبار</b><small>گردش کار چندمرحله‌ای</small></span>
    </div>
    <div class="hs-chip c2">
        <span class="ico blue"><?= icon('reports') ?></span>
        <span><b>گزارش لحظه‌ای</b><small>پیشرفت فیزیکی و مالی</small></span>
    </div>
</div>
