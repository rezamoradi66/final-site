<?php
/**
 * bootstrap.php — هسته راه‌اندازی برنامه
 * این فایل باید در ابتدای تمام صفحات (عمومی و مدیریتی) require شود.
 *
 * سازگار با PHP 8.1+ (تست‌شده روی 8.3/8.4) — هاست cPanel / LiteSpeed / Linux
 */

/* ---------- محیط و خطاها ---------- */
define('APP_VERSION', '3.2.0');
define('BASE_PATH_REAL', dirname(__DIR__)); // مسیر واقعی ریشه سایت روی دیسک

ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
error_reporting(E_ALL);

date_default_timezone_set('Asia/Tehran');
mb_internal_encoding('UTF-8');

/* مسیرها */
define('APP_ROOT',  BASE_PATH_REAL);
define('DATA_DIR',  APP_ROOT . '/data');
define('LOG_DIR',   DATA_DIR . '/logs');
define('CONFIG_DIR', APP_ROOT . '/config');
define('UPLOAD_DIR', APP_ROOT . '/uploads');

/* Upgrade hardening: protect an existing DB config immediately on first v3.2 request. */
$configFileForPerms = CONFIG_DIR . '/config.php';
if (is_file($configFileForPerms)) {
    $mode = @fileperms($configFileForPerms);
    if ($mode !== false && (($mode & 0777) !== 0600)) { if (!@chmod($configFileForPerms, 0600)) { @error_log('[SECURITY] Could not chmod config.php to 0600'); } }
    $dirMode = @fileperms(CONFIG_DIR);
    if ($dirMode !== false && (($dirMode & 0777) !== 0700)) { if (!@chmod(CONFIG_DIR, 0700)) { @error_log('[SECURITY] Could not chmod config directory to 0700'); } }
}

/* پوشه لاگ */
if (!is_dir(LOG_DIR)) { @mkdir(LOG_DIR, 0755, true); }
$logFile = is_dir(LOG_DIR) && is_writable(LOG_DIR) ? LOG_DIR . '/php-error.log' : null;
if ($logFile) { ini_set('error_log', $logFile); }

/* نمایش خطای کنترل‌شده در حالت دیباگ */
$appCfgTmp = null;
if (is_file(CONFIG_DIR . '/config.php')) { $appCfgTmp = require CONFIG_DIR . '/config.php'; }
define('APP_DEBUG', (bool)($appCfgTmp['app']['debug'] ?? false));
unset($appCfgTmp);
if (APP_DEBUG) { ini_set('display_errors', '1'); }

/* هندلر خطای سراسری برای صفحات عمومی */
set_exception_handler(function (Throwable $e) {
    @error_log('[EXCEPTION] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    if (APP_DEBUG) {
        http_response_code(500);
        echo '<meta charset="utf-8"><div style="font-family:\'B Nazanin\',\'BNazanin\',sans-serif;direction:rtl;padding:40px;background:#F7F4EE;color:#101E32;min-height:100vh">'
           . 'خطای برنامه: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</div>';
    } else {
        http_response_code(500);
        @include dirname(__DIR__) . '/500.php';
    }
    exit;
});

/* ---------- پیکربندی ---------- */
$GLOBALS['APP_CONFIG'] = null;
if (is_file(CONFIG_DIR . '/config.php')) {
    $GLOBALS['APP_CONFIG'] = require CONFIG_DIR . '/config.php';
}
function cfg(string $path, $default = null) {
    $node = $GLOBALS['APP_CONFIG'];
    foreach (explode('.', $path) as $k) {
        if (!is_array($node) || !array_key_exists($k, $node)) { return $default; }
        $node = $node[$k];
    }
    return $node === null ? $default : $node;
}
/* ---------- هدرهای دفاعی سراسری ---------- */
$GLOBALS['CSP_NONCE'] = base64_encode(random_bytes(18));
if (!headers_sent()) {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    header('Cross-Origin-Opener-Policy: same-origin');
    header('Cross-Origin-Resource-Policy: same-origin');
    /* Nonce برای inline scriptها؛ script-src بدون unsafe-inline است. استایل inline به دلیل قالب فعلی مجاز مانده است. */
    header("Content-Security-Policy: default-src 'self'; base-uri 'self'; object-src 'none'; frame-ancestors 'self'; form-action 'self'; script-src 'self' 'nonce-" . $GLOBALS['CSP_NONCE'] . "'; script-src-attr 'none'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https:; font-src 'self' data:; media-src 'self' https:; frame-src 'self' https:; upgrade-insecure-requests");
    if (is_https()) { header('Strict-Transport-Security: max-age=15552000'); }
}

function cfg_set(string $path, $value): bool {
    $node = &$GLOBALS['APP_CONFIG'];
    foreach (explode('.', $path) as $k) { $node = &$node[$k]; }
    $node = $value;
    return true;
}

/* ---------- نشست امن ---------- */
function secure_session_start(): void {
    if (session_status() === PHP_SESSION_ACTIVE) { return; }
    $name = cfg('app.session_name', 'moradiapp_ses');
    session_name($name);
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'domain'   => '',
        'secure'   => is_https(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_start();
    /* محافظت در برابر ثابت‌ماندن شناسه نشست */
    if (!isset($_SESSION['__init'])) {
        session_regenerate_id(true);
        $_SESSION['__init'] = true;
    }
}

function is_https(): bool {
    if (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off') { return true; }
    if (($_SERVER['SERVER_PORT'] ?? '') == 443) { return true; }
    return false;
}

/* اجبار HTTPS به host مشخص‌شده در config؛ از redirect به HTTP_HOST خام جلوگیری می‌شود. */
if (cfg('security.force_https', false) && !is_https()) {
    $canonicalHost = strtolower(trim((string)cfg('app.canonical_host', 'moradiapp.ir')));
    if (!preg_match('/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)*[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/i', $canonicalHost)) { $canonicalHost = 'moradiapp.ir'; }
    if ($canonicalHost === 'www.moradiapp.ir') { $canonicalHost = 'moradiapp.ir'; }
    $uri = (string)($_SERVER['REQUEST_URI'] ?? '/');
    if (!str_starts_with($uri, '/') || str_starts_with($uri, '//')) { $uri = '/'; }
    header('Location: https://' . $canonicalHost . $uri, true, 301);
    exit;
}

/* ---------- بارگذاری ماژول‌ها ---------- */
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/store.php';

/* ---------- شروع هسته داده ---------- */
Store::init();
