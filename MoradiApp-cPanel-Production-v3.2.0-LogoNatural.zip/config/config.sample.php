<?php
/**
 * config.sample.php — نمونه فایل پیکربندی (نسخه امن‌شده)
 *
 * راهنما:
 *  1) این فایل را به «config.php» تغییر نام (یا کپی) کنید.
 *  2) مقادیر دیتابیس را از بخش «Databases» کنترل پنل cPanel وارد کنید.
 *  3) ویزارد نصب (install.php) این کار را به‌صورت خودکار انجام می‌دهد.
 *
 * امنیت: این فایل از طریق .htaccess از دسترسی وب مسدود شده و اگر ممکن است
 * بهتر است کل پوشه config/ را یک سطح بالاتر از public_html قرار دهید و
 * مسیرها را با ثابت‌های DATA_DIR/CONFIG_DIR در includes/bootstrap.php هماهنگ کنید.
 */
return [
    'db' => [
        'host'    => 'localhost',   // در cPanel معمولاً localhost است
        'port'    => '3306',
        'name'    => '',            // نام دیتابیس، مثال: user_moradi
        'user'    => '',            // نام کاربر دیتابیس
        'pass'    => '',            // رمز کاربر دیتابیس
        'charset' => 'utf8mb4',
    ],
    'app' => [
        'debug'              => false,          // هرگز روی هاست اصلی true نگذارید
        'session_name'       => 'moradiapp_ses',
        'canonical_host'     => 'moradiapp.ir', // برای staging مقدار hostname همان محیط را وارد کنید
        'admin_idle_minutes' => 45,             // مهلت بی‌کاری نشست مدیریت (دقیقه)
        'admin_max_hours'    => 8,              // حداکثر عمر نشست مدیریت (ساعت)
    ],
    'security' => [
        'force_https'       => true,  // با فعال بودن SSL پیشنهاد می‌شود true شود
        'mfa_encryption_key' => '', // در پنل امنیت ورود، کلید تصادفی مستقل بسازید؛ نصب‌کننده این مقدار را خودکار تولید می‌کند
        'login_max_attempts'=> 5,      // legacy setting; actual throttle is IP + username
        'login_lock_minutes'=> 15,     // مدت قفل حساب پس از تلاش‌های ناموفق
    ],
    'uploads' => [
        'max_size_mb' => 4,
        'allowed'     => ['jpg', 'jpeg', 'png', 'webp', 'gif'],
    ],
];
