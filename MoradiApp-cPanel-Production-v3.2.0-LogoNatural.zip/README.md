# MoradiApp.ir — نسخه نهایی قابل نصب روی cPanel (v3.2.0)

این بسته برای هاست اصلی **Linux / cPanel / LiteSpeed / PHP 8.3 / MySQL** آماده شده است.
دامنه هدف: `https://moradiapp.ir`؛ سامانه `plan.moradiapp.ir` جداگانه باقی می‌ماند.

## امکانات
- صفحه اصلی بر پایه طرح تأییدشده و فایل موشن Liquid Light + Silk Brook
- لوگوی رسمی و تصاویر طرح مرجع به‌صورت محلی؛ بدون CDN یا وابستگی خارجی
- فونت‌های BYekan و BKoodak مطابق فایل مرجع تأییدشده؛ BTitr نیز به‌عنوان فایل فونت پیوست در بسته قرار دارد
- پنل مدیریت واقعی با MySQL: محصولات/سامانه‌ها، محتوای صفحه اصلی، رسانه‌ها، درخواست‌های دمو، تنظیمات برند و سئو، کاربران مدیر و گزارش فعالیت
- محصولات اولیه خالی هستند؛ هیچ محصول نمونه، آمار ساختگی، تلفن یا ایمیل جعلی منتشر نمی‌شود
- آمار صفحه اصلی فقط پس از ثبت مقادیر واقعی از پنل نمایش داده می‌شود
- احراز هویت مدیر، هش رمز، محدودیت تلاش ورود، قفل موقت، CSRF، نشست امن، Prepared Statements، ثبت فعالیت، کنترل نقش مدیر/مدیر محتوا
- فرم درخواست دمو با اعتبارسنجی، honeypot و محدودیت ارسال
- صفحات محصولات، جزئیات محصول، درباره ما، تماس، sitemap، robots، 404 و 500
- پشتیبانی از SSL/HTTPS، هدرهای امنیتی، حفاظت پوشه‌های حساس و جلوگیری از اجرای PHP در uploads

## نصب روی cPanel
راهنمای گام‌به‌گام: `docs/INSTALL-cPanel.md`

خلاصه:
1. از سایت و دیتابیس فعلی نسخه پشتیبان بگیرید.
2. در cPanel یک MySQL Database و Database User بسازید و دسترسی کامل بدهید.
3. محتوای ZIP را در `public_html` دامنه `moradiapp.ir` استخراج کنید.
4. پوشه‌های `data/`, `data/logs/` و `uploads/media/` باید قابل نوشتن باشند (معمولاً 755؛ در صورت نیاز مالکیت/ACL هاست را اصلاح کنید؛ از 777 دائمی استفاده نکنید).
5. در مرورگر `https://moradiapp.ir/install.php` را باز و ویزارد را کامل کنید؛ رمز دیتابیس و رمز مدیر را فقط در ویزارد وارد کنید.
6. بعد از نصب، از داشبورد حذف `install.php` را اجرا کنید و مطمئن شوید فایل حذف شده است.
7. ورود پنل: `https://moradiapp.ir/admin/login.php`
8. در پنل، صفحه اصلی، تنظیمات سایت، محصولات و رسانه‌ها را تکمیل کنید.

## مهم
- این ZIP برای نصب روی cPanel است؛ روی Windows/IIS و SQL Server نصب نمی‌شود.
- `plan.moradiapp.ir` سامانه جداگانه است؛ دکمه ورود سایت به‌صورت پیش‌فرض به آن متصل است و از تنظیمات قابل تغییر است.
- پیش از انتشار، اطلاعات تماس، لینک‌های ورود/ثبت‌نام و محتوای محصولات را از پنل وارد کنید.
- هیچ رمز یا اطلاعات دیتابیس در ZIP قرار ندارد.

Installer is setup-key protected in v3.2.0. Create `config/setup.key` from the sample and replace the placeholder with a private random 32+ character key before installation.


## v3.2.0 release notes

See `docs/AUDIT-REMEDIATION-REPORT-v3.2.0-FA.md` and `docs/RELEASE-VALIDATION-v3.2.0-FA.md` for remediation details and staging validation scope.
