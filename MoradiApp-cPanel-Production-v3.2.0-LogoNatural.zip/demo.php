<?php
/**
 * demo.php — صفحه نسخه آزمایشی هر سامانه
 * انواع دمو پشتیبانی‌شده:
 *   direct      → دکمه ورود به لینک مستقیم/زیردامنه
 *   iframe      → نمایش در قالب صفحه داخلی
 *   media       → نمایش تصویر یا ویدئوی معرفی
 *   placeholder → صفحه «به‌زودی» حرفه‌ای
 * آدرس تمیز: /demos/{slug}
 */
require_once __DIR__ . '/includes/bootstrap.php';
secure_session_start();

$slug = (string)($_GET['slug'] ?? '');
$p = Store::product($slug);
if (!$p || $p['status'] !== 'active') {
    http_response_code(404);
    require __DIR__ . '/404.php';
    exit;
}

$S = Store::settings();
$type = $p['demo_type'] ?: 'placeholder';
$demoUrl = (string)$p['demo_url'];
$hasDemo = $type !== 'placeholder' && $demoUrl !== '';

$pageTitle = 'نسخه آزمایشی ' . $p['title'];
$pageDesc  = 'ورود به نسخه آزمایشی ' . $p['title'] . ' و تجربه مستقیم امکانات سامانه.';

require __DIR__ . '/includes/partials/header.php';
?>
<section class="page-hero">
    <div class="container">
        <div class="crumb"><a href="<?= base_url() ?>">خانه</a> / <a href="<?= base_url('products') ?>">سامانه‌ها</a> / <a href="<?= e(base_url('products/' . $p['slug'])) ?>"><?= e($p['title']) ?></a> / نسخه آزمایشی</div>
    </div>
</section>

<section style="padding-bottom:90px">
    <div class="container demo-shell">
        <div class="demo-card-box">
            <span class="demo-ico"><?= icon('play') ?></span>
            <h1>نسخه آزمایشی <?= e($p['title']) ?></h1>
            <p class="sub"><?= $hasDemo
                ? 'با ورود به محیط آزمایشی، امکانات سامانه را با داده‌های نمونه تجربه کنید. محیط آزمایشی از سامانه عملیاتی سازمان کاملاً جداست.'
                : 'نسخه آزمایشی این سامانه در حال آماده‌سازی است. با ثبت درخواست دمو، نسخه اختصاصی برای شما فعال خواهد شد و در همین صفحه لینک ورود نمایش داده می‌شود.' ?></p>

            <?php if ($type === 'iframe' && $hasDemo): ?>
                <div class="demo-frame-wrap">
                    <iframe src="<?= e($demoUrl) ?>" title="نسخه آزمایشی <?= e($p['title']) ?>"
                            loading="lazy" referrerpolicy="no-referrer"
                            sandbox="allow-scripts allow-forms"></iframe>
                </div>
                <p style="color:var(--text-2);font-size:13px;margin-top:14px">
                    اگر محیط آزمایشی نمایش داده نشود، سامانه مقصد اجازه نمایش داخل قالب (iframe) ندارد؛
                    <a href="<?= e($demoUrl) ?>" target="_blank" rel="noopener">از اینجا در تب جدید باز کنید</a>.
                </p>
            <?php elseif ($type === 'direct' && $hasDemo): ?>
                <div class="demo-steps">
                    <div class="ds"><b>۱. ورود به محیط</b><span>روی دکمه زیر کلیک کنید؛ محیط آزمایشی در تب جدید باز می‌شود.</span></div>
                    <div class="ds"><b>۲. داده‌های نمونه</b><span>همه اطلاعات موجود، داده‌های آزمایشی هستند و هرگز با داده‌های واقعی سازمان اشتراکی نیست.</span></div>
                    <div class="ds"><b>۳. ثبت درخواست</b><span>پس از بازدید، برای ارائه اختصاصی فرم درخواست دمو را تکمیل کنید.</span></div>
                </div>
                <a class="btn btn-primary btn-lg" href="<?= e($demoUrl) ?>" target="_blank" rel="noopener">
                    <?= icon('play') ?>ورود به محیط آزمایشی
                </a>
            <?php elseif ($type === 'media' && $hasDemo): ?>
                <div class="demo-frame-wrap">
                    <?php if (preg_match('/\.(mp4|webm)(?:[?#].*)?$/i', $demoUrl)): ?>
                        <video src="<?= e(preg_match('#^https?://#i', $demoUrl) ? $demoUrl : base_url(ltrim($demoUrl, '/'))) ?>" controls style="width:100%;display:block;max-height:640px;background:#000"></video>
                    <?php else: ?>
                        <img src="<?= e(str_starts_with($demoUrl, 'http') ? $demoUrl : base_url($demoUrl)) ?>" alt="معرفی <?= e($p['title']) ?>" style="width:100%;display:block">
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <div class="demo-steps">
                    <div class="ds"><b>۱. آماده‌سازی محیط</b><span>یک نسخه نمونه با داده‌های آزمایشی برای سازمان شما مستقر می‌شود.</span></div>
                    <div class="ds"><b>۲. ارائه راهنما</b><span>در یک جلسه کوتاه، امکانات و سناریوهای اصلی سامانه معرفی می‌شود.</span></div>
                    <div class="ds"><b>۳. فعال‌سازی لینک</b><span>لینک ورود اختصاصی، در همین صفحه فعال خواهد شد.</span></div>
                </div>
                <a class="btn btn-primary" href="<?= e(base_url('contact') . '?product=' . rawurlencode($p['slug'])) ?>#request-form">
                    درخواست فعال‌سازی نسخه آزمایشی
                </a>
            <?php endif; ?>

            <div style="display:flex;gap:14px;align-items:center;justify-content:center;margin-top:26px;flex-wrap:wrap;color:var(--text-2);font-size:13.5px">
                <?= icon('shield') ?> محیط آزمایشی از سامانه عملیاتی کاملاً جداست.
            </div>
        </div>
    </div>
</section>

<?php require __DIR__ . '/includes/partials/footer.php'; ?>
