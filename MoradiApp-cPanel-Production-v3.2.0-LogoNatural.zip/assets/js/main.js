/* =====================================================================
   MoradiApp — Premium Immersive Showcase | main.js (نسخه ۲.۰)
   موتور حرکت اختصاصی — بدون هیچ وابستگی خارجی
   اصول: فقط transform/opacity، rAF، IntersectionObserver، passive listeners
   پشتیبانی کامل prefers-reduced-motion
   ===================================================================== */
(function () {
    'use strict';

    var d = document;
    var root = d.documentElement;
    root.classList.add('js');

    var mqMobile = window.matchMedia('(max-width: 920px)');
    var mqReduce = window.matchMedia('(prefers-reduced-motion: reduce)');
    var isMobile = mqMobile.matches;
    var reduceMotion = mqReduce.matches;
    if (mqReduce.addEventListener) {
        mqReduce.addEventListener('change', function (e) { reduceMotion = e.matches; });
    }

    /* ============================================================
       ۱) نوار پیشرفت اسکرول + وضعیت هدر
    ============================================================ */
    var progressBar = d.querySelector('.scroll-progress');
    var header = d.querySelector('.site-header');

    /* ============================================================
       ۲) پارالاکس Hero (موس + اسکرول) — فقط دسکتاپ و بدون کاهش حرکت
    ============================================================ */
    var hero = d.querySelector('.hero');
    var heroLayers = [];
    if (hero) {
        heroLayers = Array.prototype.slice.call(hero.querySelectorAll('.hs-layer[data-depth]'));
    }
    var mouseTx = 0, mouseTy = 0;

    function applyHeroParallax() {
        if (reduceMotion || isMobile || !hero) return;
        var r = hero.getBoundingClientRect();
        /* پارالاکس اسکرول: تا وقتی Hero در دید است */
        var sy = Math.min(Math.max(-r.top, 0), r.height);
        heroLayers.forEach(function (layer) {
            var depth = parseFloat(layer.getAttribute('data-depth')) || 0;
            layer.style.transform =
                'translate3d(' + mouseTx * depth + 'px,' + (mouseTy * depth + sy * depth * 0.35) + 'px,0)';
        });
    }

    if (hero && !isMobile && !reduceMotion) {
        hero.addEventListener('mousemove', function (ev) {
            var r = hero.getBoundingClientRect();
            mouseTx = ((ev.clientX - r.left) / r.width - 0.5) * 18;
            mouseTy = ((ev.clientY - r.top) / r.height - 0.5) * 14;
        }, { passive: true });
        hero.addEventListener('mouseleave', function () { mouseTx = 0; mouseTy = 0; }, { passive: true });
        /* تیلت ملایم قاب‌ها */
        d.querySelectorAll('.show-media .frame, .pd-shot .frame').forEach(function (frame) {
            frame.addEventListener('mousemove', function (ev) {
                var r = frame.getBoundingClientRect();
                var dx = (ev.clientX - r.left) / r.width - 0.5;
                var dy = (ev.clientY - r.top) / r.height - 0.5;
                frame.style.transform =
                    'perspective(1400px) rotateY(' + (dx * 5) + 'deg) rotateX(' + (-dy * 5) + 'deg)';
            }, { passive: true });
            frame.addEventListener('mouseleave', function () {
                frame.style.transform = '';
            }, { passive: true });
        });
    }

    /* ============================================================
       ۳) حلقه اسکرول واحد (rAF) — پیشرفت، هدر، ریل ویترین
    ============================================================ */
    var showcase = d.querySelector('.showcase');
    var showRowsWrap = d.querySelector('.show-rows');
    var ticking = false;

    function onFrame() {
        ticking = false;
        var y = window.scrollY || root.scrollTop;
        var vh = window.innerHeight;

        if (header) header.classList.toggle('scrolled', y > 24);
        if (progressBar) {
            var doc = d.documentElement;
            var max = doc.scrollHeight - vh;
            progressBar.style.transform = 'scaleX(' + (max > 0 ? Math.min(y / max, 1) : 0) + ')';
        }
        if (showcase && showRowsWrap && !reduceMotion) {
            var r = showRowsWrap.getBoundingClientRect();
            var p = (vh * 0.55 - r.top) / (r.height + vh * 0.2);
            p = Math.min(Math.max(p, 0), 1);
            showcase.style.setProperty('--rail-p', p.toFixed(3));
        }
        applyHeroParallax();
    }
    function requestTick() {
        if (!ticking) { ticking = true; requestAnimationFrame(onFrame); }
    }
    window.addEventListener('scroll', requestTick, { passive: true });
    window.addEventListener('resize', requestTick, { passive: true });
    onFrame();

    /* ============================================================
       ۴) نمایان‌سازی هنگام اسکرول (Reveal)
    ============================================================ */
    var revealEls = d.querySelectorAll('.reveal, .statement, .j-steps');
    if ('IntersectionObserver' in window && !reduceMotion) {
        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) {
                if (en.isIntersecting) {
                    en.target.classList.add('in-view');
                    io.unobserve(en.target);
                }
            });
        }, { threshold: 0.14, rootMargin: '0px 0px -48px 0px' });
        revealEls.forEach(function (el) { io.observe(el); });
    } else {
        revealEls.forEach(function (el) { el.classList.add('in-view'); });
    }

    /* ============================================================
       ۵) ریل ویترین: نقطه فعال هر محصول
    ============================================================ */
    var showRows = d.querySelectorAll('.show-row');
    var railDots = d.querySelectorAll('.show-rail .rail-dot');
    if (showRows.length && railDots.length && 'IntersectionObserver' in window) {
        var rowIo = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) {
                if (!en.isIntersecting) return;
                var idx = Array.prototype.indexOf.call(showRows, en.target);
                railDots.forEach(function (dot, i) { dot.classList.toggle('active', i === idx); });
            });
        }, { rootMargin: '-42% 0px -42% 0px', threshold: 0 });
        showRows.forEach(function (row) { rowIo.observe(row); });
    }

    /* ============================================================
       ۶) منوی موبایل
    ============================================================ */
    var burger = d.querySelector('.burger');
    var mobileMenu = d.getElementById('mobileMenu');
    if (burger && mobileMenu) {
        mobileMenu.querySelectorAll('a').forEach(function (a, i) {
            a.style.setProperty('--i', i);
        });
        burger.addEventListener('click', function () {
            var open = mobileMenu.classList.toggle('open');
            burger.classList.toggle('open', open);
            burger.setAttribute('aria-expanded', open ? 'true' : 'false');
            d.body.style.overflow = open ? 'hidden' : '';
        });
        mobileMenu.querySelectorAll('a').forEach(function (a) {
            a.addEventListener('click', function () {
                mobileMenu.classList.remove('open');
                burger.classList.remove('open');
                d.body.style.overflow = '';
            });
        });
    }

    /* ============================================================
       ۷) هایلایت لینک فعال منو در صفحه اصلی
    ============================================================ */
    var navLinks = d.querySelectorAll('.main-nav a[href*="#"]');
    var sections = [];
    navLinks.forEach(function (a) {
        var hash = a.getAttribute('href').split('#')[1];
        if (hash) {
            var sec = d.getElementById(hash);
            if (sec) sections.push({ link: a, sec: sec });
        }
    });
    if (sections.length && 'IntersectionObserver' in window) {
        var navIo = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) {
                if (en.isIntersecting) {
                    navLinks.forEach(function (a) { a.classList.remove('active'); });
                    sections.forEach(function (s) {
                        if (s.sec === en.target) s.link.classList.add('active');
                    });
                }
            });
        }, { rootMargin: '-40% 0px -55% 0px' });
        sections.forEach(function (s) { navIo.observe(s.sec); });
    }

    /* ============================================================
       ۸) چرخه یکپارچه (Journey) — تعاملی
    ============================================================ */
    var jSteps = d.querySelectorAll('.j-step');
    var jDetail = d.getElementById('jDetail');
    if (jSteps.length && jDetail) {
        var flowData = [];
        try {
            var fdEl = d.getElementById('flowData');
            if (fdEl) flowData = JSON.parse(fdEl.textContent || '[]');
        } catch (e) { flowData = []; }

        function showStep(i) {
            jSteps.forEach(function (s, idx) { s.classList.toggle('active', idx === i); });
            var item = flowData[i];
            if (!item) return;
            jDetail.replaceChildren();
            var title = d.createElement('h3'); title.textContent = String(item.title || '');
            var desc = d.createElement('p'); desc.textContent = String(item.desc || '');
            jDetail.appendChild(title); jDetail.appendChild(desc);
            var points = Array.isArray(item.points) ? item.points : [];
            if (points.length) {
                var wrap = d.createElement('div'); wrap.className = 'j-points';
                points.forEach(function (point) { var span = d.createElement('span'); span.textContent = String(point || ''); wrap.appendChild(span); });
                jDetail.appendChild(wrap);
            }
            if (!isMobile && !reduceMotion && jDetail.animate) {
                jDetail.animate(
                    [{ opacity: 0, transform: 'translateY(12px)' }, { opacity: 1, transform: 'none' }],
                    { duration: 300, easing: 'cubic-bezier(.16,1,.3,1)' }
                );
            }
        }
        jSteps.forEach(function (s, i) {
            s.setAttribute('tabindex', '0');
            s.setAttribute('role', 'button');
            s.addEventListener('click', function () { showStep(i); });
            s.addEventListener('keydown', function (ev) {
                if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); showStep(i); }
            });
        });
        if (jSteps[0]) showStep(0);
    }

    /* ============================================================
       ۹) شمارنده آمار (فقط آمار واقعی ثبت‌شده)
    ============================================================ */
    var statNums = d.querySelectorAll('.stat-card .num[data-count]');
    if (statNums.length && 'IntersectionObserver' in window && !reduceMotion) {
        var so = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) {
                if (!en.isIntersecting) return;
                var el = en.target;
                var target = parseInt(el.getAttribute('data-count'), 10) || 0;
                var suffix = el.getAttribute('data-suffix') || '';
                var t0 = null;
                function tick(ts) {
                    if (!t0) t0 = ts;
                    var p = Math.min((ts - t0) / 1400, 1);
                    var val = Math.round(target * (1 - Math.pow(1 - p, 3)));
                    el.textContent = faDigits(String(val)) + suffix;
                    if (p < 1) requestAnimationFrame(tick);
                }
                requestAnimationFrame(tick);
                so.unobserve(el);
            });
        }, { threshold: 0.4 });
        statNums.forEach(function (el) { so.observe(el); });
    }
    function faDigits(s) {
        return s.replace(/[0-9]/g, function (c) { return '۰۱۲۳۴۵۶۷۸۹'[+c]; });
    }

    /* ============================================================
       ۱۰) اعتبارسنجی سمت کاربر فرم درخواست دمو
    ============================================================ */
    window.__bindFormValidation = function () {
        var form = d.getElementById('demoRequestForm');
        if (!form || form.__validated) return;
        form.__validated = true;
        var phoneField = form.querySelector('[name="phone"]');
        if (phoneField && !phoneField.__faDigits) {
            phoneField.__faDigits = true;
            phoneField.addEventListener('input', function () {
                phoneField.value = phoneField.value.replace(/[۰-۹٠-٩]/g, function (c) {
                    var fa = '۰۱۲۳۴۵۶۷۸۹', ar = '٠١٢٣٤٥٦٧٨٩';
                    var i = fa.indexOf(c);
                    return i > -1 ? String(i) : String(ar.indexOf(c));
                });
            });
        }
        form.addEventListener('submit', function (ev) {
            var ok = true;
            function fail(name, msg) {
                var input = form.querySelector('[name="' + name + '"]');
                var err = form.querySelector('.form-err[data-for="' + name + '"]');
                if (input) input.classList.add('err');
                if (err) { err.textContent = msg; err.classList.add('show'); }
                ok = false;
            }
            form.querySelectorAll('.err').forEach(function (el) { el.classList.remove('err'); });
            form.querySelectorAll('.form-err.show').forEach(function (el) { el.classList.remove('show'); });

            var name = (form.querySelector('[name="full_name"]') || {}).value || '';
            var org = (form.querySelector('[name="organization"]') || {}).value || '';
            var phone = (form.querySelector('[name="phone"]') || {}).value || '';
            var email = (form.querySelector('[name="email"]') || {}).value || '';
            var msg = (form.querySelector('[name="message"]') || {}).value || '';

            if (name.trim().length < 3) fail('full_name', 'نام و نام خانوادگی را کامل وارد کنید.');
            if (org.trim().length < 2) fail('organization', 'نام سازمان را وارد کنید.');
            if (!/^[0-9\+\-\(\)\s]{8,22}$/.test(phone.trim())) fail('phone', 'شماره تماس معتبر نیست (مثال: 09121234567).');
            if (email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) fail('email', 'ایمیل معتبر نیست.');
            if (msg.length > 2000) fail('message', 'توضیحات نمی‌تواند بیش از ۲۰۰۰ کاراکتر باشد.');

            if (!ok) {
                ev.preventDefault();
                var firstErr = form.querySelector('.err');
                if (firstErr) firstErr.focus();
            }
        });
    };
    window.__bindFormValidation();

    /* ============================================================
       ۱۱) لایت‌باکس گالری محصول
    ============================================================ */
    var lightbox = d.getElementById('lightbox');
    if (lightbox) {
        var lbImg = lightbox.querySelector('img');
        d.querySelectorAll('.pd-gallery figure img').forEach(function (img) {
            img.parentElement.addEventListener('click', function () {
                lbImg.src = img.src.replace(/\?v=\d+$/, '?v=' + Date.now());
                lbImg.alt = img.alt || '';
                lightbox.classList.add('open');
                d.body.style.overflow = 'hidden';
            });
        });
        function closeLb() {
            lightbox.classList.remove('open');
            d.body.style.overflow = '';
        }
        lightbox.addEventListener('click', function (ev) {
            if (ev.target === lightbox || ev.target.classList.contains('lb-close')) closeLb();
        });
        d.addEventListener('keydown', function (ev) {
            if (ev.key === 'Escape') closeLb();
        });
    }

    /* ============================================================
       ۱۲) اسکرول نرم به فرم پس از خطای سمت سرور
    ============================================================ */
    if (location.hash === '#demoRequestForm' || location.hash === '#request') {
        var target = d.getElementById('demoRequestForm') || d.getElementById('request');
        if (target) {
            setTimeout(function () {
                target.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'center' });
            }, 60);
        }
    }
})();
