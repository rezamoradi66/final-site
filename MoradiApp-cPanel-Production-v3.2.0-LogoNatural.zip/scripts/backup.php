<?php
/* CLI-only encrypted backup; requires MORADIAPP_BACKUP_KEY from a secret external to webroot. */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once dirname(__DIR__).'/includes/bootstrap.php';
if (!Store::dbMode()) { fwrite(STDERR,"DB connection unavailable\n"); exit(2); }
$secret = (string)getenv('MORADIAPP_BACKUP_KEY');
if (strlen($secret) < 32) { fwrite(STDERR,"MORADIAPP_BACKUP_KEY must be set to at least 32 characters\n"); exit(3); }
if (!function_exists('openssl_encrypt')) { fwrite(STDERR,"OpenSSL extension is required\n"); exit(4); }
$pdo=Store::db(); $dir=DATA_DIR.'/backups'; if(!is_dir($dir)&&!mkdir($dir,0700,true)){fwrite(STDERR,"Cannot create backup directory\n");exit(5);} @chmod($dir,0700);
$stamp=date('Ymd-His'); $tmp=$dir.'/moradiapp-'.$stamp.'.sql.gz.tmp'; $gzPath=$dir.'/moradiapp-'.$stamp.'.sql.gz'; $out=$dir.'/moradiapp-'.$stamp.'.sql.gz.enc';
@umask(0077); $gz=gzopen($tmp,'wb9'); if(!$gz){fwrite(STDERR,"Cannot write backup\n");exit(6);} @chmod($tmp,0600);
gzwrite($gz,"-- MoradiApp database backup {$stamp}\nSET FOREIGN_KEY_CHECKS=0;\n");
$tables=$pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
foreach($tables as $table){ if(!preg_match('/^[A-Za-z0-9_]+$/',$table))continue; $qt='`'.str_replace('`','``',$table).'`'; $create=$pdo->query('SHOW CREATE TABLE '.$qt)->fetch(PDO::FETCH_NUM); gzwrite($gz,"\nDROP TABLE IF EXISTS {$qt};\n".$create[1].";\n");
 $rows=$pdo->query('SELECT * FROM '.$qt); while($row=$rows->fetch(PDO::FETCH_NUM)){ $vals=[]; foreach($row as $v){$vals[]=$v===null?'NULL':$pdo->quote((string)$v);} gzwrite($gz,'INSERT INTO '.$qt.' VALUES ('.implode(',',$vals).");\n"); }
}
gzwrite($gz,"SET FOREIGN_KEY_CHECKS=1;\n"); gzclose($gz);
$plain=@file_get_contents($tmp); if($plain===false){@unlink($tmp);fwrite(STDERR,"Cannot read temporary backup\n");exit(7);} @unlink($tmp);
$key=hash('sha256',$secret,true); $nonce=random_bytes(12); $tag=''; $cipher=openssl_encrypt($plain,'aes-256-gcm',$key,OPENSSL_RAW_DATA,$nonce,$tag,'MoradiApp backup v1',16); unset($plain);
if($cipher===false){fwrite(STDERR,"Backup encryption failed\n");exit(8);}
$payload="MAPPBKP1".$nonce.$tag.$cipher; $written=@file_put_contents($out,$payload,LOCK_EX); if($written!==strlen($payload)){@unlink($out);fwrite(STDERR,"Cannot write encrypted backup\n");exit(9);} @chmod($out,0600);
foreach(glob($dir.'/moradiapp-*.sql.gz.enc')?:[] as $f){if(filemtime($f)<time()-14*86400)@unlink($f);}
foreach(glob($dir.'/moradiapp-*.sql.gz')?:[] as $f){if(filemtime($f)<time()-14*86400)@unlink($f);}
echo "Encrypted backup created: ".basename($out)."\n";
