<?php
/* CLI-only privacy maintenance. Default: anonymize IP after 30d; delete archived requests and logs after 365d. */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once dirname(__DIR__).'/includes/bootstrap.php';
if (!Store::dbMode()) { fwrite(STDERR,"DB connection unavailable\n"); exit(2); }
$pdo=Store::db(); $days=max(90,min(1825,(int)(getenv('MORADIAPP_RETENTION_DAYS')?:365))); $ipDays=max(7,min(365,(int)(getenv('MORADIAPP_IP_RETENTION_DAYS')?:30)));
try {
  $ip=$pdo->prepare("UPDATE demo_requests SET ip_address='' WHERE ip_address<>'' AND created_at < DATE_SUB(NOW(), INTERVAL {$ipDays} DAY)"); $ip->execute(); $ipCount=$ip->rowCount();
  $del=$pdo->prepare("DELETE FROM demo_requests WHERE archived=1 AND created_at < DATE_SUB(NOW(), INTERVAL {$days} DAY)"); $del->execute(); $requestCount=$del->rowCount();
  $logs=$pdo->prepare("DELETE FROM activity_log WHERE created_at < DATE_SUB(NOW(), INTERVAL {$days} DAY)"); $logs->execute(); $logCount=$logs->rowCount();
  echo "Retention complete: anonymized IPs={$ipCount}; archived requests deleted={$requestCount}; activity logs deleted={$logCount}; retention={$days}d\n";
} catch(Throwable $e) { @error_log('[RETENTION] '.$e->getMessage()); fwrite(STDERR,"Retention failed; check application log\n"); exit(3); }
