<?php
/* CLI-only: tighten private directories/files without changing public media permissions. */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
require_once dirname(__DIR__).'/includes/bootstrap.php';
$errors=[];
$dirs=[CONFIG_DIR,DATA_DIR,LOG_DIR,DATA_DIR.'/inbox',DATA_DIR.'/security',DATA_DIR.'/backups'];
foreach($dirs as $dir){if(is_dir($dir)&&!@chmod($dir,0700))$errors[]='dir:'.basename($dir);}
$files=[CONFIG_DIR.'/config.php',CONFIG_DIR.'/setup.key',DATA_DIR.'/products.json',DATA_DIR.'/site-content.json',DATA_DIR.'/security/login-rate.json',DATA_DIR.'/security/contact-rate.json'];
foreach($files as $file){if(is_file($file)&&!@chmod($file,0600))$errors[]='file:'.basename($file);}
foreach(glob(DATA_DIR.'/inbox/*.json')?:[] as $file){if(is_file($file)&&!@chmod($file,0600))$errors[]='inbox:'.basename($file);}
foreach(glob(DATA_DIR.'/backups/*')?:[] as $file){if(is_file($file)&&!@chmod($file,0600))$errors[]='backup:'.basename($file);}
if($errors){fwrite(STDERR,"Some permissions could not be changed: ".implode(', ',$errors)."\n");exit(2);}
echo "Private config/data/log/inbox/security/backup permissions hardened. Public uploads were not changed.\n";
