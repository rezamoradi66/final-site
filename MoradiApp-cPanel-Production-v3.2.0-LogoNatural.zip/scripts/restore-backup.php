<?php
/* Verify and decrypt a MoradiApp AES-256-GCM backup to a private .sql.gz file. CLI only; SQL import is a separate operator step. */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
if ($argc < 2) { fwrite(STDERR,"Usage: php scripts/restore-backup.php /path/to/backup.sql.gz.enc\n"); exit(2); }
$input=realpath($argv[1]); if(!$input||!is_file($input)||!is_readable($input)){fwrite(STDERR,"Backup file is not readable\n");exit(3);}
$secret=(string)getenv('MORADIAPP_BACKUP_KEY');if(strlen($secret)<32){fwrite(STDERR,"MORADIAPP_BACKUP_KEY must be set\n");exit(4);}
$data=@file_get_contents($input);if($data===false||strlen($data)<36||substr($data,0,8)!=='MAPPBKP1'){fwrite(STDERR,"Invalid backup format\n");exit(5);}
$nonce=substr($data,8,12);$tag=substr($data,20,16);$cipher=substr($data,36);$key=hash('sha256',$secret,true);
$plain=openssl_decrypt($cipher,'aes-256-gcm',$key,OPENSSL_RAW_DATA,$nonce,$tag,'MoradiApp backup v1');unset($data,$cipher);
if($plain===false){fwrite(STDERR,"Backup authentication failed; wrong key or damaged file\n");exit(6);}
$out=dirname($input).'/'.basename($input,'.enc').'.verified';$tmp=$out.'.tmp';@umask(0077);
if(@file_put_contents($tmp,$plain,LOCK_EX)!==strlen($plain)||!@chmod($tmp,0600)||!@rename($tmp,$out)){@unlink($tmp);unset($plain);fwrite(STDERR,"Cannot write verified backup\n");exit(7);}unset($plain);
echo "Verified and decrypted gzip SQL: {$out}\nImport it only into the intended database after verifying the target.\n";
