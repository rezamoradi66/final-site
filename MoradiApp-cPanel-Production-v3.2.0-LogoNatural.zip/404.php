<?php
/**
 * 404.php — صفحه خطای یافت‌نشدن
 */
if (!defined('APP_VERSION')) { require_once __DIR__ . '/includes/bootstrap.php'; secure_session_start(); }
http_response_code(404);
$S = Store::settings();
$pageTitle = 'صفحه پیدا نشد | ' . ($S['brand_name'] ?: 'مرادی‌اپ');
$pageDesc  = 'صفحه موردنظر یافت نشد.';
require __DIR__ . '/includes/partials/header.php';
?>
<section class="err-page">
    <div class="container">
        <div class="code">۴۰۴</div>
        <h1>این صفحه در سامانه‌ها ثبت نشده است!</h1>
        <p>نشانی واردشده وجود ندارد یا تغییر کرده است. از لینک‌های زیر استفاده کنید.</p>
        <div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap">
            <a class="btn btn-primary" href="<?= base_url() ?>">صفحه اصلی</a>
            <a class="btn btn-ghost" href="<?= base_url('products') ?>">مشاهده سامانه‌ها</a>
        </div>
    </div>
</section>
<?php require __DIR__ . '/includes/partials/footer.php'; ?>
