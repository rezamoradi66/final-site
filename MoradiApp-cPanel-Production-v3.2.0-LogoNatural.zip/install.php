<?php
/**
 * install.php — ویزارد نصب مرادی‌اپ | Software Showcase
 *
 * مراحل:
 *   ۱) بررسی پیش‌نیازها
 *   ۲) اتصال به دیتابیس (اجرای schema.sql و ایجاد اولین مدیر)
 *   ۳) پایان نصب + قفل نصب
 *
 * امنیت:
 *   - پس از پایان نصب، فایل data/install.lock ساخته می‌شود و ویزارد دیگر اجرا نمی‌شود.
 *   - از دکمه «حذف install.php» در داشبورد یا File Manager برای حذف کامل فایل استفاده کنید.
 */
require_once __DIR__ . '/includes/bootstrap.php';
secure_session_start();
require_once __DIR__ . '/includes/icons.php';

/* ---------- قفل نصب ----------
   شرط پایان نصب، وجود فایل قفل است (نه صرفاً وجود config) تا مرحله‌ی
   «ایجاد مدیر اول» بعد از ثبت config از دست نرود. */
$lockFile = DATA_DIR . '/install.lock';
$installed = is_file($lockFile);
$setupKeyFile = CONFIG_DIR . '/setup.key';
$setupKey = is_file($setupKeyFile) ? trim((string)file_get_contents($setupKeyFile)) : '';
$setupAuthorized = !empty($_SESSION['setup_authorized']);
$dbConfigured = Store::dbMode();

/* حذف خودکار (پس از نصب، از داشبورد) */
if (isset($_POST['selfdestruct'])) {
    csrf_check();
    if (!empty($_SESSION['admin'])) {
        @unlink(__FILE__);
        flash_set('ok', 'فایل install.php حذف شد.');
        redirect(base_url('admin/index.php'));
    }
    http_response_code(403);
    exit('دسترسی مجاز نیست.');
}

if ($installed) {
    $msg = 'نصب قبلاً انجام شده است. این ویزارد برای امنیت قفل شده است.';
    $extra = 'برای نصب مجدد از صفر، فایل data/install.lock را از File Manager حذف کنید (با احتیاط).';
    ?>
    <!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><title>نصب انجام شده</title>
    <link rel="stylesheet" href="<?= asset_url('admin/assets/admin.css') ?>"></head><body>
    <div class="login-page"><div class="login-box">
        <h1>نصب مرادی‌اپ</h1>
        <div class="flash warn"><?= e($msg) ?> <?= e($extra) ?></div>
        <a class="btn" href="<?= base_url('admin/login.php') ?>">ورود به پنل مدیریت</a>
        <a class="btn btn-ghost" href="<?= base_url() ?>">مشاهده سایت</a>
    </div></div></body></html>
    <?php
    exit;
}

/* نصب اولیه فقط با کلید محرمانهٔ setup.key (ساخته‌شده توسط مالک هاست) مجاز است. */
if (!$setupAuthorized) {
    $setupError = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'authorize_setup') {
        csrf_check();
        $provided = (string)($_POST['setup_key'] ?? '');
        if ($setupKey !== '' && strlen($setupKey) >= 32 && hash_equals($setupKey, $provided)) {
            $_SESSION['setup_authorized'] = true; session_regenerate_id(true); redirect('install.php');
        }
        $setupError = 'کلید راه‌اندازی معتبر نیست. فایل config/setup.key را طبق راهنما بسازید.';
    }
    ?>
    <!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>محافظت نصب MoradiApp</title><link rel="stylesheet" href="<?= asset_url('admin/assets/admin.css') ?>"></head><body><div class="login-page"><div class="login-box"><h1>محافظت نصب</h1><p>برای جلوگیری از ایجاد مدیر اولیه توسط شخص ثالث، نصب با کلید محرمانه انجام می‌شود. فایل <code>config/setup.key</code> را از روی نمونه بسازید و کلید تصادفی حداقل ۳۲ کاراکتری داخل آن قرار دهید.</p><?php if ($setupError): ?><div class="flash err"><?= e($setupError) ?></div><?php endif; ?><form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="authorize_setup"><label>کلید راه‌اندازی</label><input type="password" name="setup_key" required autocomplete="off"><button class="btn" type="submit">ادامه نصب</button></form></div></div></body></html>
    <?php exit;
}

/* اگر دیتابیس از قبل دستی پیکربندی شده باشد ولی قفل نباشد، فقط هشدار بده */
$alreadyConfiguredNotice = $dbConfigured
    ? 'توجه: دیتابیس از قبل پیکربندی شده است. اجرای مرحله ۳ جداول را با CREATE IF NOT EXISTS می‌سازد و داده موجود را بازنویسی نمی‌کند.'
    : '';

/* ---------- وضعیت مراحل ---------- */
$step = (int)($_SESSION['install_step'] ?? 1);
if ($step < 1 || $step > 3) { $step = 1; }

/* گذر از مرحله پیش‌نیازها */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'req_ok') {
    csrf_check();
    $_SESSION['install_step'] = 2;
    redirect('install.php');
}

/* ---------- بررسی پیش‌نیازها ---------- */
function req_php(): array { return [PHP_VERSION_ID >= 80100, PHP_VERSION, 'PHP 8.1 یا بالاتر (پیشنهادی: 8.3)']; }
function req_pdo(): array { return [extension_loaded('pdo') && in_array('mysql', PDO::getAvailableDrivers(), true), 'on/off', 'افزونه PDO MySQL']; }
function req_fileinfo(): array { return [extension_loaded('fileinfo'), 'on/off', 'افزونه fileinfo (بررسی MIME آپلودها)']; }
function req_gd(): array { return [extension_loaded('gd') && function_exists('imagecreatefromstring'), 'on/off', 'افزونه GD برای بازرمزگذاری امن تصاویر']; }
function req_zlib(): array { return [extension_loaded('zlib') && function_exists('gzopen'), 'on/off', 'افزونه zlib برای بکاپ فشرده']; }
function req_openssl(): array { return [extension_loaded('openssl') && function_exists('openssl_encrypt'), 'on/off', 'افزونه OpenSSL برای رمزنگاری MFA و بکاپ']; }
function req_mbstring(): array { return [extension_loaded('mbstring'), 'on/off', 'افزونه mbstring (پشتیبانی کامل فارسی)']; }
function req_json(): array { return [function_exists('json_encode'), 'on/off', 'JSON']; }
function req_data_writable(): array { return [is_writable(DATA_DIR), '755', 'قابل نوشتن بودن پوشه data/']; }
function req_config_writable(): array { return [is_writable(CONFIG_DIR), '755', 'قابل نوشتن بودن پوشه config/']; }
function req_uploads_writable(): array { return [is_writable(UPLOAD_DIR . '/media') || is_writable(UPLOAD_DIR), '755', 'قابل نوشتن بودن پوشه uploads/']; }
$checks = [
    'نسخه PHP' => req_php(),
    'PDO MySQL' => req_pdo(),
    'fileinfo' => req_fileinfo(),
    'GD' => req_gd(),
    'zlib' => req_zlib(),
    'OpenSSL' => req_openssl(),
    'mbstring' => req_mbstring(),
    'JSON' => req_json(),
    'پوشه data/' => req_data_writable(),
    'پوشه config/' => req_config_writable(),
    'پوشه uploads/' => req_uploads_writable(),
];
$allPass = true;
foreach ($checks as [$ok, , ]) { if (!$ok) { $allPass = false; } }

/* ---------- مرحله ۲: دیتابیس ---------- */
$dbError = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'db') {
    csrf_check();
    $host = trim((string)($_POST['host'] ?? 'localhost'));
    $port = trim((string)($_POST['port'] ?? '3306'));
    $name = trim((string)($_POST['name'] ?? ''));
    $user = trim((string)($_POST['user'] ?? ''));
    $pass = (string)($_POST['pass'] ?? '');

    if ($name === '' || $user === '') {
        $dbError = 'نام دیتابیس و نام کاربر دیتابیس الزامی است.';
    } else {
        try {
            $dsn = "mysql:host=$host;port=$port;dbname=$name;charset=utf8mb4";
            $test = new PDO($dsn, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT => 6]);
            /* نوشتن config.php */
            $installHost = strtolower((string)(parse_url('http://' . (string)($_SERVER['HTTP_HOST'] ?? 'moradiapp.ir'), PHP_URL_HOST) ?: 'moradiapp.ir'));
            if (!preg_match('/^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)*[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/i', $installHost)) { $installHost = 'moradiapp.ir'; }
            if ($installHost === 'www.moradiapp.ir') { $installHost = 'moradiapp.ir'; }
            $configPhp = "<?php\n"
                . "/**\n * config.php — پیکربندی اصلی (توسط ویزارد نصب ساخته شد)\n * تاریخ: " . date('Y-m-d H:i:s') . "\n * این فایل از طریق .htaccess از دسترسی وب مسدود است.\n */\n"
                . "return [\n"
                . "    'db' => [\n"
                . "        'host' => " . var_export($host, true) . ",\n"
                . "        'port' => " . var_export($port, true) . ",\n"
                . "        'name' => " . var_export($name, true) . ",\n"
                . "        'user' => " . var_export($user, true) . ",\n"
                . "        'pass' => " . var_export($pass, true) . ",\n"
                . "        'charset' => 'utf8mb4',\n"
                . "    ],\n"
                . "    'app' => [\n"
                . "        'debug' => false,\n"
                . "        'session_name' => 'moradiapp_ses',\n"
                . "        'canonical_host' => " . var_export($installHost, true) . ",\n"
                . "        'admin_idle_minutes' => 45,\n"
                . "        'admin_max_hours' => 8,\n"
                . "    ],\n"
                . "    'security' => [\n"
                . "        'force_https' => " . (is_https() ? 'true' : 'false') . ",\n"
                . "        'mfa_encryption_key' => '" . bin2hex(random_bytes(32)) . "',\n"
                . "        'login_max_attempts' => 5,\n"
                . "        'login_lock_minutes' => 15,\n"
                . "    ],\n"
                . "    'uploads' => [\n"
                . "        'max_size_mb' => 4,\n"
                . "        'allowed' => ['jpg', 'jpeg', 'png', 'webp', 'gif'],\n"
                . "    ],\n"
                . "];\n";
            if (@file_put_contents(CONFIG_DIR . '/config.php', $configPhp, LOCK_EX) === false || !@chmod(CONFIG_DIR . '/config.php', 0600)) {
                @unlink(CONFIG_DIR . '/config.php');
                $dbError = 'نوشتن فایل config/config.php یا محدودسازی مجوز خصوصی آن ناموفق بود؛ مجوز پوشه config را بررسی کنید.';
            } else {
                @chmod(CONFIG_DIR, 0700);
                $_SESSION['install_step'] = 3;
                $_SESSION['install_config_done'] = 1;
                redirect('install.php');
            }
        } catch (Throwable $ex) {
            @error_log('[INSTALL-DB] '.$ex->getMessage());
            $dbError = 'اتصال به دیتابیس ناموفق بود. نام دیتابیس، کاربر، رمز و دسترسی‌های MySQL را در cPanel بررسی کنید.';
        }
    }
}

/* ---------- مرحله ۳: مدیر و seed ---------- */
$finishError = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['do'] ?? '') === 'finish') {
    csrf_check();
    try {
        $pdo = Store::db();
        if (!$pdo) { throw new RuntimeException('اتصال دیتابیس برقرار نیست.'); }

        /* ۱) اجرای schema.sql — ابتدا خطوط کامنت حذف می‌شوند تا «;» داخل کامنت‌ها
           باعث شکستن غلط دستورها نشود، سپس بر اساس «;» تجزیه می‌کنیم. */
        $schemaFile = APP_ROOT . '/database/schema.sql';
        $sql = (string)file_get_contents($schemaFile);
        $sql = (string)preg_replace('/^\s*--.*$/m', '', $sql);
        $statements = array_values(array_filter(array_map('trim', explode(';', $sql)), fn($s) => $s !== ''));
        foreach ($statements as $stmt) {
            $pdo->exec($stmt);
        }

        /* نسخه واقعی دیتابیس */
        $dbVersion = (string)$pdo->query('SELECT VERSION()')->fetchColumn();

        /* ۲) ایجاد اولین مدیر */
        $username = trim((string)($_POST['username'] ?? ''));
        $fullName = trim((string)($_POST['full_name'] ?? ''));
        $pass = (string)($_POST['password'] ?? '');
        $pass2 = (string)($_POST['password2'] ?? '');

        if (!preg_match('/^[a-zA-Z0-9_\.\-]{4,60}$/', $username)) {
            $finishError = 'نام کاربری باید ۴ تا ۶۰ کاراکتر انگلیسی، عدد، نقطه یا خط تیره باشد.';
        } elseif (mb_strlen($pass) < 12 || strlen($pass) > 72 || !preg_match('/[A-Za-z]/', $pass) || !preg_match('/[0-9]/', $pass)) {
            $finishError = 'رمز عبور باید ۱۲ تا ۷۲ بایت، شامل حرف و عدد باشد (سازگار با bcrypt).';
        } elseif ($pass !== $pass2) {
            $finishError = 'تکرار رمز عبور مطابقت ندارد.';
        } else {
            $st = $pdo->prepare('SELECT COUNT(*) c FROM admin_users WHERE username = :u');
            $st->execute([':u' => $username]);
            if ((int)$st->fetch()['c'] > 0) {
                $finishError = 'این نام کاربری قبلاً ثبت شده است.';
            } else {
                $st = $pdo->prepare('INSERT INTO admin_users (username, email, full_name, password_hash, role, is_active, created_at)
                                     VALUES (:u, :e, :fn, :p, :r, 1, NOW())');
                $st->execute([
                    ':u' => $username,
                    ':e' => mb_substr(trim((string)($_POST['email'] ?? '')), 0, 150),
                    ':fn' => mb_substr($fullName ?: $username, 0, 120),
                    ':p' => password_hash($pass, PASSWORD_DEFAULT),
                    ':r' => 'admin',
                ]);

                /* ۳) انتقال محتوای seed به دیتابیس */
                seed_database($pdo);

                /* ۴) قفل نصب */
                @file_put_contents($lockFile, 'installed at ' . date('Y-m-d H:i:s') . "\n", LOCK_EX);
                @chmod($lockFile, 0600);
                @unlink($setupKeyFile); unset($_SESSION['setup_authorized']);
                $_SESSION['install_step'] = 3;
                $_SESSION['install_done'] = 1;
                $_SESSION['install_db_version'] = $dbVersion;
                $step = 3;
            }
        }
    } catch (Throwable $ex) {
        @error_log('[INSTALL-FINISH] '.$ex->getMessage());
        $finishError = 'مرحله نصب با خطا مواجه شد. جزئیات در لاگ سرور ثبت شده است؛ اطلاعات دیتابیس در صفحه نمایش داده نمی‌شود.';
    }
}

/** انتقال داده‌های seed از پوشه data/ به جداول دیتابیس */
function seed_database(PDO $pdo): void
{
    $products = json_decode((string)file_get_contents(DATA_DIR . '/products.json'), true) ?: [];
    $settings = json_decode((string)file_get_contents(DATA_DIR . '/site-content.json'), true) ?: [];

    $hasProducts = (int)$pdo->query('SELECT COUNT(*) c FROM products')->fetch()['c'];
    if ($hasProducts === 0 && $products) {
        $st = $pdo->prepare('INSERT INTO products (slug, title, subtitle, description, category, image, gallery, features, modules, technologies, demo_url, demo_type, status, featured, display_order, updated_at)
                             VALUES (:slug,:title,:subtitle,:description,:category,:image,:gallery,:features,:modules,:technologies,:demo_url,:demo_type,:status,:featured,:display_order,NOW())');
        foreach ($products as $p) {
            $st->execute([
                ':slug' => $p['slug'], ':title' => $p['title'], ':subtitle' => $p['subtitle'] ?? '',
                ':description' => $p['description'] ?? '', ':category' => $p['category'] ?? '',
                ':image' => $p['image'] ?? '',
                ':gallery' => json_encode($p['gallery'] ?? [], JSON_UNESCAPED_UNICODE),
                ':features' => json_encode($p['features'] ?? [], JSON_UNESCAPED_UNICODE),
                ':modules' => json_encode($p['modules'] ?? [], JSON_UNESCAPED_UNICODE),
                ':technologies' => json_encode($p['technologies'] ?? [], JSON_UNESCAPED_UNICODE),
                ':demo_url' => $p['demo_url'] ?? '', ':demo_type' => $p['demo_type'] ?? 'placeholder',
                ':status' => $p['status'] ?? 'active', ':featured' => !empty($p['featured']) ? 1 : 0,
                ':display_order' => (int)($p['display_order'] ?? 0),
            ]);
        }
    }

    /* تنظیمات: فقط کلیدهایی که هنوز ثبت نشده‌اند */
    $st = $pdo->prepare('INSERT INTO site_settings (setting_key, setting_value, updated_at) VALUES (:k, :v, NOW())
                         ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)');
    foreach ($settings as $k => $v) {
        $st->execute([':k' => $k, ':v' => is_array($v) ? json_encode($v, JSON_UNESCAPED_UNICODE) : (string)$v]);
    }
}

$showDbVersion = $_SESSION['install_db_version'] ?? null;
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>نصب سامانه معرفی | مرادی‌اپ</title>
<meta name="robots" content="noindex, nofollow">
<link rel="stylesheet" href="<?= asset_url('admin/assets/admin.css') ?>">
</head>
<body>
<div class="login-page">
    <div class="login-box" style="width:min(680px,100%)">
        <div class="lb-brand"><?= brand_logo_svg('40') ?><span><h1>نصب سامانه معرفی محصولات</h1></span></div>
        <div class="lb-sub">در سه مرحله، سایت و پنل مدیریت را روی هاست cPanel خود راه‌اندازی کنید.</div>

        <div class="install-steps">
            <span class="<?= $step >= 1 ? 'cur' : '' ?> <?= $step > 1 ? 'done' : '' ?>">۱. پیش‌نیازها</span>
            <span class="<?= $step >= 2 ? 'cur' : '' ?> <?= $step > 2 ? 'done' : '' ?>">۲. اتصال دیتابیس</span>
            <span class="<?= $step >= 3 ? 'cur' : '' ?>">۳. مدیر سایت و پایان</span>
        </div>

        <?php if ($alreadyConfiguredNotice): ?><div class="flash warn"><?= e($alreadyConfiguredNotice) ?></div><?php endif; ?>

        <?php if ($step === 1): ?>
            <div class="panel">
                <h2>بررسی پیش‌نیازها</h2>
                <table class="req-table">
                    <?php foreach ($checks as $label => [$ok, $extra, $desc]): ?>
                    <tr>
                        <td><?= e($desc) ?></td>
                        <td style="max-width:170px" dir="ltr"><?= e($extra) ?></td>
                        <td class="<?= $ok ? 'req-pass' : 'req-fail' ?>"><?= $ok ? '✔ آماده' : '✕ نامناسب' ?></td>
                    </tr>
                    <?php endforeach; ?>
                </table>
                <?php if ($allPass): ?>
                <form method="post">
                    <?= csrf_field() ?>
                    <input type="hidden" name="do" value="req_ok">
                    <div class="f-actions"><button class="btn" type="submit">ادامه به مرحله ۲</button></div>
                </form>
                <?php else: ?>
                <div class="flash err">پیش‌نیازها کامل نیست. موارد ناقص را از بخش «Select PHP Version» یا File Manager کنترل پنل cPanel اصلاح کنید و صفحه را دوباره بارگذاری کنید.</div>
                <?php endif; ?>
            </div>

        <?php elseif ($step === 2): ?>
            <div class="panel">
                <h2>اتصال به دیتابیس MySQL</h2>
                <p class="p-desc">مقادیر را دقیقاً از بخش <b>MySQL® Databases</b> کنترل پنل cPanel وارد کنید. ابتدا در cPanel یک دیتابیس و یک کاربر بسازید و کاربر را به دیتابیس با دسترسی ALL PRIVILEGES اضافه کنید (راهنمای کامل در سند استقرار).</p>
                <?php if ($dbError): ?><div class="flash err"><?= e($dbError) ?></div><?php endif; ?>
                <form method="post" data-validate>
                    <?= csrf_field() ?>
                    <input type="hidden" name="do" value="db">
                    <div class="f-grid">
                        <div class="f-field">
                            <label>هاست دیتابیس</label>
                            <input type="text" name="host" value="localhost" dir="ltr" style="text-align:left">
                        </div>
                        <div class="f-field">
                            <label>پورت</label>
                            <input type="text" name="port" value="3306" dir="ltr" style="text-align:left">
                        </div>
                        <div class="f-field">
                            <label>نام دیتابیس <span class="req">*</span></label>
                            <input type="text" name="name" required dir="ltr" style="text-align:left" placeholder="cpuser_moradi">
                        </div>
                        <div class="f-field">
                            <label>نام کاربر دیتابیس <span class="req">*</span></label>
                            <input type="text" name="user" required dir="ltr" style="text-align:left" placeholder="cpuser_moradiu">
                        </div>
                        <div class="f-field full">
                            <label>رمز کاربر دیتابیس <span class="req">*</span></label>
                            <input type="password" name="pass" required autocomplete="new-password">
                        </div>
                        <div class="f-actions full"><button class="btn" type="submit">تست اتصال و ادامه</button></div>
                    </div>
                </form>
            </div>

        <?php elseif ($step === 3): ?>
            <?php if (!empty($_SESSION['install_done'])): ?>
                <div class="flash ok">نصب با موفقیت کامل شد!
                    <?php if ($showDbVersion): ?>نسخه واقعی دیتابیس هاست شما: <b dir="ltr"><?= e($showDbVersion) ?></b>.<?php endif; ?>
                </div>
                <div class="panel">
                    <h2>گام‌های پیشنهادی بعد از نصب</h2>
                    <table class="req-table">
                        <tr><td>حذف امن فایل نصب</td><td class="req-pass">از داشبورد پنل، دکمه «حذف فایل نصب» را بزنید.</td></tr>
                        <tr><td>پشتیبان‌گیری اولیه</td><td class="req-pass">از phpMyAdmin یک Export از دیتابیس تهیه کنید.</td></tr>
                        <tr><td>بررسی SSL</td><td class="req-pass">مطمئن شوید سایت روی https باز می‌شود.</td></tr>
                    </table>
                    <div class="f-actions">
                        <a class="btn" href="<?= base_url('admin/login.php') ?>">ورود به پنل مدیریت</a>
                        <a class="btn btn-ghost" href="<?= base_url() ?>">مشاهده سایت</a>
                    </div>
                </div>
            <?php else: ?>
                <div class="panel">
                    <h2>ایجاد اولین مدیر سایت</h2>
                    <p class="p-desc">با این حساب وارد پنل مدیریت می‌شوید. این اطلاعات را در جای امنی نگه دارید؛ رمز عبور به‌صورت هش‌شده (bcrypt) ذخیره می‌شود و قابل بازیابی نیست.</p>
                    <?php if ($finishError): ?><div class="flash err"><?= e($finishError) ?></div><?php endif; ?>
                    <form method="post" data-validate>
                        <?= csrf_field() ?>
                        <input type="hidden" name="do" value="finish">
                        <div class="f-grid">
                            <div class="f-field">
                                <label>نام کاربری مدیر <span class="req">*</span></label>
                                <input type="text" name="username" required maxlength="60" dir="ltr" style="text-align:left" placeholder="admin">
                            </div>
                            <div class="f-field">
                                <label>نام کامل</label>
                                <input type="text" name="full_name" maxlength="120">
                            </div>
                            <div class="f-field">
                                <label>ایمیل مدیر</label>
                                <input type="email" name="email" maxlength="150" dir="ltr" style="text-align:left">
                            </div>
                            <div class="f-field">
                                <label>رمز عبور <span class="req">*</span></label>
                                <input type="password" name="password" required maxlength="72" autocomplete="new-password">
                            </div>
                            <div class="f-field">
                                <label>تکرار رمز عبور <span class="req">*</span></label>
                                <input type="password" name="password2" required maxlength="72" autocomplete="new-password">
                            </div>
                            <div class="f-actions full">
                                <button class="btn" type="submit">اجرای نصب و ایجاد مدیر</button>
                            </div>
                        </div>
                    </form>
                    <p class="p-desc" style="margin-top:14px">این مرحله به‌صورت خودکار: ساخت جداول، انتقال محتوای اولیه (۵ سامانه و تنظیمات سایت) و ایجاد مدیر را انجام می‌دهد.</p>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
<script nonce="<?= e($GLOBALS['CSP_NONCE'] ?? '') ?>" src="<?= asset_url('admin/assets/admin.js') ?>" defer></script>
</body>
</html>
