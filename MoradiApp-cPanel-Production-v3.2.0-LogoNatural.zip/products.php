<?php
/**
 * products.php — فهرست همه سامانه‌ها | ایندکس ادیتوریال (نسخه ۲.۰)
 */
require_once __DIR__ . '/includes/bootstrap.php';
secure_session_start();

$S = Store::settings();
$products = Store::products();
$categories = [];
foreach ($products as $p) { if ($p['category']) { $categories[$p['category']][] = $p; } }

/* شماره‌گذاری سراسری برای حس «ایندکس» */
$gIdx = 0;
$hues = ['', 'h-teal', 'h-amber', 'h-rose', 'h-sky', 'h-ink'];

$pageTitle = 'همه سامانه‌ها | ' . ($S['brand_name'] ?: 'مرادی‌اپ');
$pageDesc  = 'فهرست کامل سامانه‌های نرم‌افزاری سازمانی: برنامه و بودجه، کنترل پروژه، مدیریت مالی، منابع انسانی و تحلیل داده.';

require __DIR__ . '/includes/partials/header.php';
?>
<section class="page-hero">
    <div class="container">
        <div class="crumb"><a href="<?= base_url() ?>">خانه</a> / سامانه‌ها</div>
        <span class="eyebrow"><span class="idx">Index</span>ویترین سامانه‌های سازمانی</span>
        <h1>هر سامانه، یک مسئله واقعی را حل می‌کند</h1>
        <p class="lead">هر سامانه مستقل و ماژولار است؛ اما داده‌های آن با سایر ماژول‌ها یکپارچه می‌شود. برای هر سامانه می‌توانید روایت کامل و نسخه آزمایشی را مشاهده کنید.</p>
    </div>
</section>

<section class="pindex">
    <div class="container">
        <?php foreach ($categories as $cat => $items): ?>
        <div class="pindex-group">
            <div class="pindex-cat reveal"><h2><?= e($cat) ?></h2></div>
            <?php foreach ($items as $p):
                $gIdx++;
                $img = !empty($p['image']) ? base_url($p['image']) : ''; 
                $tags = array_slice($p['technologies'] ?? [], 0, 3);
            ?>
            <article class="pindex-row reveal" style="--d:.04s">
                <span class="pindex-num" aria-hidden="true"><?= e(fa_num(sprintf('%02d', $gIdx))) ?></span>
                <div class="pindex-main">
                    <h3><a href="<?= e(base_url('products/' . $p['slug'])) ?>" style="color:inherit"><?= e($p['title']) ?></a></h3>
                    <p><?= e(excerpt($p['subtitle'] ?: $p['description'], 150)) ?></p>
                    <?php if ($tags): ?>
                    <div class="pindex-tags">
                        <?php foreach ($tags as $t): ?><span><?= e($t) ?></span><?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                    <div class="pindex-links">
                        <a class="link-arrow solid" href="<?= e(base_url('products/' . $p['slug'])) ?>">مشاهده سامانه<?= icon('arrow') ?></a>
                        <a class="link-arrow" href="<?= e(base_url('demos/' . $p['slug'])) ?>">نسخه آزمایشی</a>
                    </div>
                </div>
                <div class="pindex-media">
                    <div class="frame">
                        <div class="f-head"><i></i><i></i><i></i><b><?= e($p['title']) ?></b></div>
                        <div class="f-body">
                            <?php if ($img): ?><img src="<?= e($img) ?>" alt="نمای محیط <?= e($p['title']) ?>" width="600" height="338" loading="lazy" decoding="async"><?php else: ?><img class="product-image-placeholder" src="<?= e(base_url('assets/images/products/placeholder.svg')) ?>" alt="تصویر برای <?= e($p['title']) ?> هنوز ثبت نشده" width="600" height="338" loading="lazy"><?php endif; ?>
                        </div>
                    </div>
                </div>
            </article>
            <?php endforeach; ?>
        </div>
        <?php endforeach; ?>
        <?php if (!$products): ?>
        <div class="stats-empty">در حال حاضر سامانه‌ای فعال نشده است. برای معرفی سامانه جدید، از پنل مدیریت استفاده کنید.</div>
        <?php endif; ?>
    </div>
</section>

<?php require __DIR__ . '/includes/partials/footer.php'; ?>
