<?php
require_once __DIR__ . '/includes/bootstrap.php';
$S = Store::settings();
$V = (array)Store::settings('visual_content', []);
$P = Store::products();
$heroTitle = trim((string)($V['hero_title'] ?? '')) ?: 'راهکارهای نرم‌افزاری هوشمند';
$heroSubtitle = trim((string)($V['hero_subtitle'] ?? '')) ?: 'برای توسعه و رشد کسب‌وکار شما';
$aboutTitle = trim((string)($V['about_title'] ?? '')) ?: 'معرفی MoradiApp.ir';
$aboutText = trim((string)($V['about_text'] ?? '')) ?: 'ما در MoradiApp.ir با تکیه بر تجربه، تخصص و فناوری‌های نوین، راهکارهای نرم‌افزاری متناسب با نیاز سازمان‌ها و کسب‌وکارها ارائه می‌دهیم. هدف ما، تحول دیجیتال، افزایش بهره‌وری و ایجاد ارزش پایدار برای مشتریان است.';
$features = (array)($V['features'] ?? []);
$featureDefaults = [
 ['title'=>'نرم‌افزارهای اختصاصی','subtitle'=>'از ایده تا اجرا'],
 ['title'=>'راهکارهای منعطف','subtitle'=>'متناسب با نیاز شما'],
 ['title'=>'پشتیبانی مطمئن','subtitle'=>'همراه شما در تمام مراحل']
];
for ($i=0; $i<3; $i++) { $features[$i] = array_merge($featureDefaults[$i], (array)($features[$i] ?? [])); }
$features = array_slice($features, 0, 3);
$stats = array_values(array_filter((array)($V['stats'] ?? []), fn($x) => trim((string)($x['label'] ?? '')) !== '' && trim((string)($x['value'] ?? '')) !== ''));
$statIcons = [
 '<svg viewBox="0 0 40 40" aria-hidden="true"><rect x="6" y="8" width="28" height="25" rx="5"/><path d="M13 4v8M27 4v8M6 16h28"/></svg>',
 '<svg viewBox="0 0 40 40" aria-hidden="true"><path d="m20 4 15 8-15 8L5 12z"/><path d="m5 20 15 8 15-8M5 28l15 8 15-8"/></svg>',
 '<svg viewBox="0 0 40 40" aria-hidden="true"><circle cx="15" cy="13" r="6"/><circle cx="29" cy="16" r="5"/><path d="M3 34v-3a12 12 0 0 1 24 0v3M27 26a9 9 0 0 1 10 9"/></svg>',
 '<svg viewBox="0 0 40 40" aria-hidden="true"><path d="M20 4 34 10v10c0 8-6 13-14 16C12 33 6 28 6 20V10z"/><path d="m13 20 5 5 10-11"/></svg>'
];
$siteTitle = trim((string)($S['site_title'] ?? '')) ?: 'MoradiApp.ir | راهکارهای نرم‌افزاری هوشمند';
$siteDescription = trim((string)($S['site_description'] ?? '')) ?: 'راهکارهای نرم‌افزاری هوشمند برای توسعه و رشد کسب‌وکار شما.';
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($siteTitle) ?></title>
<meta name="description" content="<?= e($siteDescription) ?>">
<meta name="robots" content="index,follow">
<link rel="canonical" href="<?= e(full_url()) ?>">
<meta property="og:type" content="website"><meta property="og:site_name" content="MoradiApp.ir">
<meta property="og:title" content="<?= e($siteTitle) ?>"><meta property="og:description" content="<?= e($siteDescription) ?>">
<meta property="og:url" content="<?= e(full_url()) ?>"><meta property="og:image" content="<?= e(full_url('assets/images/brand/logo.webp')) ?>"><meta property="og:locale" content="fa_IR">
<link rel="icon" type="image/png" href="<?= e(base_url('assets/images/brand/favicon.png')) ?>">
<meta name="theme-color" content="#f6f9ff">
<style>
@font-face{font-family:BYekan;src:url('assets/fonts/BYekan.ttf') format('truetype');font-weight:400;font-display:swap}
@font-face{font-family:BKoodak;src:url('assets/fonts/BKoodak.ttf') format('truetype');font-weight:700;font-display:swap}
:root{
 --navy:#092b86;--blue:#075bd8;--deep:#052c9a;--cyan:#06c7e9;--teal:#00aebd;
 --gold:#e9a83d;--gold2:#ffd56a;--ink:#09276f;--muted:#31518d;
 --glass:rgba(255,255,255,.57);--line:rgba(255,255,255,.86);
 --shadow:0 18px 36px rgba(16,91,182,.16),inset 0 1px 0 rgba(255,255,255,.95);
}
*{box-sizing:border-box}
html{scroll-behavior:smooth;width:100%;max-width:100%;overflow-x:clip}
body{margin:0;width:100%;max-width:100%;overflow-x:clip;color:var(--ink);font-family:BYekan,Tahoma,sans-serif;background:
 radial-gradient(ellipse at 78% 8%,rgba(255,255,255,.96) 0 12%,transparent 35%),
 radial-gradient(ellipse at 10% 38%,rgba(105,194,255,.24),transparent 40%),
 linear-gradient(180deg,#f6faff 0%,#e8f4ff 42%,#f8fbff 100%);overflow-x:hidden}
a{color:inherit;text-decoration:none}
button{font:inherit;cursor:pointer}
.page{width:100%;max-width:1600px;margin:auto;position:relative;isolation:isolate;overflow:hidden}
.decor{position:absolute;inset:0;z-index:-1;pointer-events:none;overflow:hidden}
.silk-backdrop{position:absolute;inset:0;width:100%;height:100%;opacity:.8}
.decor:before{content:"";position:absolute;top:-110px;left:0;width:100%;height:520px;border-radius:0;background:radial-gradient(ellipse at 28% 18%,rgba(86,174,255,.16),rgba(255,255,255,.08) 38%,transparent 72%);}
.decor:after{content:"";position:absolute;bottom:0;left:0;right:0;height:360px;
 background:linear-gradient(180deg,transparent,rgba(72,169,255,.13) 55%,rgba(255,255,255,.72));
 clip-path:none}
.header{height:90px;display:flex;align-items:center;gap:28px;padding:10px clamp(22px,5.4vw,86px);position:relative}
.brand{width:200px;flex:0 0 200px;display:flex;align-items:center}
.brand img{width:100%;height:auto;display:block;filter:drop-shadow(0 5px 6px rgba(0,62,131,.08))}
.nav{display:flex;align-items:center;justify-content:center;gap:clamp(22px,3.4vw,55px);flex:1;white-space:nowrap}
.nav a{font-family:BYekan,sans-serif;font-size:18px;font-weight:bold;position:relative;padding:11px 2px;transition:.25s}
.nav a:hover{color:#0078df}
.nav a.active{background:linear-gradient(135deg,#b7f1ff,#82dcf4);border-radius:30px;padding:11px 25px}
.nav a:not(.active):after{content:"";position:absolute;bottom:4px;right:0;width:0;height:2px;background:linear-gradient(90deg,var(--gold),var(--cyan));transition:.25s}
.nav a:hover:after{width:100%}
.actions{display:flex;gap:12px;flex:0 0 auto}
.pill{border-radius:28px;padding:10px 23px;border:1.5px solid #075bd8;display:inline-flex;align-items:center;justify-content:center;gap:9px;font-weight:bold;min-height:45px;background:rgba(255,255,255,.7);box-shadow:0 4px 12px rgba(20,100,210,.06);transition:.25s}
.pill.primary{color:#fff;border:0;background:linear-gradient(115deg,#00aaf2 0%,#075bd8 45%,#061d8a 100%);box-shadow:0 10px 20px rgba(0,87,210,.25)}
.pill:hover{transform:translateY(-2px);box-shadow:0 12px 24px rgba(0,87,210,.2)}
.usericon{width:20px;height:20px;display:inline-block}
.hero{min-height:400px;padding:0 clamp(24px,4.8vw,74px) 0;display:grid;grid-template-columns:1.2fr .9fr;align-items:center;gap:18px;position:relative;direction:ltr}
.hero-copy,.hero-visual{direction:rtl}
.hero-copy{order:2;position:relative;z-index:2;padding:5px 0 18px}
.eyebrow i{width:8px;height:8px;background:var(--gold);border-radius:50%;box-shadow:0 0 12px rgba(255,183,54,.8)}
h1{font-family:BKoodak,sans-serif;font-size:clamp(34px,3.25vw,50px);line-height:1.45;margin:0 0 10px;color:#062d96;text-shadow:0 3px 0 rgba(255,255,255,.8),0 8px 18px rgba(0,71,173,.13)}
.subtitle{font-size:clamp(20px,1.9vw,29px);line-height:1.65;margin:0;color:#102c75}
.goldline{width:min(390px,80%);height:18px;margin:13px 0 26px;display:block}
.benefits{display:flex;gap:11px;flex-wrap:wrap;margin:0 0 30px}
.benefit{display:inline-flex;align-items:center;gap:8px;padding:9px 17px;border-radius:30px;background:linear-gradient(145deg,rgba(255,255,255,.82),rgba(228,243,255,.65));box-shadow:0 4px 15px rgba(42,109,186,.07);font-size:15px;font-weight:bold}
.benefit svg{width:16px;height:16px;stroke:#073b9e;stroke-width:3;fill:none}
.hero-cta{display:flex;gap:16px;flex-wrap:wrap}
.hero-cta .pill{padding:13px 28px;min-width:185px;font-size:17px}
.hero-visual{order:1;position:relative;min-height:360px;display:flex;align-items:center;justify-content:center}
.hero-visual:before{content:"";position:absolute;width:85%;height:60%;left:5%;top:22%;border-radius:50%;background:radial-gradient(ellipse,rgba(31,157,255,.3),rgba(0,217,238,.13) 35%,transparent 70%);filter:blur(26px)}
.reference-hero-art{position:relative;width:min(100%,850px);height:auto;max-height:400px;object-fit:contain;display:block;z-index:1;filter:drop-shadow(0 16px 16px rgba(0,83,169,.08))}
.mark{position:relative;width:min(100%,700px);height:auto;max-height:440px;object-fit:contain;filter:drop-shadow(0 24px 18px rgba(0,80,160,.18));z-index:1}
.hero-floor{position:absolute;bottom:12px;left:7%;width:88%;height:24px;background:radial-gradient(ellipse,rgba(0,161,237,.22),transparent 68%);filter:blur(7px)}
.hero-wave{position:absolute;left:0;right:0;width:100%;bottom:-20px;height:145px;z-index:-1}
.feature-row{display:grid;grid-template-columns:repeat(3,1fr);gap:22px;padding:0 clamp(28px,6.2vw,95px);margin:0 auto 22px;position:relative;z-index:3}
.feature{min-height:108px;border-radius:30px;border:1px solid rgba(255,255,255,.94);background:linear-gradient(145deg,rgba(255,255,255,.72),rgba(205,230,255,.58));box-shadow:var(--shadow);display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:18px 15px;backdrop-filter:blur(12px);transition:transform .25s,box-shadow .25s}
.feature:hover{transform:translateY(-5px);box-shadow:0 22px 36px rgba(13,102,202,.2),inset 0 1px 0 white}
.feature svg{width:38px;height:38px;margin-bottom:7px;stroke:url(#iconGrad);fill:none;stroke-width:2.4}
.feature strong{font-family:BKoodak,BYekan,sans-serif;font-size:20px;color:#082d91}
.feature span{font-size:15px;margin-top:2px;color:#244987}
.about{position:relative;padding:10px clamp(28px,6.2vw,95px) 8px;display:grid;grid-template-columns:.9fr 1.1fr;gap:50px;align-items:center;direction:ltr}
.about-art,.about-copy{direction:rtl}
.about:before{content:"";position:absolute;inset:0;z-index:-1;background:linear-gradient(180deg,rgba(255,255,255,.25),rgba(255,255,255,.48));border-top:1px solid rgba(255,255,255,.7);border-bottom:1px solid rgba(255,255,255,.65);border-radius:42% 42% 0 0 / 8% 8% 0 0}
.about:after{content:"";position:absolute;top:0;left:-3%;right:-3%;height:44px;pointer-events:none;background:linear-gradient(180deg,rgba(255,255,255,.6),transparent);border-top:1px solid rgba(255,255,255,.75);border-radius:50% 50% 0 0}
.about-art{min-height:205px;display:flex;align-items:center;justify-content:center;position:relative}\n.reference-about-art{width:min(100%,680px);height:auto;display:block;filter:drop-shadow(0 8px 10px rgba(0,86,160,.08))}
.laptop{width:min(100%,460px);position:relative;filter:drop-shadow(0 20px 15px rgba(0,72,143,.18));}
.laptop-screen{height:210px;width:76%;margin:auto;border:8px solid #0d397e;border-bottom-width:12px;border-radius:16px 16px 8px 8px;background:linear-gradient(145deg,#073d9b,#009edc 62%,#03246c);transform:perspective(700px) rotateY(-7deg) rotateX(2deg);display:flex;align-items:center;justify-content:center;overflow:hidden;position:relative}
.laptop-screen:before{content:"";position:absolute;inset:0;background:linear-gradient(120deg,transparent 10%,rgba(255,255,255,.25) 35%,transparent 50%)}
.laptop-screen img{width:58%;height:90%;object-fit:contain;position:relative;filter:drop-shadow(0 0 10px rgba(0,220,255,.35))}
.laptop-base{height:20px;width:100%;background:linear-gradient(180deg,#c8eaff,#6d9fc7 48%,#f4fbff);clip-path:polygon(14% 0,86% 0,100% 100%,0 100%);border-radius:0 0 20px 20px}
.laptop-glow{position:absolute;width:95%;height:45%;bottom:2%;left:2%;background:radial-gradient(ellipse,rgba(0,178,255,.2),transparent 68%);filter:blur(12px)}
.about-copy{text-align:right}
.section-title{font-family:BKoodak,sans-serif;font-size:30px;margin:0 0 18px;color:#092d93;display:flex;align-items:center;gap:18px}
.section-title:after{content:"";height:3px;width:90px;background:linear-gradient(90deg,var(--gold),var(--cyan));border-radius:8px;display:inline-block}
.about-copy p{font-size:17px;line-height:2.1;margin:0 0 22px;color:#153674}
.outline-link{display:inline-flex;align-items:center;gap:12px;border:1.5px solid #0871ed;border-radius:30px;padding:10px 22px;background:rgba(255,255,255,.5);font-weight:bold;transition:.2s}
.outline-link:hover{background:#fff;transform:translateY(-2px)}
.stats{margin:0 clamp(28px,6.2vw,95px) 12px;display:grid;grid-template-columns:repeat(4,1fr);border-radius:30px;border:1px solid white;background:linear-gradient(120deg,rgba(255,255,255,.72),rgba(220,240,255,.62));box-shadow:var(--shadow);overflow:hidden;backdrop-filter:blur(10px)}
.stat{padding:18px 16px;display:flex;align-items:center;justify-content:center;gap:13px;position:relative;text-align:right}
.stat:not(:last-child):after{content:"";position:absolute;left:0;top:20%;height:60%;width:1px;background:rgba(42,142,235,.4)}
.stat svg{width:36px;height:36px;stroke:#0098d1;fill:none;stroke-width:2}
.stat strong{display:block;font-family:BKoodak,BYekan,sans-serif;font-size:24px;color:#092b91}
.stat span{font-size:14px;color:#244987}
.contact-band{margin:0 clamp(28px,7.5vw,120px) 48px;padding:26px 30px;border-radius:30px;background:linear-gradient(120deg,rgba(255,255,255,.76),rgba(224,244,255,.7));border:1px solid rgba(255,255,255,.95);box-shadow:var(--shadow);display:flex;align-items:center;justify-content:space-between;gap:20px}
.contact-band h2{font-family:BKoodak,sans-serif;font-size:25px;margin:0 0 6px}
.contact-band p{margin:0;color:#31518d}

.products-section{padding:28px clamp(28px,6.2vw,95px) 30px;text-align:center;position:relative}
.products-section .section-title{justify-content:center;margin-bottom:10px}
.products-section .section-title:after{width:70px}
.products-empty{max-width:950px;margin:0 auto;border:1px solid rgba(255,255,255,.95);border-radius:28px;padding:26px 24px;background:linear-gradient(135deg,rgba(255,255,255,.72),rgba(219,240,255,.58));box-shadow:var(--shadow);display:flex;align-items:center;justify-content:center;gap:18px;backdrop-filter:blur(10px)}
.products-empty svg{width:42px;height:42px;stroke:#058ed0;fill:none;stroke-width:2}
.products-empty strong{display:block;font-family:BKoodak,BYekan,sans-serif;font-size:20px;color:#0a3295;margin-bottom:5px}
.products-empty span{font-size:15px;color:#31518d}
@media(max-width:760px){.products-section{padding:22px 20px}.products-empty{padding:22px 16px;flex-direction:column}.products-empty strong{font-size:18px}.products-empty span{font-size:13px}}
\n.footer{padding:10px clamp(28px,6.2vw,95px) 12px;display:flex;align-items:center;justify-content:space-between;gap:22px;border-top:1px solid rgba(70,153,224,.22);background:rgba(255,255,255,.35)}
.footer-brand{display:block;flex:0 0 150px;width:150px}
.footer-brand img{width:100%;height:auto}
.footer small{color:#5272a4}
.mobile-menu{display:none}
@media(max-width:1100px){
 .header{gap:18px;padding-inline:28px}.brand{width:160px;flex-basis:160px}.nav{gap:18px}.nav a{font-size:15px}.actions .pill{padding:9px 14px}
 .hero{padding-inline:32px;grid-template-columns:1fr 1fr}.hero-visual{min-height:360px}
 .feature-row{padding-inline:32px}.about{padding-inline:32px;gap:28px}.stats{margin-inline:32px}
}
@media(max-width:760px){
 .header{height:auto;min-height:88px;padding:12px 18px;flex-wrap:wrap;justify-content:space-between}
 .brand{width:135px;flex-basis:135px;order:1}.actions{order:2}.actions .pill{min-height:38px;font-size:13px;padding:7px 12px}
 .nav{order:3;flex-basis:100%;justify-content:space-between;gap:8px;overflow:auto;padding:3px 0 8px}
 .nav a{font-size:13px}.nav a.active{padding:8px 15px}
 .hero{display:flex;flex-direction:column;gap:0;padding:12px 20px 0;min-height:auto;direction:rtl}
 .hero-copy{order:1;text-align:center;width:100%;padding:12px 0 0}
 .eyebrow{margin-bottom:10px;font-size:12px}
 h1{font-size:31px;line-height:1.5}.subtitle{font-size:19px}
 .goldline{margin:8px auto 16px}
 .benefits{justify-content:center;gap:7px;margin-bottom:18px}.benefit{font-size:12px;padding:7px 11px}
 .hero-cta{justify-content:center;gap:10px}.hero-cta .pill{min-width:0;padding:10px 17px;font-size:14px}
 .hero-visual{order:2;width:100%;min-height:255px;margin-top:0}.mark{max-height:280px;width:90%}.reference-hero-art{max-height:280px;width:100%}.reference-about-art{width:100%;max-width:440px}
 .hero-wave{height:90px;bottom:-8px}
 .feature-row{grid-template-columns:1fr;gap:12px;padding:0 20px;margin:0 0 30px}
 .feature{min-height:95px;border-radius:24px}.feature svg{width:30px;height:30px}.feature strong{font-size:18px}
 .about{grid-template-columns:1fr;gap:12px;padding:22px 22px 26px}
 .about-art{min-height:190px;order:2}.about-copy{order:1;text-align:center}
 .section-title{justify-content:center;font-size:25px}.section-title:after{width:45px}
 .about-copy p{font-size:15px;line-height:1.9}
 .laptop{max-width:350px}.laptop-screen{height:160px}
 .stats{grid-template-columns:repeat(2,1fr);margin:0 20px 30px;border-radius:24px}
 .stat{padding:15px 10px;gap:9px}.stat:nth-child(2):after{display:none}
 .stat strong{font-size:20px}.stat span{font-size:12px}.stat svg{width:28px;height:28px}
 .contact-band{margin:0 20px 28px;flex-direction:column;text-align:center;padding:22px}
 .contact-band h2{font-size:21px}.contact-band p{font-size:14px}
 .footer{padding:20px;flex-direction:column;text-align:center}.footer-brand{width:120px}
}
@media(prefers-reduced-motion:reduce){*{scroll-behavior:auto;transition:none!important}}

/* === Liquid Light + Silk Brook motion layer: preserves approved composition === */
.silk-backdrop path{transform-box:fill-box;transform-origin:center;will-change:transform,opacity}
.silk-backdrop path:nth-of-type(1){animation:silkDriftA 17s ease-in-out infinite alternate}
.silk-backdrop path:nth-of-type(2){animation:silkDriftB 21s ease-in-out infinite alternate}
.silk-backdrop path:nth-of-type(3){animation:silkDriftC 19s ease-in-out infinite alternate}
.silk-backdrop path:nth-of-type(4){animation:silkDriftD 23s ease-in-out infinite alternate}
.hero-visual{isolation:isolate}
.reference-hero-art,.mark{animation:liquidFloat 8.5s ease-in-out infinite;will-change:transform,filter}
.hero-visual:after{
 content:"";position:absolute;z-index:2;inset:7% 2%;pointer-events:none;border-radius:48%;
 background:linear-gradient(112deg,transparent 0%,rgba(255,255,255,0) 32%,rgba(255,255,255,.30) 43%,rgba(94,247,255,.25) 48%,rgba(255,222,146,.22) 53%,transparent 66%);
 background-size:230% 100%;background-position:150% 0;
 mix-blend-mode:screen;opacity:.62;
 animation:liquidSheen 10s cubic-bezier(.45,0,.55,1) infinite;
 mask-image:radial-gradient(ellipse at center,#000 28%,rgba(0,0,0,.65) 55%,transparent 78%);
}
.hero-visual:before{animation:liquidGlow 7s ease-in-out infinite alternate}
.reference-about-art{animation:brookFloat 11s ease-in-out infinite}
.hero-floor{animation:floorGlow 6.5s ease-in-out infinite alternate}
.feature{animation:glassBreath 9s ease-in-out infinite;animation-delay:var(--motion-delay,0s)}
.feature:nth-child(2){--motion-delay:1.4s}
.feature:nth-child(3){--motion-delay:2.8s}
@keyframes silkDriftA{0%{transform:translate3d(-.6%,0,0) scaleY(.98);opacity:.46}100%{transform:translate3d(1.2%,1.3%,0) scaleY(1.04);opacity:.66}}
@keyframes silkDriftB{0%{transform:translate3d(1%,.4%,0)}100%{transform:translate3d(-1.2%,-.8%,0)}}
@keyframes silkDriftC{0%{transform:translate3d(1%,0,0) scaleY(1)}100%{transform:translate3d(-.8%,-1.1%,0) scaleY(1.035)}}
@keyframes silkDriftD{0%{transform:translate3d(-1%,.5%,0);opacity:.68}100%{transform:translate3d(1.1%,-.5%,0);opacity:.94}}
@keyframes liquidFloat{0%,100%{transform:translate3d(0,0,0) scale(1);filter:drop-shadow(0 16px 16px rgba(0,83,169,.08))}50%{transform:translate3d(0,-7px,0) scale(1.006);filter:drop-shadow(0 22px 20px rgba(0,115,195,.16))}}
@keyframes liquidSheen{0%,12%{background-position:150% 0;opacity:0}28%{opacity:.54}62%{background-position:-70% 0;opacity:.42}78%,100%{background-position:-70% 0;opacity:0}}
@keyframes liquidGlow{0%{opacity:.72;transform:scale(.96)}100%{opacity:1;transform:scale(1.04)}}
@keyframes brookFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-5px)}}
@keyframes floorGlow{0%{opacity:.45;transform:scaleX(.92)}100%{opacity:1;transform:scaleX(1.08)}}
@keyframes glassBreath{0%,100%{box-shadow:var(--shadow)}50%{box-shadow:0 20px 38px rgba(13,102,202,.19),inset 0 1px 0 white}}
@media(prefers-reduced-motion:reduce){
 .silk-backdrop path,.reference-hero-art,.mark,.hero-visual:after,.hero-visual:before,.reference-about-art,.hero-floor,.feature{animation:none!important}
}


/* Server-rendered CMS product cards — matching approved glass/Liquid visual */
.server-products-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:22px;max-width:1240px;margin:24px auto 0;text-align:right}
.server-product-card{overflow:hidden;border:1px solid rgba(255,255,255,.94);border-radius:26px;background:linear-gradient(145deg,rgba(255,255,255,.82),rgba(218,239,255,.65));box-shadow:var(--shadow);backdrop-filter:blur(12px);transition:transform .3s ease,box-shadow .3s ease}
.server-product-card:hover{transform:translateY(-5px);box-shadow:0 24px 44px rgba(16,91,182,.22)}
.server-product-image{display:block;aspect-ratio:16/9;background:linear-gradient(135deg,#dceeff,#f9fcff 55%,#fff0ca);overflow:hidden}
.server-product-image img{width:100%;height:100%;object-fit:cover;display:block}
.product-image-placeholder{height:100%;display:flex;align-items:center;justify-content:center;font-family:BKoodak,sans-serif;font-size:22px;color:#075bd8;background:radial-gradient(circle at 30% 20%,rgba(0,199,233,.2),transparent 40%),linear-gradient(135deg,#edf7ff,#fff)}
.server-product-body{padding:20px 22px 24px}
.server-product-body h3{font-family:BKoodak,BYekan,sans-serif;font-size:22px;margin:0;color:#092b86}
.server-product-body p{margin:8px 0 14px;color:#31518d;line-height:1.9}
.server-product-link{display:inline-flex;align-items:center;gap:8px;color:#075bd8;font-weight:bold}
.products-all{margin:22px auto 0}
.footer small a{color:#075bd8;text-decoration:none}
@media(max-width:900px){.server-products-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:600px){.server-products-grid{grid-template-columns:1fr}.server-product-body{padding:18px}}


/* Brand asset fit: show the complete approved logo without cropping */
.header{height:auto!important;min-height:116px;padding-top:8px!important;padding-bottom:8px!important;overflow:visible!important}
.brand{width:150px!important;flex:0 0 150px!important;min-width:0}
.brand img{width:150px!important;height:116px!important;max-width:100%;object-fit:contain!important;object-position:right center!important;display:block;overflow:visible}
.footer-brand{width:140px!important;flex:0 0 140px!important;height:108px!important;overflow:visible!important}
.footer-brand img{width:100%!important;height:100%!important;object-fit:contain!important;object-position:right center!important;display:block}
.reference-hero-art{object-fit:contain!important;object-position:center!important;width:min(100%,850px)!important;height:auto!important;max-height:400px!important}
.reference-about-art{object-fit:contain!important;object-position:center!important;width:min(100%,680px)!important;height:auto!important}
@media(max-width:1100px){
 .header{min-height:100px!important}
 .brand{width:125px!important;flex-basis:125px!important}
 .brand img{width:125px!important;height:96px!important}
 .footer-brand{width:120px!important;flex-basis:120px!important;height:92px!important}
}
@media(max-width:700px){
 .header{min-height:84px!important;padding-top:5px!important;padding-bottom:5px!important}
 .brand{width:94px!important;flex-basis:94px!important}
 .brand img{width:94px!important;height:72px!important}
 .footer-brand{width:105px!important;flex-basis:105px!important;height:81px!important}
}

</style>
</head>
<body>
<div class="page">
<div class="decor">
<svg class="silk-backdrop" viewBox="0 0 1600 1300" preserveAspectRatio="none" aria-hidden="true">
 <defs>
  <linearGradient id="silkBlue" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#ffffff" stop-opacity=".95"/><stop offset=".45" stop-color="#68baff" stop-opacity=".42"/><stop offset="1" stop-color="#02c8e9" stop-opacity=".04"/></linearGradient>
  <linearGradient id="silkGold" x1="0" y1="0" x2="1" y2="0"><stop stop-color="#f2b44b" stop-opacity=".08"/><stop offset=".5" stop-color="#fff0bd" stop-opacity=".8"/><stop offset="1" stop-color="#00c8e8" stop-opacity=".15"/></linearGradient>
 </defs>
 <path d="M-120 260 C220 40 300 190 520 80 S900 20 1110 180 S1430 310 1720 65" fill="none" stroke="url(#silkBlue)" stroke-width="34" opacity=".55"/>
 <path d="M-100 286 C210 70 310 210 520 105 S900 45 1110 205 S1430 335 1700 95" fill="none" stroke="#ffffff" stroke-width="2.5" opacity=".72"/>
 <path d="M-150 1040 C200 840 390 1110 650 990 S1050 890 1260 1030 S1500 1120 1740 940" fill="none" stroke="url(#silkBlue)" stroke-width="42" opacity=".48"/>
 <path d="M-120 1080 C220 890 400 1140 650 1020 S1040 920 1260 1060 S1500 1150 1710 980" fill="none" stroke="url(#silkGold)" stroke-width="5" opacity=".85"/>
</svg>
</div>
<header class="header">
  <a class="brand" href="/" aria-label="MoradiApp.ir"><img src="assets/images/brand/logo.webp" alt="لوگوی رسمی MoradiApp.ir" width="150" height="116"></a>
  <nav class="nav" aria-label="منوی اصلی">
    <a class="active" href="/">خانه</a><a href="/products">محصولات</a><a href="#services">خدمات</a><a href="/about">درباره ما</a><a href="/contact">تماس با ما</a>
  </nav>
  <div class="actions">
    <a class="pill primary" href="<?= e((string)($S['client_portal_url'] ?? 'https://plan.moradiapp.ir')) ?>" target="_blank" rel="noopener"><svg class="usericon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="7" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2z"/></svg>ورود</a>
    <a class="pill" href="<?= e((string)($S['registration_url'] ?? 'contact#request-form')) ?>"><svg class="usericon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="7" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2z"/></svg>ثبت‌نام</a>
  </div>
</header>

<main id="home">
<section class="hero">
  <div class="hero-copy">
    <h1><?= e($heroTitle) ?></h1>
    <p class="subtitle"><?= e($heroSubtitle) ?></p>
    <svg class="goldline" viewBox="0 0 400 20" aria-hidden="true"><defs><linearGradient id="lineg"><stop stop-color="#e9a83d"/><stop offset=".48" stop-color="#ffe9a3"/><stop offset=".72" stop-color="#00c7ee"/><stop offset="1" stop-color="#075bd8"/></linearGradient></defs><path d="M3 17 C90 -10 145 4 218 6 S326 16 397 1" fill="none" stroke="url(#lineg)" stroke-width="4" stroke-linecap="round"/></svg>
    <div class="benefits">
      <span class="benefit">مدرن <svg viewBox="0 0 20 20"><path d="m3 10 5 5L17 4"/></svg></span>
      <span class="benefit">امن <svg viewBox="0 0 20 20"><path d="m3 10 5 5L17 4"/></svg></span>
      <span class="benefit">پایدار <svg viewBox="0 0 20 20"><path d="m3 10 5 5L17 4"/></svg></span>
      <span class="benefit">قابل توسعه <svg viewBox="0 0 20 20"><path d="m3 10 5 5L17 4"/></svg></span>
    </div>
    <div class="hero-cta">
      <a class="pill primary" href="/products">مشاهده محصولات <span>←</span></a>
      <a class="pill" href="/about">درباره ما <span>ⓘ</span></a>
    </div>
  </div>
  <div class="hero-visual" aria-label="نماد سیال هویت MoradiApp">
    <div class="hero-floor"></div>
    <img class="reference-hero-art" src="assets/images/brand/hero-infinity.png" alt="نماد یکپارچه MoradiApp؛ سامانه‌های متصل" width="900" height="375" fetchpriority="high">
  </div>
  <svg class="hero-wave" viewBox="0 0 1600 180" preserveAspectRatio="none" aria-hidden="true">
    <defs><linearGradient id="waveblue" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#3db4ff" stop-opacity=".04"/><stop offset="1" stop-color="#4fa9f2" stop-opacity=".32"/></linearGradient><linearGradient id="wavegold"><stop stop-color="#f5b63f"/><stop offset=".5" stop-color="#fff3c7"/><stop offset="1" stop-color="#00c8e8"/></linearGradient></defs>
    <path d="M0 70 C180 5 280 165 480 80 S760 20 920 85 S1240 150 1600 25 V180 H0Z" fill="url(#waveblue)"/>
    <path d="M0 72 C180 6 280 166 480 80 S760 20 920 85 S1240 150 1600 25" fill="none" stroke="white" stroke-opacity=".8" stroke-width="3"/>
    <path d="M0 100 C200 28 320 170 520 100 S860 60 1040 115 S1340 135 1600 55" fill="none" stroke="url(#wavegold)" stroke-width="2.5" opacity=".9"/>
  </svg>
</section>

<section class="feature-row" id="services">
<?php
$featureSvgs = [
 '<svg viewBox="0 0 40 40" aria-hidden="true"><path d="M22 5c8-2 13 3 11 11L19 30 10 21z"/><path d="m10 21-6 2 1 8 8-1M19 30l-2 6-8-1 1-8"/><circle cx="27" cy="12" r="3"/></svg>',
 '<svg viewBox="0 0 40 40" aria-hidden="true"><path d="m20 4 15 8-15 8L5 12z"/><path d="m5 20 15 8 15-8M5 28l15 8 15-8"/></svg>',
 '<svg viewBox="0 0 40 40" aria-hidden="true"><path d="M8 22v-5a12 12 0 0 1 24 0v5"/><rect x="5" y="20" width="7" height="12" rx="3"/><rect x="28" y="20" width="7" height="12" rx="3"/><path d="M28 32c-2 4-7 4-11 4"/></svg>'
];
foreach ($features as $i=>$f): ?>
<a class="feature" href="<?= $i===2 ? '/contact' : '/products' ?>"><?= $featureSvgs[$i] ?><strong><?= e((string)$f['title']) ?></strong><span><?= e((string)$f['subtitle']) ?></span></a>
<?php endforeach; ?>
</section>

<section class="about" id="about">
  <div class="about-art"><img class="reference-about-art" src="assets/images/brand/about-laptop.png" alt="تصویر لپ‌تاپ و موج‌های سیال از طرح مرجع" width="680" height="220" loading="lazy"></div>
  <div class="about-copy">
    <h2 class="section-title"><?= e($aboutTitle) ?></h2>
    <p><?= e($aboutText) ?></p>
    <a class="outline-link" href="/about">بیشتر بدانید <span>←</span></a>
  </div>
</section>

<?php if ($stats): ?>
<section class="stats" aria-label="آمار و دستاوردها">
<?php foreach ($stats as $i=>$st): ?><div class="stat"><?= $statIcons[$i % count($statIcons)] ?><div><strong><?= e((string)$st['value']) ?></strong><span><?= e((string)$st['label']) ?></span></div></div><?php endforeach; ?>
</section>
<?php endif; ?>

</main>
<section class="products-section" id="products">
  <h2 class="section-title">سامانه‌ها و محصولات</h2>
  <?php if ($P): ?>
  <div class="server-products-grid">
    <?php foreach ($P as $product): ?>
    <article class="server-product-card">
      <a class="server-product-image" href="<?= e(base_url('products/' . rawurlencode((string)$product['slug']))) ?>">
        <?php if (!empty($product['image']) && is_file(APP_ROOT . '/' . ltrim((string)$product['image'],'/'))): ?>
          <img src="<?= e(base_url((string)$product['image'])) ?>" alt="<?= e((string)$product['title']) ?>" loading="lazy">
        <?php else: ?><span class="product-image-placeholder" aria-hidden="true">MoradiApp</span><?php endif; ?>
      </a>
      <div class="server-product-body">
        <h3><a href="<?= e(base_url('products/' . rawurlencode((string)$product['slug']))) ?>"><?= e((string)$product['title']) ?></a></h3>
        <?php if (!empty($product['subtitle'])): ?><p><?= e((string)$product['subtitle']) ?></p><?php endif; ?>
        <a class="server-product-link" href="<?= e(base_url('products/' . rawurlencode((string)$product['slug']))) ?>">مشاهده جزئیات <span>←</span></a>
      </div>
    </article>
    <?php endforeach; ?>
  </div>
  <a class="outline-link products-all" href="/products">مشاهده همه سامانه‌ها <span>←</span></a>
  <?php else: ?>
  <div class="products-empty">
    <svg viewBox="0 0 40 40" aria-hidden="true"><path d="m20 4 15 8-15 8L5 12z"/><path d="m5 20 15 8 15-8M5 28l15 8 15-8"/></svg>
    <div><strong>سامانه‌ها و محصولات MoradiApp</strong><span>محصولات پس از ثبت و انتشار از پنل مدیریت، در این بخش نمایش داده می‌شوند.</span></div>
  </div>
  <?php endif; ?>
</section>
<footer class="footer" id="contact">
  <a class="footer-brand" href="/"><img src="assets/images/brand/logo.webp" alt="MoradiApp.ir" width="140" height="108" loading="lazy"></a>
  <small><?= e((string)($S['footer_text'] ?? 'ارائه‌دهنده راهکارهای نرم‌افزاری هوشمند برای توسعه و رشد کسب‌وکار شما.')) ?></small>
  <small><?php if (!empty($S['contact_phone'])): ?>تلفن: <?= e((string)$S['contact_phone']) ?> · <?php endif; ?><?php if (!empty($S['contact_email'])): ?><?= e((string)$S['contact_email']) ?> · <?php endif; ?><?= e((string)($S['copyright'] ?? '© MoradiApp.ir — تمامی حقوق محفوظ است.')) ?> · <a href="/contact">تماس با ما</a> · <a href="/privacy">حریم خصوصی</a></small>
</footer>
</div>
<script nonce="<?= e($GLOBALS['CSP_NONCE'] ?? '') ?>">
document.querySelectorAll('a[href^="#"]').forEach(a=>{
  a.addEventListener('click',e=>{
    const id=a.getAttribute('href');
    if(id.length>1 && document.querySelector(id)){e.preventDefault();document.querySelector(id).scrollIntoView({behavior:'smooth',block:'start'});}
  });
});
</script>
</body>
</html>