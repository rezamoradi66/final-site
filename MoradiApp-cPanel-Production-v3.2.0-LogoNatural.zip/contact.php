<?php
/**
 * contact.php — صفحه ارتباط با ما + پردازش فرم درخواست دمو
 * فرم از همه صفحات به همین نقطه ارسال می‌شود (الگوی PRG).
 */
require_once __DIR__ . '/includes/bootstrap.php';
secure_session_start();

$S = Store::settings();
$formSuccess = false;
$formError = false;

/* ---------- پردازش ارسال فرم ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_check();

    $data = [
        'full_name'    => trim((string)($_POST['full_name'] ?? '')),
        'organization' => trim((string)($_POST['organization'] ?? '')),
        'phone'        => latin_digits(trim((string)($_POST['phone'] ?? ''))),
        'email'        => trim((string)($_POST['email'] ?? '')),
        'message'      => trim((string)($_POST['message'] ?? '')),
        'website'      => (string)($_POST['website'] ?? ''), // تله اسپم
        'product'      => (string)($_POST['product'] ?? ''),
        'ip_address'   => substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45),
    ];

    $errors = [];
    if (mb_strlen($data['full_name']) < 3 || mb_strlen($data['full_name']) > 120) { $errors[] = 'نام و نام خانوادگی'; }
    if (mb_strlen($data['organization']) < 2 || mb_strlen($data['organization']) > 150) { $errors[] = 'نام سازمان'; }
    if (!valid_phone($data['phone'])) { $errors[] = 'شماره تماس'; }
    if ($data['email'] !== '' && !valid_email($data['email'])) { $errors[] = 'ایمیل'; }
    if (mb_strlen($data['message']) > 2000) { $errors[] = 'توضیحات'; }

    /* محدودیت نشست + محدودیت پایدار سمت سرور برای IP (مستقل از session) */
    $lastSubmit = (int)($_SESSION['last_demo_submit'] ?? 0);
    if (time() - $lastSubmit < 20 || !contact_rate_limit_allow($data['ip_address'])) { $errors[] = 'زمان'; }

    /* سامانه انتخابی را اعتبارسنجی کن */
    $product = null;
    if ($data['product'] !== '' && $data['product'] !== 'other') {
        $product = Store::product($data['product']);
        if (!$product) { $errors[] = 'سامانه'; }
    }

    $hp = trim($data['website']);
    if ($hp !== '') {
        /* بوت‌اسپم: بی‌صدا رد شود اما پیام موفقیت نشان بده */
        redirect(base_url('contact?sent=1#request-form'));
    }

    if ($errors || $hp !== '') {
        $_SESSION['form_old'] = [
            'full_name' => $data['full_name'], 'organization' => $data['organization'],
            'phone' => $data['phone'], 'email' => $data['email'],
            'message' => $data['message'], 'product' => $data['product'],
        ];
        $_SESSION['form_errors'] = $errors;
        redirect(base_url('contact#request-form'));
    }

    $ok = Store::saveRequest([
        'full_name'    => $data['full_name'],
        'organization' => $data['organization'],
        'phone'        => $data['phone'],
        'email'        => $data['email'],
        'product_id'   => $product['id'] ?? null,
        'product_title'=> $product['title'] ?? 'مشاوره عمومی',
        'message'      => $data['message'],
        'ip_address'   => $data['ip_address'],
    ]);

    if ($ok) {
        $_SESSION['last_demo_submit'] = time();
        redirect(base_url('contact?sent=1#request-form'));
    }
    $formError = true;
    $formSuccess = false;
}

if (isset($_GET['sent'])) { $formSuccess = true; }
$prefillProduct = (string)($_GET['product'] ?? '');

$pageTitle = 'ارتباط با ما | ' . ($S['brand_name'] ?: 'مرادی‌اپ');
$pageDesc  = 'راه‌های ارتباط با مجموعه ' . ($S['brand_name'] ?: 'مرادی‌اپ') . ' و ثبت درخواست دموی سامانه‌های سازمانی.';

require __DIR__ . '/includes/partials/header.php';
?>
<section class="page-hero">
    <div class="container">
        <div class="crumb"><a href="<?= base_url() ?>">خانه</a> / ارتباط با ما</div>
        <h1>ارتباط با ما</h1>
        <p class="lead">برای دریافت مشاوره، استقرار نسخه آزمایشی یا پاسخ به پرسش‌های فنی، از راه‌های زیر با ما در تماس باشید یا فرم درخواست دمو را تکمیل کنید.</p>
    </div>
</section>

<section class="section" style="padding-top:16px">
    <div class="container contact-grid">
        <div class="contact-info-card reveal">
            <h3>اطلاعات تماس</h3>
            <div class="contact-line">
                <span class="c-ico"><?= icon('phone') ?></span>
                <span><b>تلفن</b><span dir="ltr" style="display:block;text-align:right"><?= e($S['contact_phone'] ?: '—') ?></span></span>
            </div>
            <div class="contact-line">
                <span class="c-ico"><?= icon('mail') ?></span>
                <span><b>ایمیل</b><span dir="ltr" style="display:block;text-align:right"><?= e($S['contact_email'] ?: '—') ?></span></span>
            </div>
            <div class="contact-line">
                <span class="c-ico"><?= icon('location') ?></span>
                <span><b>نشانی</b><span><?= e($S['contact_address'] ?: '—') ?></span></span>
            </div>
            <div class="contact-line">
                <span class="c-ico"><?= icon('clock') ?></span>
                <span><b>ساعات پاسخگویی</b><span>شنبه تا چهارشنبه، <?= e(fa_num('8:00')) ?> تا <?= e(fa_num('17:00')) ?></span></span>
            </div>
            <?php
            $socials = (array)($S['social'] ?? []);
            $socialLinks = ['telegram' => 'telegram', 'instagram' => 'instagram', 'linkedin' => 'linkedin', 'whatsapp' => 'whatsapp'];
            $hasSocial = false; ob_start();
            foreach ($socialLinks as $key => $icoName) {
                if (!empty($socials[$key])) { $hasSocial = true; ?>
                    <a href="<?= e($socials[$key]) ?>" target="_blank" rel="noopener" aria-label="<?= e($key) ?>"><?= icon($icoName) ?></a>
                <?php }
            } $socialHtml = ob_get_clean(); ?>
            <?php if ($hasSocial): ?><div class="footer-social"><?= $socialHtml ?></div><?php endif; ?>
        </div>
        <div>
            <?php
            $formError = $formError || (bool)($_SESSION['form_errors'] ?? false);
            unset($_SESSION['form_errors']);
            require __DIR__ . '/includes/partials/request-form.php';
            ?>
        </div>
    </div>
</section>

<?php require __DIR__ . '/includes/partials/footer.php'; ?>
